<?php $__env->startSection('content'); ?>
    <job-applications-list></job-applications-list>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\axelh\localData\sisapp\resources\views/modules/transaction/list-application.blade.php ENDPATH**/ ?>