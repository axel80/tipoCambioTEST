<?php $__env->startSection('content'); ?>
    <vacancy-list></vacancy-list>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\axelh\localData\sisapp\resources\views/modules/maintanance/vacancy-module/list.blade.php ENDPATH**/ ?>