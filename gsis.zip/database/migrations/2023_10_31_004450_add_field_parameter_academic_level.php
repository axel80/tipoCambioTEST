<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('academic_levels', function (Blueprint $table) {
            $table->dropColumn('level_type');
        });

        Schema::table('academic_levels', function (Blueprint $table) {

            $table->enum('level_type', ["PRIM", "BASI", "TITU",  "DIVER", "UNIV", "POSTG", "DOCT"])->default("DIVER")->after('active')->comment("The type of academic level showing what kind of level belongs");
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('academic_levels', function (Blueprint $table) {
            $table->dropColumn('level_type');
        });

        Schema::table('academic_levels', function (Blueprint $table) {
            $table->enum('level_type', ["PRIM", "DIVER", "UNIV", "POSTG"])->after('active')->default("DIVER")->comment("The type of academic level showing what kind of level belongs");
        });
    }
};
