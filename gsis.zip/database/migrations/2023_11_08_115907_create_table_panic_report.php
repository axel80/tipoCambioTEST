<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('panic_reports', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->references('id')->on('users');
            $table->text('report')->default('-----');
            $table->enum('status', ["ALERTSEND", "HELPSEND", "HELPCANCEL", "HELPIN", "PAYMENTPROC", "PAYING"])
                ->default("ALERTSEND")->comment('folowin status are used: ALERT, HELPSEND, HELPIN, PAYMENTPROC, PAYING');
            $table->decimal('service_price', 10, 2)->default(0)->comment('Price for panic button service emergency');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('panic_reports');
    }
};
