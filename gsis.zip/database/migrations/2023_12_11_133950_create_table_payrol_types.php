<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTablePayrolTypes extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payrol_types', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->integer('days_per_month')->default(0);
            $table->integer('days_per_year')->default(0);
            $table->decimal('percentage_igss', 12, 2)->default(0.00);
            $table->decimal('percentage_igss_retired', 12, 2)->default(0.000000);
            $table->foreignId('deduction_isr_id')->references('id')->on('deduction_types');
            $table->decimal('personal_expenses_isr', 12, 2)->default(0.00);
            $table->foreignId('deduction_vacation_id')->references('id')->on('deduction_types');
            $table->foreignId('bonus_decree_id')->references('id')->on('deduction_types')->comment('Bono decreto para aplicar en nomina');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('payrol_types');
    }
}
