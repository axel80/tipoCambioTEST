<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('family_data', function (Blueprint $table) {
            $table->id();
            $table->string('first_name');
            $table->string('second_name');
            $table->string('first_last_name');
            $table->string('second_last_name');
            $table->string('addres');
            $table->date('birth_date');
            $table->string('phone_number');
            $table->foreignId('occupation_id')->references('id')->on('occupations');
            $table->foreignId('employee_file_id')->references('id')->on('employee_files');
            $table->foreignId('relationship_id')->references('id')->on('family_relationships');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('family_data');
    }
};
