<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddFieldDocumentIdNumberAlterEployeeFileId extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('employee_document_files', function (Blueprint $table) {
            $table->dropForeign('employee_document_files_employee_file_id_foreign');
            $table->renameColumn('employee_file_id', 'employee_document_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('employee_document_files', function (Blueprint $table) {
            $table->renameColumn('employee_document_id', 'employee_file_id');
        });
    }
}
