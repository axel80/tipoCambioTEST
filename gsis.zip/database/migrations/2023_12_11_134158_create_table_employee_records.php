<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTableEmployeeRecords extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('employee_records', function (Blueprint $table) {
            $table->id();
            $table->string('description')->default('----');
            $table->foreignId('employee_file_id')->referecences('id')->on('employee_files');
            $table->foreignId('work_day_id')->nullable()->referecences('id')->on('working_days');
            $table->foreignId('cost_center_id')->nullable()->referecences('id')->on('cost_centers');
            $table->foreignId('application_job_id')->nullable()->referecences('id')->on('application_jobs');
            $table->decimal('base_salary', 12, 2)->default(0.00);
            $table->decimal('incentive_bonus_amount', 12, 2)->default(0.00);
            $table->decimal('productive_bonus_amount', 12, 2)->default(0.00);
            $table->foreignId('worker_file_type_id')->referecences('id')->on('worker_file_types');
            $table->string('document_path')->nullable()->comment('File upload');
            $table->boolean('status')->default(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('employee_records');
    }
}
