<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('additional_information', function (Blueprint $table) {
            $table->id();
            $table->boolean('has_been_arrested')->default(0);
            $table->string('reason')->default("----");
            $table->string('judicial_processes')->default("----");
            $table->string('medical_history')->default("----");
            $table->string('polygraph_test')->default("----");
            $table->string('observation_polygraph_test')->default("----");
            $table->string('fecebook_user')->default("----");
            $table->string('instagram_user')->default("----");
            $table->string('twitter_x_user')->default("----");
            $table->string('tiktok_user')->default("----");
            $table->string('secure_beneficiary_name')->default("----");
            $table->string('secure_beneficiary_address')->default("----");
            $table->string('secure_beneficiary_phone')->default("----");
            $table->foreignId('relationship_id')->references('id')->on('family_relationships');
            $table->boolean('has_tattoos')->default(0);
            $table->boolean('has_family_in_company')->default(0);
            $table->foreignId('family_in_company_vacancy_id')->nullable()->refrences('id')->on('vacancies');
            $table->string('name_family_in_company')->default("----");
            $table->boolean('has_friend_in_company')->default(0);
            $table->foreignId('friend_in_company_vacancy_id')->nullable()->refrences('id')->on('vacancies');
            $table->string('name_friend_in_company')->default("----");
            $table->boolean('previously_worked')->default(0);
            $table->date('date_admission')->default("1979-01-01 00:00:00");
            $table->date('date_unregistration')->default("1979-01-01 00:00:00");
            $table->date('previus_vacancy_id')->nullable()->refrences('id')->on('vacancies');
            $table->string('reason_unregistration')->default("----");
            $table->string('use_cuadra')->default("----");
            $table->string('bonus_course')->default("----");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('additional_information');
    }
};
