<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('per_lab_references', function (Blueprint $table) {
            $table->id();
            $table->string('personal_full_name')->default('----');
            $table->string('phone_number')->default('----');
            $table->string('address')->default('----');
            $table->enum('referece_type', ['PER', 'LAB'])->default('PER');
            $table->string('laboral_company_name')->default('----');
            $table->string('last_position_held')->default('----');
            $table->string('immediate_last_boss')->default('----');
            $table->string('unregistration_reason')->default('----');
            $table->date('start_date_work')->default('1979-01-01 00:00:00');
            $table->date('end_date_work')->default('1979-01-01 00:00:00');
            $table->decimal('last_salary_earned', 12,2)->default('0.00');
            $table->foreignId('occupation_id')->references('id')->on('occupations');
            $table->foreignId('employee_file_id')->references('id')->on('employee_files');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('per_lab_references');
    }
};
