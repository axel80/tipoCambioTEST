<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddFieldGradeArmyDeleteTypeWaponsTattosDetails extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('employee_files', function (Blueprint $table) {
            $table->boolean('tottoos')->default(0);
            $table->boolean('tottoos_visibility')->default(0);
            $table->string('meaning_tottoo')->default('----');
            $table->string('picture_tattoo', 200)->default('----');
            $table->foreignId('shot_gun_id')->nullable()->references('id')->on('type_weapons')->comment('Escopeta');
            $table->enum('shot_gun_time', ['0-1', '2-5', '6-10', '11-15', '16-20', '21-30'])->default('0-1')->comment('0-1 to 30 in years');
            $table->foreignId('gun_id')->nullable()->references('id')->on('type_weapons')->comment('pistola');
            $table->enum('gun_time', ['0-1', '2-5', '6-10', '11-15', '16-20', '21-30'])->default('0-1')->comment('0-1 to 30 in years');
            $table->foreignId('revolver_id')->nullable()->references('id')->on('type_weapons')->comment('revólver');
            $table->enum('revolver_time', ['0-1', '2-5', '6-10', '11-15', '16-20', '21-30'])->default('0-1')->comment('0-1 to 30 in years');
            $table->string('army_last_grade')->default('----');
            $table->string('pnc_last_grade')->default('----');
            $table->string('pmt_last_grade')->default('----');
            $table->boolean('pmt_services')->default(0);
            $table->string('pmt_service_time')->default("----")->comment('length of pmt service');
            $table->date('pmt_service_unregistration_date')->default("1970-01-01");
            $table->text('pmt_reason_unregistration')->default("----");
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('employee_files', function (Blueprint $table) {
            $table->dropForeign('employee_files_shot_gun_id_foreign');
            $table->dropColumn('shot_gun_id');
            $table->dropForeign('employee_files_gun_id_foreign');
            $table->dropColumn('gun_id');
            $table->dropForeign('employee_files_revolver_id_foreign');
            $table->dropColumn('revolver_id');
            $table->dropColumn('shot_gun_time');
            $table->dropColumn('gun_time');
            $table->dropColumn('revolver_time');
        });
    }
}
