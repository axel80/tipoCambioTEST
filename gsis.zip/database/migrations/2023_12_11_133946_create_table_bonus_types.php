<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTableBonusTypes extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('bonus_types', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('description');
            $table->string('fix_unix', 1)->default('U')->comment('F = fijo, U= unico');
            $table->string('amount_per_day', 1)->default('S')->comment('S = Si, N= No');
            $table->string('affect_igss', 1)->default('S')->comment('S = Si, N= No');
            $table->string('affect_isr', 1)->default('S')->comment('S = Si, N= No');
            $table->string('affect_aguinaldo', 1)->default('S')->comment('S = Si, N= No');
            $table->string('affect_bono_14', 1)->default('S')->comment('S = Si, N= No');
            $table->string('affect_vacations', 1)->default('S')->comment('S = Si, N= No');
            $table->string('affect_compensation', 1)->default('S')->comment('S = Si, N= No, indemnizacion');
            $table->string('advance_payment_apply', 1)->default('S')->comment('S = Si, N= No aplica a anticipo');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('bonus_types');
    }
}
