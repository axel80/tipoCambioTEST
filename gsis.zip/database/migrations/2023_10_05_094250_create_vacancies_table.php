<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('vacancies', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->text('description_vacancy');
            $table->unsignedInteger('number_vacancy_available');
            $table->unsignedInteger('number_filled_vacancies');
            $table->date('approve_date')->default(date('Y-m-d H:i:s'));
            $table->date('publication_date')->default(date('Y-m-d H:i:s'));
            $table->boolean('public_vacancy')->default(1)->comment('In this fiel mark if the vacancy is public or only internal application recived');
            $table->boolean('private_vacancy')->default(1)->comment('In this fiel mark if the vacancy is private or only internal application recived');
            $table->text('additional_notes')->default('Sin nota adicional');
            $table->decimal('approved_salary', 12, 2);
            $table->decimal('incentive_bonus', 12, 2)->default(0.00);
            $table->decimal('productivity_bonus', 12, 2)->default(0.00);
            $table->boolean('active')->default(1);
            $table->text('comment_validate')->default('Sin comentario de por validacion');
            $table->text('comment_approve')->default('Sin comentario aprovación');
            $table->foreignId('user_create_id')->nullable()->references('id')->on('users');
            $table->foreignId('user_validate_id')->nullable()->references('id')->on('users');
            $table->foreignId('user_appove_id')->nullable()->references('id')->on('users');
            $table->foreignId('occupation_id')->references('id')->on('occupations');
            $table->foreignId('academic_level_id')->references('id')->on('academic_levels');
            $table->timestamps();
        });

        Schema::create('vacancies_requirements', function (Blueprint $table) {
            $table->id();
            $table->foreignId('vacancy_id')->references('id')->on('vacancies');
            $table->foreignId('job_requirement_id')->references('id')->on('job_requirements');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {

        Schema::dropIfExists('vacancies_requirements');
        Schema::dropIfExists('vacancies');
    }
};
