<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddFieldUserIdEmployeeFilesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('employee_files', function (Blueprint $table) {
            $table->foreignId('user_id')->nullable()->references('id')->on('users');
            $table->string('last_degree_earned')->default('----')->comment('Ultimo grado obtenido segun nivel academico seleccionado');
            $table->boolean('weapons_handling')->default(false)->comment('Manejo de armas true si las maneja');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('employee_files', function (Blueprint $table) {
            $table->dropColumn('type_weapons');
            $table->dropColumn('weapons_handling');
            $table->dropColumn('last_degree_earned');
            $table->dropForeign('employee_files_user_id_foreign');
            $table->dropColumn('user_id');
        });
    }
}
