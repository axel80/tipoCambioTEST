<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddConctacNumbersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('employee_files', function (Blueprint $table) {
            $table->string('personal_mobile_number')->default('00000000')->after('updated_at');
            $table->string('personal_home_number')->default('00000000')->after('personal_mobile_number');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('employee_files', function (Blueprint $table) {
            $table->dropColumn('personal_mobile_number');
            $table->dropColumn('personal_home_number');
        });
    }
}
