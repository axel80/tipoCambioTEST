<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('company_cats', function (Blueprint $table) {
            $table->id();
            $table->string('code');
            $table->string('full_name');
            $table->string('address')->nullable();
            $table->string('zip_code')->nullable();
            $table->string('phone_number',20);
            $table->string('tax_number',35);
            $table->string('closing_day');
            $table->string('patronal_number');
            $table->string('business_name');
            $table->string('address_zone')->default("0")->nullable();
            $table->string('representative_name')->nullable();
            $table->date('representative_birth_date')->nullable();
            $table->foreignId('country_rep_id')->nullable()->references('id')->on('countries');
            $table->boolean('active')->default(1);
            $table->foreignId('city_id')->references('id')->on('cities');
            $table->decimal('panic_price', 12,2)->default(0.00);
            $table->string('logo')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('company_cats');
    }
};
