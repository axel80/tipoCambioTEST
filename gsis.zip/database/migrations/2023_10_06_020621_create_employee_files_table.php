<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('employee_files', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('code')->default(1);
            $table->foreignId('company_id')->nullable()->references('id')->on('company_cats');
            $table->boolean('active')->default(1);
            $table->string('first_name')->default('----');
            $table->string('second_name')->default("----");
            $table->string('third_name')->default("----");
            $table->string('first_last_name')->default('----');
            $table->string('marital_last_name')->default("----");
            $table->string('second_last_name')->default("----");
            $table->foreignId('gender_id')->nullable()->references('id')->on('genders');
            $table->foreignId('academic_id')->nullable()->references('id')->on('academic_levels');
            $table->enum('company_employee_status', ['CO', 'LN', 'LE', 'RC', 'SO'])->default('SO')
                ->comment('CON = CONTRATADO, LN = LISTA NEGRA, LE = LISTA EN ESPERA, RC = RETIRADO PUEDE CONTRATAR, SO = SOLICITUD LABORAL');
            $table->date('application_date')->default(date('Y-m-d'));
            $table->date('hire_date')->default("1970-01-01");
            $table->date('start_date')->default("1970-01-01");
            $table->date('unregistration_date')->default("1970-01-01")->comment('date of dismissal or resignation');
            $table->date('last_change_date')->default("1970-01-01");
            $table->enum('type_bank_account', ["M", "A"])->default("M");
            $table->string('bank_account')->default("----");
            $table->string('bank_name')->default("----");
            $table->text('notes')->default("----");
            $table->string('address')->default("----");
            $table->foreignId('city_id')->nullable()->references('id')->on('cities');
            $table->boolean('army_services')->default(0);
            $table->string('army_service_time')->default("----")->comment('length of military service');
            $table->date('army_service_unregistration_date')->default("1970-01-01");
            $table->text('army_reason_unregistration')->default("----");
            $table->boolean('pnc_services')->default(0);
            $table->string('pnc_service_time')->default("----")->comment('length of military service');
            $table->date('pnc_service_unregistration_date')->default("1970-01-01");
            $table->text('pnc_reason_unregistration')->default("----");
            $table->string('document_dpi', 13)->default('----')->comment('DPI id number');
            $table->foreignId('document_id_extend_city_id')->nullable()->references('id')->on('cities');
            $table->date('document_dpi_expiration')->default('1970-01-01');
            $table->string('tax_number')->default('----');
            $table->foreignId('marital_status_id')->nullable()->constrained();
            $table->foreignId('ethnic_id')->nullable()->constrained();
            $table->boolean('exception_igss')->default(0)->comment("IGSS exception ");
            $table->string('irtra_number')->default('----')->comment('IRTRA number');
            $table->date('irtra_expiration')->default('1970-01-01')->comment('IRTRA date expiration');
            $table->string('passport_id', 20)->default('----')->comment('Passport number');
            $table->date('passport_expiration')->default('1970-01-01')->comment('Passport date expiration');
            $table->string('igss_number')->comment('DPI id number');
            $table->date('igss_expiration')->default('1970-01-01')->comment('IGSS id number');
            $table->boolean('driver_license_number')->default(0);
            $table->foreignId('principal_language_id')->nullable()->references('id')->on('languages_apps');
            $table->foreignId('secondary_language_id')->nullable()->references('id')->on('languages_apps');
            $table->boolean('has_children')->default(0);
            $table->string('how_many_children')->default("0");
            $table->string('total_people_depend')->default("0");
            $table->string('emergency_contact_name')->default("----");
            $table->string('emergency_contact_phone')->default("----");
            $table->foreignId('relationship_id')->nullable()->references('id')->on('family_relationships');
            $table->string('photo_path')->default("----");
            $table->string('reason_let_job')->default("----");
            $table->string('carnet_number')->default("----");
            $table->date('carnet_expiration_date')->default("1970-01-01");
            $table->string('company_email')->default("----");
            $table->string('personal_email')->default("----");
            $table->timestamp('last_update_device_date')->default("1970-01-01 00:00:00");
            $table->boolean('universal_compensation')->default(0);
            $table->boolean('allergies')->default(0);
            $table->text('describe_allergies')->default("----");
            $table->foreignId('blood_type_id')->nullable()->constrained();
            $table->string('religion')->default("----");
            $table->boolean('own_home')->default(0);
            $table->string('homeowner_phone_number')->default("----");
            $table->foreignId('shirt_size_id')->nullable()->references('id')->on('clothing_sizes');
            $table->foreignId('pant_size_id')->nullable()->references('id')->on('clothing_sizes');
            $table->foreignId('jacket_size_id')->nullable()->references('id')->on('clothing_sizes');
            $table->foreignId('shoes_size_id')->nullable()->references('id')->on('clothing_sizes');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('employee_files');
    }
};
