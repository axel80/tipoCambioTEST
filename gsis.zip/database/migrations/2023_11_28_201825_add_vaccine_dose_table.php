<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddVaccineDoseTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('employee_files', function (Blueprint $table) {
            $table->enum('vaccine_dose', ['0', '1', '2', '3'])->default('0')->comment("0 = sin vacuna o no selecciona, 1 = primera dosis, 2 = segunda dosis, 3 = tercera dosis");
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('employee_files', function (Blueprint $table) {
            $table->dropColumn('vaccine_dose');
        });
    }
}
