<?php

namespace Database\Seeders;

use App\Models\Catalogs\SystemCruds\LanguageApp;
use Illuminate\Database\Seeder;

class LanguageSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $languages = [
            ['name' => 'español'],
            ['name' => 'ingles'],
            ['name' => 'garifuna'],
            ['name' => 'quiche'],
            ['name' => 'kakchiquel'],
        ];

        foreach ($languages as $language) {
            LanguageApp::create($language);
        }
    }
}
