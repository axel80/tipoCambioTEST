<?php

namespace Database\Seeders;

use App\Models\Modules\System\HumanResources\TypeWeapon;
use Illuminate\Database\Seeder;

class TypeWeaponSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $tWeapons = [
            ['name' => 'escopeta', 'caliber' => '12mm'],
            ['name' => 'pistola', 'caliber' => '09mm'],
            ['name' => 'revolver', 'caliber' => '09mm'],
        ];

        foreach ($tWeapons as $tweapon) {

            TypeWeapon::create($tweapon);
        }
    }
}
