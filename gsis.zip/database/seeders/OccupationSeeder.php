<?php

namespace Database\Seeders;

use App\Models\Catalogs\SystemCruds\Occupation;
use Illuminate\Database\Seeder;

class OccupationSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $occupations = [
            ["name" => "primaria concluida", "short_name"       =>   "PRIM", "country_id" => 83],
            ["name" => "abogado notiario", "short_name"         =>   "LAW",  "country_id" => 83],
            ["name" => "contador publico auditor", "short_name" =>   "CPA",  "country_id" => 83],
            ["name" => "ingeniero sistemas", "short_name"       =>   "INGS", "country_id" => 83],
            ["name" => "ingeniero civil", "short_name"          =>   "INGC", "country_id" => 83],
            ["name" => "básicos concluidos", "short_name"       =>   "BAS",  "country_id" => 83],
            ["name" => "bachiller", "short_name"                =>   "BACH", "country_id" => 83]
        ];

        foreach ($occupations as $occupation) {
            Occupation::create($occupation);
        }
    }
}
