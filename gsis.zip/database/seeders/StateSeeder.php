<?php

namespace Database\Seeders;

use App\Models\Catalogs\SystemCruds\State;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class StateSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $states = [

            ["local_code" => "01", "name" => "Guatemala", "country_id" => 83],
            ["local_code" => "15", "name" => "Baja Verapaz", "country_id" => 83],
            ["local_code" => "16", "name" => "Alta Verapaz", "country_id" => 83],
            ["local_code" => "02", "name" => "El Progreso", "country_id" => 83],
            ["local_code" => "18", "name" => "Izabal", "country_id" => 83],
            ["local_code" => "19", "name" => "Zacapa", "country_id" => 83],
            ["local_code" => "20", "name" => "Chiquimula", "country_id" => 83],
            ["local_code" => "06", "name" => "Santa Rosa", "country_id" => 83],
            ["local_code" => "21", "name" => "Jalapa", "country_id" => 83],
            ["local_code" => "22", "name" => "Jutiapa", "country_id" => 83],
            ["local_code" => "03", "name" => "Sacatepequez", "country_id" => 83],
            ["local_code" => "04", "name" => "Chimaltenango", "country_id" => 83],
            ["local_code" => "05", "name" => "Escuintla", "country_id" => 83],
            ["local_code" => "07", "name" => "Solola", "country_id" => 83],
            ["local_code" => "08", "name" => "Totonicapan", "country_id" => 83],
            ["local_code" => "09", "name" => "Quetzaltenango", "country_id" => 83],
            ["local_code" => "10", "name" => "Suchitepequez", "country_id" => 83],
            ["local_code" => "11", "name" => "Retalhuleu", "country_id" => 83],
            ["local_code" => "12", "name" => "San Marcos", "country_id" => 83],
            ["local_code" => "13", "name" => "Huehuetenango", "country_id" => 83],
            ["local_code" => "14", "name" => "Quiche", "country_id" => 83],
            ["local_code" => "17", "name" => "Peten", "country_id" => 83],


        ];

        foreach ($states as $state){
            State::create($state);
        }
    }
}
