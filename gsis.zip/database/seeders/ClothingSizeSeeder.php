<?php

namespace Database\Seeders;

use App\Models\Catalogs\SystemCruds\ClothingSize;
use Illuminate\Database\Seeder;

class ClothingSizeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $clothings = [
            ['name' => 'talla l chaqueta', 'type' => 'JACK', 'size' => 'J-L'],
            ['name' => 'talla m chaqueta', 'type' => 'JACK', 'size' => 'J-M'],
            ['name' => 'talla s chaqueta', 'type' => 'JACK', 'size' => 'J-S'],
            ['name' => 'talla xl chaqueta', 'type' => 'JACK', 'size' => 'J-XL'],
            ['name' => 'talla xs chaqueta', 'type' => 'JACK', 'size' => 'J-XS'],
            ['name' => 'talla l camisa', 'type' => 'SHIRT', 'size' => 'S-L'],
            ['name' => 'talla m camisa', 'type' => 'SHIRT', 'size' => 'S-M'],
            ['name' => 'talla s camisa', 'type' => 'SHIRT', 'size' => 'S-S'],
            ['name' => 'talla xl camisa', 'type' => 'SHIRT', 'size' => 'S-XL'],
            ['name' => 'talla xs camisa', 'type' => 'SHIRT', 'size' => 'S-XS'],
            ['name' => 'talla 32 pantalon', 'type' => 'PANT', 'size' => 'P-32'],
            ['name' => 'talla 36 pantalon', 'type' => 'PANT', 'size' => 'P-36'],
            ['name' => 'talla 38 pantalon', 'type' => 'PANT', 'size' => 'P-38'],
            ['name' => 'talla 30  pantalon', 'type' => 'PANT', 'size' => 'P-30'],
            ['name' => 'talla 34  pantalon', 'type' => 'PANT', 'size' => 'P-34'],
            ['name' => 'talla 32 zapato', 'type' => 'SHOES', 'size' => 'Z-32'],
            ['name' => 'talla 36 zapato', 'type' => 'SHOES', 'size' => 'Z-36'],
            ['name' => 'talla 35 zapato', 'type' => 'SHOES', 'size' => 'Z-35'],
            ['name' => 'talla 38 zapato', 'type' => 'SHOES', 'size' => 'Z-38'],
            ['name' => 'talla 30  zapato', 'type' => 'SHOES', 'size' => 'Z-30'],
            ['name' => 'talla 34  zapato', 'type' => 'SHOES', 'size' => 'Z-34'],
            ['name' => 'talla 40  zapato', 'type' => 'SHOES', 'size' => 'Z-40']

        ];

        foreach ($clothings as $cloth) {
            ClothingSize::create($cloth);
        }
    }
}
