<?php

namespace Database\Seeders;

use App\Models\Catalogs\SystemCruds\Ethnic;
use Illuminate\Database\Seeder;

class EthnicSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $ethnics = [
            ['name' => 'xinca', 'short_name' => 'XIN', 'local_code' => '01'],
            ['name' => 'garifuna', 'short_name' => 'GAR', 'local_code' => '02'],
            ['name' => 'maya', 'short_name' => 'MAY', 'local_code' => '03'],
            ['name' => 'mestiza', 'short_name' => 'MES', 'local_code' => '04'],
            ['name' => 'extranjeros', 'short_name' => 'EXT', 'local_code' => '05'],
            ['name' => 'afrodescendiente / creole / afromestizo', 'short_name' => 'AFR', 'local_code' => '06']
        ];

        foreach ($ethnics as $eth) {
            Ethnic::create($eth);
        }
    }
}
