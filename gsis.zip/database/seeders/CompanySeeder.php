<?php

namespace Database\Seeders;

use App\Models\Catalogs\SystemCruds\CompanyCat;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CompanySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $companies = [
            [
                "code"              => "SIS",
                "full_name"         => "Grupo SIS, S.A",
                "address"           => "KM 11.5 Carretera a Villa Canales",
                "zip_code"          => "01013",
                "phone_number"      => "+502 24292200",
                "tax_number"        => "36105716",
                "closing_day"       => "30",
                "patronal_number"   => "105111",
                "business_name"     => "GRUPO SIS, SOCIEDAD ANONIMA",
                "address_zone"      => "0",
                "city_id"           => 1,
                "logo"              => "logo/logo.png",
                "base_salarial"     => "3250.00"
            ],
            [
                "code"              => "YAMAM",
                "full_name"         => "YAMAM, S.A",
                "address"           => "KM 11.5 Carretera a Villa Canales",
                "zip_code"          => "01013",
                "phone_number"      => "+502 24292200",
                "tax_number"        => "36105716",
                "closing_day"       => "30",
                "patronal_number"   => "105111",
                "business_name"     => "YAMAM, SOCIEDAD ANONIMA",
                "address_zone"      => "0",
                "city_id"           => 1,
                "logo"              => "logo/logo.png",
                "base_salarial"     => "3550.00"
            ]


        ];

        foreach ($companies as $company) {
            CompanyCat::create($company);
        }
    }
}
