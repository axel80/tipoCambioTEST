<?php

namespace Database\Seeders;

use App\Models\Modules\System\HumanResources\DeductionType;
use Illuminate\Database\Seeder;

class DeductionTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // types ['F', 'U', 'P'] fijo, unico, prestamo
        $deductions = [
            [
                'name'          => 'ornato',
                'description'   => 'boleto de ornato',
                'type'          => 'U', //Que solo se aplica una vez
            ],
            [
                'name'          => 'anticipo quincenal',
                'description'   => 'anticipo quincenal',
                'type'          => 'U',
            ],
            [
                'name'          => 'prestamo',
                'description'   => 'prestamo bancario',
                'type'          => 'P', //Prestamo
            ],
            [
                'name'          => 'isr',
                'description'   => 'deducción isr',
                'type'          => 'U',
            ],
            [
                'name'          => 'otro descuento',
                'description'   => 'otros descuentos',
                'type'          => 'U',
            ],
            [
                'name'          => 'faltantes caja',
                'description'   => 'faltantes caja chica',
                'type'          => 'U',
            ],
            [
                'name'          => 'deducción bonificación incentivo',
                'description'   => 'deducción bonificación incentivo',
                'type'          => 'U',
            ],
            [
                'name'          => 'vacación',
                'description'   => 'deduccion por vacaciones',
                'type'          => 'U',
            ],

        ];

        foreach ($deductions as $deduction) {
            DeductionType::create($deduction);
        }
    }
}
