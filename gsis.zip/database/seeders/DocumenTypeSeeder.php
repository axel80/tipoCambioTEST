<?php

namespace Database\Seeders;

use App\Models\Catalogs\SystemCruds\DocumentType;
use Illuminate\Database\Seeder;

class DocumenTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $documents = [
            ['name' => 'documento de identidad', 'active' => true],
            ['name' => 'licencia de conducir', 'active' => true],
            ['name' => 'certificado de estudios superiores', 'active' => true],
            ['name' => 'certificado de estudios diversificados', 'active' => true],
            ['name' => 'certificado de estudios básicos', 'active' => true],
            ['name' => 'certificado de estudios primaria', 'active' => true],
            ['name' => 'permiso tenencia de arma', 'active' => true],
            ['name' => 'permiso portación de arma', 'active' => true]
        ];

        foreach ($documents as $document) {
            DocumentType::create($document);
        }
    }
}
