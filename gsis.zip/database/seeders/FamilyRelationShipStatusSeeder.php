<?php

namespace Database\Seeders;

use App\Models\Catalogs\SystemCruds\FamilyRalationShip;
use Illuminate\Database\Seeder;

class FamilyRelationShipStatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $familyRealationships = [
            ["name" => "padre", 'active' => true],
            ["name" => "madre", 'active' => true],
            ["name" => "hijo(a)", 'active' => true],
            ["name" => "conyuge", 'active' => true],
        ];

        foreach ($familyRealationships as $family) {
            FamilyRalationShip::create($family);
        }
    }
}
