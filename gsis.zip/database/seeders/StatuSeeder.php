<?php

namespace Database\Seeders;

use App\Models\Catalogs\SystemCruds\Status;
use Illuminate\Database\Seeder;

class StatuSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $statuses = [
            ['name' => 'creado', 'active' => true],
            ['name' => 'enviado', 'active' => true],
            ['name' => 'proceso', 'active' => true],
            ['name' => 'autorizado', 'active' => true],
            ['name' => 'aprobado', 'active' => true],
            ['name' => 'generado', 'active' => true],
            ['name' => 'agregado', 'active' => true],
            ['name' => 'actualizado', 'active' => true],
            ['name' => 'agendado', 'active' => true],
            ['name' => 'asignado', 'active' => true],

        ];

        foreach ($statuses as $status) {
            Status::create($status);
        }
    }
}
