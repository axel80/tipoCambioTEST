<?php

namespace Database\Seeders;

use App\Models\Catalogs\SystemCruds\AcademicLevel;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class AcademicLevelSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $levels = [

            ["name" => Str::upper("Bachiller en computación"),  "short_name" => "BACHC", "active" => 1, "level_type" => "DIVER", "country_id" => 83],
            ["name" => Str::upper("Perito Contador con Especialidad en Computación"), "short_name" => "PCC", "active" => 1, "level_type" => "DIVER", "country_id" => 83],
            ["name" => Str::upper("Lic Auditor público"), "short_name" => "PCC", "active" => 1, "level_type" => "DIVER", "country_id" => 83],
            ["name" => "6to. " . Str::upper("Primaria"), "short_name" => "PCC", "active" => 1, "level_type" => "PRIM",  "country_id" => 83],
            ["name" => Str::upper("Basicos concluido"), "short_name" => "BAS", "active" => 1, "level_type" => "BASI",  "country_id" => 83],
        ];

        foreach ($levels as $level) {
            AcademicLevel::create($level);
        }
    }
}
