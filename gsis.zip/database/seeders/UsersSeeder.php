<?php

namespace Database\Seeders;

use App\Models\User;
use Faker\Generator;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UsersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run(Generator $faker)
    {
        $demoUser = User::create([
            'name'              => 'Usuario demo',
            'email'             => 'demo@gmail.com',
            'username'          => '2546091390103',
            'password'          => Hash::make('123456789'),
            'email_verified_at' => now(),
        ]);

        $demoUser2 = User::create([
            'name'              => 'Axel Sarceño',
            'email'             => 'asarceno.orozco@gmail.com',
            'username'          => '2546091390101',
            'password'          => Hash::make('123456789'),
            'email_verified_at' => now(),
        ]);

        $demoUser3 = User::create([
            'name'              => 'Rodrigo contreras',
            'email'             => 'rcontreras@gmail.com',
            'username'          => '2546091390105',
            'password'          => Hash::make('123456789'),
            'email_verified_at' => now(),
        ]);
        $demoUser4 = User::create([
            'name'              => 'Gerardo Osorio',
            'email'             => 'gosorio@gmail.com',
            'username'          => '2546091390108',
            'password'          => Hash::make('123456789'),
            'email_verified_at' => now(),
        ]);
    }
}
