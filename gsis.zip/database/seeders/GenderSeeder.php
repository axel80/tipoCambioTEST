<?php

namespace Database\Seeders;

use App\Models\Catalogs\SystemCruds\Gender;
use Illuminate\Database\Seeder;

class GenderSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $genders = [
            ["name" => "masculino", "note" => "Masculino", "local_code" => "M"],
            ["name" => "femenino", "note" => "Femenino", "local_code" => "F"]
        ];

        foreach ($genders as $gender) {
            Gender::create($gender);
        }
    }
}
