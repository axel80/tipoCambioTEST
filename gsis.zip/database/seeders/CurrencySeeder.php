<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Catalogs\SystemCruds\Currency;

class CurrencySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $currencies = [
            [
                "name"       => "Dolar",
                "code_iso"   => "USD",
                "symbol"     => "$",
            ],
            [
                "name"       => "Quetzales",
                "code_iso"   => "GTQ",
                "symbol"     => "Q",
            ],

        ];

        foreach ($currencies as $currency) {
            Currency::create($currency);
        }
    }
}
