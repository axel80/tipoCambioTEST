<?php

namespace Database\Seeders;

use App\Models\Catalogs\SystemCruds\WorkingDay;
use Illuminate\Database\Seeder;

class WorkingDaySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $workingDays = [
            [
                'name'      => 'turno 12hrs',
                'hours'     => '12',
                'rest_days' => '{
                    "dias":{
                        "dia1":"lunes",
                        "dia2":"viernes"
                    }}',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ],

            [
                'name'      => 'turno 24hrs',
                'hours'     => '24',
                'rest_days' => '{"dias":{
                    "dia1":"jueves",
                    "dia2":"viernes",
                    "dia3":"sábado"
                }}',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ],
            [
                'name'      => 'turno 8hrs',
                'hours'     => '8',
                'rest_days' => '{"dias":{
                    "dia1":"sábado",
                    "dia2":"domingo"
                }}',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ],
            [
                'name'      => 'administración 8hrs',
                'hours'     => '8',
                'rest_days' => '{"dias":{
                    "dia1":"sábado",
                    "dia2":"domingo"
                }}',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ],
            [
                'name'      => 'operaciones 8hrs',
                'hours'     => '8',
                'rest_days' => '{"dias":{
                    "dia2":"domingo"
                }}',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ],



        ];

        foreach ($workingDays as $workingDay) {
            WorkingDay::create($workingDay);
        }
    }
}
