<?php

namespace Database\Seeders;

use App\Models\Catalogs\SystemCruds\BloodType;
use Illuminate\Database\Seeder;

class BloodSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $bloodTypes = [
            ['group' => 'A+'],
            ['group' => 'A-'],
            ['group' => 'B+'],
            ['group' => 'B-'],
            ['group' => 'AB+'],
            ['group' => 'AB-'],
            ['group' => 'O+'],
            ['group' => 'O-'],
        ];

        foreach ($bloodTypes as $bloodType) {
            BloodType::create($bloodType);
        }
    }
}
