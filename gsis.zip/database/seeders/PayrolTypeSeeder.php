<?php

namespace Database\Seeders;

use App\Models\Modules\System\HumanResources\PayrolType;
use Illuminate\Database\Seeder;

class PayrolTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $payrols = [
            [
                'name'                      => 'mensual',
                'days_per_month'            => 30,
                'days_per_year'             => 365,
                'percentage_igss'           => 4.83,
                'percentage_igss_retired'   => 0.00,
                'deduction_isr_id'          => 4,
                'personal_expenses_isr'     => 48000.00,
                'deduction_vacation_id'     => 8,
                'bonus_decree_id'           => 1
            ]
        ];
        foreach ($payrols as $payrol) {
            PayrolType::create($payrol);
        }
    }
}
