<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Modules\System\HumanResources\JobRequirement;

class JobRequirementSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $requirements = [
            ["name" => "antecedentes penales",      "mandatory"    =>   true,  "type" => "FIELD"],
            ["name" => "antecedentes policiacos",   "mandatory"    =>   true,  "type" => "FIELD"],
            ["name" => "prueba poligráfica",        "mandatory"    =>   true,  "type" => "TEXTAREA"],
            ["name" => "título diversificado",      "mandatory"    =>   true,  "type" => "FIELD"],
            ["name" => "título universitario",      "mandatory"    =>   false, "type" => "FIELD"],
            ["name" => "certificado primaria",      "mandatory"    =>   true,  "type" => "FIELD"],
            ["name" => "DIGECAM certificado",       "mandatory"    =>   true,  "type" => "FIELD"]
        ];

        foreach ($requirements as $requirement) {
            JobRequirement::create($requirement);
        }
    }
}
