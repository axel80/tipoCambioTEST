<?php

namespace Database\Seeders;

use App\Models\Catalogs\SystemCruds\MaritalStatus;
use Illuminate\Database\Seeder;

class MaritalStatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $martialStatuses = [
            ["name" => "casado", "notes" => "casado", "local_code" => 1],
            ["name" => "soltero", "notes" => "soltero", "local_code" => 2],
        ];

        foreach ($martialStatuses as $marital) {
            MaritalStatus::create($marital);
        }
    }
}
