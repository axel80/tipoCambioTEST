<?php

namespace Database\Seeders;

use App\Models\Modules\System\HumanResources\BonusType;
use Illuminate\Database\Seeder;

class BonusTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $bonuses = [
            [
                'name'                  => 'bono decreto',
                'description'           => 'bonificación 78-89',
                'fix_unix'              => 'F',
                'amount_per_day'        => 'S',
                'affect_igss'           => 'N',
                'affect_isr'            => 'S',
                'affect_aguinaldo'      => 'N',
                'affect_bono_14'        => 'S',
                'affect_vacations'      => 'N',
                'affect_compensation'   => 'N',
                'advance_payment_apply' => 'N'

            ],
            [
                'name'                  => 'bono productividad',
                'description'           => 'bonificacion de productividad',
                'fix_unix'              => 'U',
                'amount_per_day'        => 'N',
                'affect_igss'           => 'S',
                'affect_isr'            => 'S',
                'affect_aguinaldo'      => 'S',
                'affect_bono_14'        => 'S',
                'affect_vacations'      => 'S',
                'affect_compensation'   => 'S',
                'advance_payment_apply' => 'N'
            ]
        ];

        foreach ($bonuses as $bonus) {
            BonusType::create($bonus);
        }
    }
}
