<?php

namespace Database\Seeders;

use App\Models\Modules\System\HumanResources\WorkerFileType;
use Illuminate\Database\Seeder;

class WorkerFileTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Reference ['U', 'D'] U = unique solo debe haber uno activo para esa ficha de empleado,
        // D = duplicate = puede haber uno o varios de ese mismo tipo
        $workerFiles = [
            [
                'name'      => 'aumento de salario',
                'reference'  => 'U'
            ],
            [
                'name'      => 'asignación bono puesto',
                'reference'  => 'U'
            ],
            [
                'name'      => 'asignacion bono decreto',
                'reference'  => 'U'
            ],
            [
                'name'      => 'documento identificación frente',
                'reference'  => 'U'
            ],
            [
                'name'      => 'documento identificación atrás',
                'reference'  => 'U'
            ],
            [
                'name'      => 'fotografía trabajador',
                'reference'  => 'U'
            ],




        ];
        foreach ($workerFiles as $workerFile) {
            WorkerFileType::create($workerFile);
        }
    }
}
