<?php

use App\Http\Controllers\Catalogs\SystemCruds\AcademicLevelController;
use App\Http\Controllers\Catalogs\SystemCruds\BloodTypeController;
use App\Http\Controllers\Catalogs\SystemCruds\CompanyCatController;
use App\Http\Controllers\Catalogs\SystemCruds\CurrencyController;
use App\Http\Controllers\Catalogs\SystemCruds\EthnicController;
use App\Http\Controllers\Catalogs\SystemCruds\GenderController;
use App\Http\Controllers\Catalogs\SystemCruds\JobRequirementController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Catalogs\SystemCruds\LanguageAppController;
use App\Http\Controllers\Catalogs\SystemCruds\OccupationController;
use App\Http\Controllers\Catalogs\SystemCruds\WorkingDayController;

Route::get('/language', [LanguageAppController::class, 'index'])->name('language');
Route::get('/language/list', [LanguageAppController::class, 'getLangList'])->name('language.list');
Route::post('/language/store', [LanguageAppController::class, 'store'])->name('language.create');
Route::post('/language/delete', [LanguageAppController::class, 'destroy'])->name('language.delete');
Route::post('/language/update', [LanguageAppController::class, 'update'])->name('language.update');



// Requirements RRHH
Route::get('/requirement', [JobRequirementController::class, 'index'])->name('requirement');
Route::get('/requirement/list', [JobRequirementController::class, 'getReqList'])->name('requirement.list');
Route::post('/requirement/store', [JobRequirementController::class, 'store'])->name('requirement.create');
Route::post('/requirement/delete', [JobRequirementController::class, 'destroy'])->name('requirement.delete');
Route::post('/requirement/update', [JobRequirementController::class, 'update'])->name('requirement.update');

// Occupations
Route::get('/occupation', [OccupationController::class, 'index'])->name('occupation');
Route::get('/occupation/list', [OccupationController::class, 'getOccupationList'])->name('occupation.list');
Route::get('/occupation/create', [OccupationController::class, 'create'])->name('occupation.create');
Route::post('/occupation/store', [OccupationController::class, 'store'])->name('occupation.save');
Route::post('/occupation/delete', [OccupationController::class, 'destroy'])->name('occupation.delete');
Route::post('/occupation/update', [OccupationController::class, 'update'])->name('occupation.update');




// Academic Levels
Route::get('/academic-level', [AcademicLevelController::class, 'index'])->name('academic.level');
Route::get('/academic-level/list', [AcademicLevelController::class, 'getAcademicLevelList'])->name('academic.level.list');
Route::get('/academic-level/create', [AcademicLevelController::class, 'create'])->name('academic.level.create');
Route::post('/academic-level/store', [AcademicLevelController::class, 'store'])->name('academic.level.save');
Route::post('/academic-level/delete', [AcademicLevelController::class, 'destroy'])->name('academic.level.delete');
Route::post('/academic-level/update', [AcademicLevelController::class, 'update'])->name('academic.level.update');

// Working Days
Route::get('/working-days', [WorkingDayController::class, 'index'])->name('working.day.level');
Route::get('/working-days/list', [WorkingDayController::class, 'getWorkingDaysList'])->name('working.day.level.list');
Route::get('/working-days/create', [WorkingDayController::class, 'create'])->name('working.day.level.create');
Route::post('/working-days/store', [WorkingDayController::class, 'store'])->name('working.day.level.save');
Route::post('/working-days/delete', [WorkingDayController::class, 'destroy'])->name('working.day.level.delete');
Route::post('/working-days/update', [WorkingDayController::class, 'update'])->name('working.day.level.update');

// Genders
Route::get('/genders', [GenderController::class, 'index'])->name('genders');
Route::get('/genders/list', [GenderController::class, 'listGenders'])->name('gender.list');
Route::get('/genders/create', [GenderController::class, 'create'])->name('gender.create');
Route::post('/genders/store', [GenderController::class, 'store'])->name('gender.save');
Route::post('/genders/delete', [GenderController::class, 'destroy'])->name('gender.delete');
Route::post('/genders/update', [GenderController::class, 'update'])->name('gender.update');

// Currencies
Route::get('/currencies', [CurrencyController::class, 'index'])->name('currencies');
Route::get('/currencies/list', [CurrencyController::class, 'getCurrencyList'])->name('currencies.list');
Route::get('/currencies/create', [CurrencyController::class, 'create'])->name('currencies.create');
Route::post('/currencies/store', [CurrencyController::class, 'store'])->name('currencies.save');
Route::post('/currencies/delete', [CurrencyController::class, 'destroy'])->name('currencies.delete');
Route::post('/currencies/update', [CurrencyController::class, 'update'])->name('currencies.update');

// Ethnics
Route::get('/ethnics', [EthnicController::class, 'index'])->name('ethnics');
Route::get('/ethnics/list', [EthnicController::class, 'getEthnicList'])->name('ethnics.list');
Route::get('/ethnics/create', [EthnicController::class, 'create'])->name('ethnics.create');
Route::post('/ethnics/store', [EthnicController::class, 'store'])->name('ethnics.save');
Route::post('/ethnics/delete', [EthnicController::class, 'destroy'])->name('ethnics.delete');
Route::post('/ethnics/update', [EthnicController::class, 'update'])->name('ethnics.update');

Route::get('/blood-types', [BloodTypeController::class, 'index'])->name('blood-types');
Route::get('/blood-types/list', [BloodTypeController::class, 'getBloodTypeList'])->name('blood-types.list');
Route::get('/blood-types/create', [BloodTypeController::class, 'create'])->name('blood-types.create');
Route::post('/blood-types/store', [BloodTypeController::class, 'store'])->name('blood-types.save');
Route::post('/blood-types/delete', [BloodTypeController::class, 'destroy'])->name('blood-types.delete');
Route::post('/blood-types/update', [BloodTypeController::class, 'update'])->name('blood-types.update');






// Companies
Route::get('/company/list', [CompanyCatController::class, 'companyList'])->name('companies.list');
Route::get('/company/baseSalarial/{id}', [CompanyCatController::class, 'companyBaseSalarial'])->name('companies.base.salarial');
