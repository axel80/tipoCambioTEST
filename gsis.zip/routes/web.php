<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Catalogs\SystemCruds\AcademicLevelController;
use App\Http\Controllers\Catalogs\SystemCruds\BloodTypeController;
use App\Http\Controllers\Catalogs\SystemCruds\GenderController;
use App\Http\Controllers\Catalogs\SystemCruds\MaritalStatusController;
use App\Http\Controllers\Catalogs\SystemCruds\StateController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\Modules\System\HumanResources\JobApplicationController;
use App\Http\Controllers\Modules\System\HumanResources\VacancyController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect('home');
});

Auth::routes();

Route::get('logout', [LoginController::class, 'logout']);
Route::get('/home', [HomeController::class, 'index'])->name('home');



Route::get('optimize-app', [HomeController::class, 'optimize'])->name('opitimize')->middleware('auth');
//Route::get('clear-data', [HomeController::class, 'clearData'])->name('clear.database')->middleware('auth');


Route::get('vacancy/{slug}', [VacancyController::class, 'jobApplication'])->name('vacancy.apply');
Route::get('cat/genders/list', [GenderController::class, 'listGenders'])->name('genders.list');
Route::get('cat/marital/list', [MaritalStatusController::class, 'listMaritalSatus'])->name('marital.list');
Route::get('job-application/{slug}', [JobApplicationController::class, 'index'])->name('job.application');
Route::get('cat/state/list', [StateController::class, 'listStates'])->name('state.application');
Route::get('cat/city/list/{state}', [StateController::class, 'listCities'])->name('city.application');
Route::get('cat/country/list', [StateController::class, 'listCountryNationality'])->name('country.application');
Route::get('cat/languages/list', [StateController::class, 'languagesList'])->name('languages.application');
Route::get('cat/size/list/{type}', [StateController::class, 'sizeCloth'])->name('size.cloth.application');
Route::get('cat/relationship/list', [StateController::class, 'relationShip'])->name('relation.ship.application');
Route::get('cat/get-relation/{id}', [StateController::class, 'getRelName'])->name('relation.getName.application');
Route::get('cat/academic-level/list', [AcademicLevelController::class, 'getAcademicLevelList'])->name('acedemic-level.list.application');
Route::get('cat/vacancies/list', [VacancyController::class, 'getVacancyApplyList'])->name('vacancy.application.list');
Route::post('process/job-application/store', [JobApplicationController::class, 'store'])->name('job-app.save');
Route::get('cat/blood/list', [BloodTypeController::class, 'getBloodTypeList'])->name('cat.blood.list');
Route::post('cat/job-application/save', [JobApplicationController::class, 'store'])->name('cat.save.application-job');
Route::post('cat/job-application/update', [JobApplicationController::class, 'update'])->name('cat.update.application-job');
