<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\Process\PanicReportController;

Route::get('/panic-button', [PanicReportController::class, 'getReports'])->name('pannic.alert');
Route::get('/panic-button/assign', [PanicReportController::class, 'getUsersAssign'])->name('pannic.assign-super-user');
