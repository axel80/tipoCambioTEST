<?php

use App\Http\Controllers\Api\Process\PanicReportController;
use App\Http\Controllers\Modules\System\HumanResources\JobApplicationController;
use Illuminate\Support\Facades\Route;


// Begin transactions routes

Route::get('applications', [JobApplicationController::class, 'listAplJob'])->name('applicacion.list');
Route::get('applications/list', [JobApplicationController::class, 'getListApls'])->name('application.get-list');
Route::get('applications/review', [JobApplicationController::class, 'showAplJob'])->name('application.show');
Route::get('applications/list-data', [JobApplicationController::class, 'listAplJobData'])->name('application.list-data');
Route::get('applications/show', [JobApplicationController::class, 'showAplJobData'])->name('application.show-data');
Route::post('applications/rejected', [JobApplicationController::class, 'requestChageStatus'])->name('application.rejected');


// Get data aplication
Route::get('applications/get/{id}', [JobApplicationController::class, 'getData'])->name('application.get-data');
Route::get('applications/users-list', [JobApplicationController::class, 'getUsers'])->name('application.get-users');



