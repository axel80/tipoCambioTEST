<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Modules\System\HumanResources\VacancyController as Vacancy;


// Vacancies RRHH
Route::get('/vacancies', [Vacancy::class, 'index'])->name('vacancies');
Route::get('/vacancies/create', [Vacancy::class, 'create'])->name('vacancies.create');
Route::get('/vacancies/edit/{id}', [Vacancy::class, 'edit'])->name('vacancies.edit');
Route::get('/vacancies/list', [Vacancy::class, 'getVacancyList'])->name('vacancies.list');
Route::post('/vacancies/store', [Vacancy::class, 'store'])->name('vacancies.save');
Route::post('/vacancies/delete', [Vacancy::class, 'destroy'])->name('vacancies.delete');
Route::post('/vacancies/update', [Vacancy::class, 'update'])->name('vacancies.update');

