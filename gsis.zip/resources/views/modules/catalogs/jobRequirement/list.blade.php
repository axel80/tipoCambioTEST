@extends('adminlte::page')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-12 mt-3">
                <div class="card card-dark">
                    <div class="card-header">Requerimientos</div>

                    <div class="card-body">

                        <requirement-job-list></requirement-job-list>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

