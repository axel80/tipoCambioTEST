@extends('adminlte::page')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-12 mt-3">
                <div class="card card-dark">
                    <div class="card-header">Etnias</div>

                    <div class="card-body">

                        <ethnics-list></ethnics-list>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection


