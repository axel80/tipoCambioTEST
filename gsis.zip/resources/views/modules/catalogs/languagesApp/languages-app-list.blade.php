@extends('adminlte::page')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-12 mt-3">
                <div class="card card-dark">
                    <div class="card-header">Idiomas</div>

                    <div class="card-body">

                        <language-list></language-list>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

