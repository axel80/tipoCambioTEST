@extends('adminlte::page')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-12 mt-3">
                <div class="card card-dark">
                    <div class="card-header">Monedas</div>

                    <div class="card-body">

                        <currency-list></currency-list>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

