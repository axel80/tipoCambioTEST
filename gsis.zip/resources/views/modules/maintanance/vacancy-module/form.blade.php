@extends('adminlte::page')

@section('content')
    <vacancy-form></vacancy-form>
@endsection


