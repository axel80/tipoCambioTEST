@extends('adminlte::page')

@section('content')
    <vacancy-list></vacancy-list>
@endsection



