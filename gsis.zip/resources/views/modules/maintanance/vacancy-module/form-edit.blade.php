@extends('adminlte::page')

@section('content')

    {{-- {{ dd($vacancyReqs) }} --}}
    <vacancy-form :vacancy="{{ $vacancy }}" :reqs="{{ $vacancyReqs }}"></vacancy-form>
@endsection


