@extends('layouts.app')

@section('content')
    {{--   <div class="card">
        <div class="container">

            {{ $vacancy }} <br>
            @foreach ($reqArrs as $req)
                {{ $req[0]['type'] }} <br>
            @endforeach
        </div>

    </div> --}}

    <job-application-form :vacancy="{{ $vacancy }}" :reqs="{{ $reqArrs }}"></job-application-form>
@endsection
