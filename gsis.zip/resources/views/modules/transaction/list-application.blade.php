@extends('adminlte::page')

@section('content')
    <job-applications-list></job-applications-list>
@endsection

{{-- @section('footer')
    @include('layouts.partials.footer')
@stop --}}
