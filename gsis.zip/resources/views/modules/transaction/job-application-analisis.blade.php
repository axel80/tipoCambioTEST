@extends('adminlte::page')

@section('content')
    <job-applications-analisis></job-applications-analisis>
@endsection
{{-- @section('footer')
    @include('layouts.partials.footer')
@stop --}}
