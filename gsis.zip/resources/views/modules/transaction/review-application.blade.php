@extends('adminlte::page')

@section('content')
    <job-application-review></job-application-review>
@endsection

@section('footer')
    @include('layouts.partials.footer')
@stop
