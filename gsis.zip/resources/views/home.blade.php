@extends('adminlte::page')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-12 mt-3">
                <div class="card">
                    <div class="card-header">Dashboard alertas boton de pánico</div>

                    <div class="card-body">
                        {{-- <home-component></home-component> --}}

                        <panic-alert></panic-alert>


                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection


{{-- @section('footer')
    @include('layouts.partials.footer')
@stop --}}
