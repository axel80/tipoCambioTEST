/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */

require('./bootstrap');

window.Vue = require('vue').default;

/**
 * The following block of code may be used to automatically register your
 * Vue components. It will recursively scan this directory for the Vue
 * components and automatically register them with their "basename".
 *
 * Eg. ./components/ExampleComponent.vue -> <example-component></example-component>
 */

// const files = require.context('./', true, /\.vue$/i)
// files.keys().map(key => Vue.component(key.split('/').pop().split('.')[0], files(key).default))

Vue.component('home-component', require('./components/ExampleComponent.vue').default);

//Catalog Vue components
Vue.component('language-list', require('./components/modules/catalogs/languagesApp/ListComponent.vue').default);
Vue.component('requirement-job-list', require('./components/modules/catalogs/requirements/ListComponent.vue').default);
Vue.component('gender-list', require('./components/modules/catalogs/genders/ListComponent.vue').default);
Vue.component('currency-list', require('./components/modules/catalogs/currencies/ListComponent.vue').default);
Vue.component('ethnics-list', require('./components/modules/catalogs/ethnics/ListComponent.vue').default);


//Vacancy components
Vue.component('vacancy-list', require('./components/modules/maintanance/vacancy-module/ListComponent.vue').default);
Vue.component('vacancy-form', require('./components/modules/maintanance/vacancy-module/FormCompoment.vue').default);


//Job Application
Vue.component('job-application-form', require('./components/modules/transaction/job-application/FormCompoment.vue').default);
Vue.component('job-application-review', require('./components/modules/transaction/job-application/ReviewComponent.vue').default);
Vue.component('job-applications-list', require('./components/modules/transaction/job-application/ListComponent.vue').default);
Vue.component('job-applications-analisis', require('./components/modules/transaction/job-application/AnalisisComponent.vue').default);


Vue.component('panic-alert', require('./components/process/PanicProcessComponent.vue').default);


/**
 * Next, we will create a fresh Vue application instance and attach it to
 * the page. Then, you may begin adding components to this application
 * or customize the JavaScript scaffolding to fit your unique needs.
 */
window.onload = ()=>{
    const app = new Vue({
        el: '#app',
    });
}

