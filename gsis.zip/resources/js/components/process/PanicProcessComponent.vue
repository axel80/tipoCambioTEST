<template>
    <div class="col-12 row">

        <div class="col-md-12" v-if="notificactions.length < 1">
            <div class="alert alert-warning alert-dismissible">
                <h5><i class="icon fas fa-exclamation-triangle"></i> Seguimientos</h5>
                No hay alertas pendientes de seguimiento
            </div>
        </div>

        <div class="col-md-4" v-for="(item, index) in notificactions" :key="item.idex" v-else>

            <div class="card" :class="`card-${item.classAlert}`">
                <div class="card-header">
                    <h3 class="card-title">Alerta Cliente: {{item.user.name}}</h3>
                </div>
                <div class="card-body">
                    <label>Contacto correo:</label>  {{ item.user.email }}
                    <label>Alerta mensaje boton pánico:</label> {{ item.report }} <br>
                    <label>Costo del servicio:</label>Q {{ item.service_price }} <br>
                    <label>Estado de la alerta: </label>
                        <span v-if="item.status === 'ALERTSEND'">
                             Alerta recibida en proceso
                        </span>
                        <span v-else-if="item.status === 'HELPIN'">
                             Ayuda en el sitio
                        </span>
                        <span v-else-if="item.status === 'PAYMENTPROC'">
                             En proceso de pago
                        </span>
                        <span v-else-if="item.status === 'PAYING'">
                             Pagada
                        </span>
                        <br>
                    <label>Supervisor asignado: </label>


                </div>
                <div class="card-footer">
                    <button class="btn btn-primary" @click="alertChangeStatus(item)"><i class="fas fa-exclamation"></i> Acciones</button>

                </div>
            </div>
        </div>

        <v-app id="inspire">
            <template>
            <v-dialog
                v-model="dialogNotes"
                max-width="750"
                persistent
                transition="dialog-bottom-transition"
            >

            <v-card>
                    <v-toolbar
                    color="primary"
                    dark
                    >Cambiar y asignar:</v-toolbar>

                    <v-card-text>

                        <v-container fluid>
                            <v-row>

                                <v-col
                                    cols="12"
                                    sm="6"
                                    md="6"
                                >
                                <v-select item-text='text' item-value="id"
                                    v-model="alertStatuSelect" :items="alertStatusItems"
                                    label="Estado a seleccionar (Obligatorio)"
                                    hint="Seleccionando estado"
                                    :loading="loadingList"
                                    >
                                </v-select>
                                </v-col>
                                <v-col
                                    cols="12"
                                    sm="6"
                                    md="6"
                                >
                                <v-select item-text='name' item-value="id"
                                    v-model="userSupervisorSelect" :items="userSupervisorArr"
                                    label="Supervisor asignar"
                                    hint="Seleccionar supervisor"
                                    :loading="loadingList"
                                    >
                                </v-select>
                                </v-col>

                            </v-row>
                        </v-container>

                    </v-card-text>

                    <v-card-actions>
                        <v-spacer></v-spacer>

                        <div class="row">
                            <div class="col-md-6">
                                <button
                                    class="btn btn-success mr-2"
                                    @click="changeData()"
                                >
                                <i class="fas fa-paper-plane"></i>
                                    Enviar
                                </button>

                            </div>


                            <div class="col-md-6">
                                <button
                                    class="btn btn-danger"
                                    @click="cancelData()"

                                >
                                <i class="fas fa-times-circle"></i>
                                    Cancelar
                                </button>
                            </div>

                        </div>



                        <v-spacer></v-spacer>

                    </v-card-actions>
            </v-card>

            </v-dialog>
        </template>
        </v-app>




    </div>
</template>

<script>
import Vuetify from "vuetify";
import "vuetify/dist/vuetify.min.css";
import Swal from "sweetalert2/dist/sweetalert2";
import "sweetalert2/src/sweetalert2.scss";

export default {
    vuetify: new Vuetify(),
    data(){
        return {
            messageAlert:'',
            colorClass:"danger",
            customerName:'',
            uri: '/notifications/',
            notificactions:[],
            alertStatuSelect:'',
            alertStatusItems:[
                {'id': 'HELPSEND',  'text': 'Ayuda en camino'},
                {'id': 'HELPIN', 'text': 'Ayuda en el lugar'},
                {'id': 'PAYMENTPROC', 'text':'En proceso de pago'},
                {'id': 'PAYING', 'text': 'Pagada por el cliente'}
            ],
            actionDialog:false,
            loadingList:false,
            dialogNotes:false,
            userSupervisorSelect:0,
            userSupervisorArr:[]

        }
    },
    computed:{},
    watch:{
    },

    mounted(){

        this.getPanicAlert();
        this.getUsers();

        setInterval(() => {
            this.getPanicAlert();
        }, 15500);

    },

    methods:{

        getPanicAlert(){
            let url = `${this.uri}panic-button`;
            axios.get(url).then((response)=>{
                console.log(response.data.data);
                this.notificactions = response.data.data
            })
        },



        toastMessage(icon, message){
            const Toast =  Swal.mixin({
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
            didOpen: (toast) => {
                toast.onmouseenter = Swal.stopTimer;
                toast.onmouseleave = Swal.resumeTimer;
            }
            });
                Toast.fire({
                icon: icon,
                title: message
            });
        },

        changeData(){
            this.dialogNotes = true
        },

        cancelData(){
            this.dialogNotes = false
        },

        alertChangeStatus(item){
            this.dialogNotes = true
        },

        getUsers(){
            let url = `${this.uri}panic-button/assign`;

            axios.get(url)
                .then((response)=>{
                    console.log(response.data.data)
                    this.userSupervisorArr = response.data.data
                });
        }





    },

    components:{
        Vuetify
    }

}

</script>
