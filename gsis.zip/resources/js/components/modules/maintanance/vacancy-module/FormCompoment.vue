<template>
    <div class="container-fluid mt-3">
        <div class="row">
            <div class="col-md-12">
                <div class="card card-dark">
                    <div class="card-header">
                        <h4 class="invoice-title">{{action}} plaza </h4>
                    </div>

                    <div class="card-body">
                        <!--     Inicia vuetify       -->
                        <v-app id="inspire">
                            <template>
                                <v-card>
                                    <v-container>
                                       <v-row>

                                           <v-col
                                               cols="12"
                                               sm="3"
                                               md="3"
                                               xs="12"
                                           >
                                               <v-text-field
                                                   ref="nameVacancy"
                                                   v-model="nameVacancy"
                                                   label="Nombre de la plaza"
                                                   hint="Nombre de la plaza"
                                                   :counter="50"
                                                   maxlength="50"
                                                   @blur="nameVacancy = nameVacancy.toUpperCase()"
                                                   :loading="loadingName"
                                               >

                                               </v-text-field>


                                           </v-col>

                                           <v-col
                                               cols="12"
                                               sm="12"
                                               md="3"
                                               lg="3"
                                           >
                                               <div>
                                                   <v-select
                                                       item-text='name'
                                                       item-value="id"
                                                       v-model="occupationSelected"
                                                       :items="occupationListArray"
                                                       label="Seleccione una ocupacion"
                                                       hint="Ocupaciones"
                                                       :loading="loadingOccupation"
                                                   >
                                                   </v-select>
                                               </div>
                                           </v-col>

                                           <v-col
                                               cols="12"
                                               sm="12"
                                               md="3"
                                               lg="3"
                                           >
                                               <div>
                                                   <v-select
                                                       item-text='name'
                                                       item-value="id"
                                                       v-model="academicLevelSelected"
                                                       :items="academicLevelListArray"
                                                       label="Seleccione un grado académico"
                                                       hint="Grado académico"
                                                       :loading="loadingCompany"
                                                   >
                                                   </v-select>
                                               </div>
                                           </v-col>

                                           <v-col
                                               cols="12"
                                               sm="12"
                                               md="3"
                                               lg="3"
                                           >
                                               <div>
                                                   <v-select
                                                       item-text='name'
                                                       item-value="id"
                                                       v-model="companySelected"
                                                       :items="companyListArray"
                                                       label="Seleccione una empresa"
                                                       hint="Empresa"
                                                       :loading="loadingAcademicLevel"
                                                       @change="getBaseSalarial(companySelected)"
                                                   >
                                                   </v-select>
                                               </div>
                                           </v-col>






                                           <v-col
                                               cols="12"
                                               sm="12"
                                               md="12"
                                               xs="12"
                                           >
                                               <v-textarea
                                                   clearable
                                                   ref="descriptionVacancy"
                                                   v-model="descriptionVacancy"
                                                   label="Descripción de la plaza"
                                                   hint="Descripción de la plaza"
                                                   :counter="500"
                                                   maxlength="500"
                                                   :loading="loadingDescription"
                                               >

                                               </v-textarea>


                                           </v-col>

                                           <v-col
                                               cols="12"
                                               xs="12"
                                               sm="3"
                                               md="3"

                                           >
                                               <v-text-field-integer
                                                   v-model="numberVacancies"
                                                   label="Numero de vacantes"
                                                   hint="Numero de vacantes"
                                                   :counter="8"
                                                   :properties="{
                                                    readonly: false,
                                                    clearable: true,
                                                    placeholder:'1253'
                                                   }"
                                                   :options="{
                                                       humanMask: '########',
                                                       machineMask: '########',
                                                       empty:'',
                                                       applyAfter: false
                                                   }"
                                               >

                                               </v-text-field-integer>


                                           </v-col>
                                           <v-col
                                               cols="12"
                                               xs="12"
                                               sm="3"
                                               md="3"

                                           >
                                               <v-text-field-integer
                                                   v-model="numberFilled"
                                                   label="Numero de plazas ocupadas"
                                                   hint="Numero de plazas ocupadas"
                                                   :counter="8"
                                                   :properties="{
                                                    readonly: true,
                                                    clearable: true,
                                                    placeholder:'1253',
                                                    disabled:true
                                                   }"
                                                   :options="{
                                                       humanMask: '########',
                                                       machineMask: '########',
                                                       empty:'',
                                                       applyAfter: false
                                                   }"
                                               >

                                               </v-text-field-integer>


                                           </v-col>
                                           <v-col
                                               cols="12"
                                               sm="3"
                                               md="3"
                                               xs="12"
                                           >
                                               <v-text-field-money
                                                        v-model="approvedSalary"
                                                        label="Salario aprobado"
                                                        :properties="{
                                                            prefix:'Q',
                                                            readonly: false,
                                                            disabled: false,
                                                            outlined: false,
                                                            clearable: true,
                                                            placeholder: 'Salario base',
                                                        }"
                                                    :options="{
                                                        humanMask: '###,###,##0.00',
                                                        machineMask: '########0.00',
                                                        empty:''
                                                    }"
                                               >

                                               </v-text-field-money>


                                           </v-col>
                                           <v-col
                                               cols="12"
                                               sm="3"
                                               md="3"
                                               xs="12"
                                           >
                                               <v-text-field-money
                                                        v-model="incentiveBonus"
                                                        label="Bono incentivo"
                                                        :properties="{
                                                            prefix:'Q',
                                                            readonly: false,
                                                            disabled: false,
                                                            outlined: false,
                                                            clearable: true,
                                                            placeholder: 'Bono incentivo',
                                                        }"
                                                    :options="{
                                                        humanMask: '###,###,##0.00',
                                                        machineMask: '########0.00',
                                                        empty:''
                                                    }"
                                               >

                                               </v-text-field-money>


                                           </v-col>
                                           <v-col
                                               cols="12"
                                               sm="3"
                                               md="3"
                                               xs="12"
                                           >
                                               <v-text-field-money
                                                        v-model="productivityBonus"
                                                        label="Bono productividad"
                                                        :properties="{
                                                            prefix:'Q',
                                                            readonly: false,
                                                            disabled: false,
                                                            outlined: false,
                                                            clearable: true,
                                                            placeholder: 'Bono productividad',
                                                        }"
                                                    :options="{
                                                        humanMask: '###,###,##0.00',
                                                        machineMask: '########0.00',
                                                        empty:''
                                                    }"
                                               >

                                               </v-text-field-money>


                                           </v-col>

                                           <v-col
                                               cols="12"
                                               sm="12"
                                               md="3"
                                               lg="3"
                                           >
                                               <div>
                                                   <v-select
                                                       item-text='name'
                                                       item-value="id"
                                                       v-model="workingDaySelected"
                                                       :items="workingDayListArray"
                                                       label="Seleccione una jornada"
                                                       hint="Jornadas"
                                                       :loading="loadingWorkingDay"
                                                   >
                                                   </v-select>
                                               </div>
                                           </v-col>

                                           <v-col
                                               cols="12"
                                               sm="12"
                                               md="3"
                                               lg="3"
                                           >
                                               <div>
                                                <v-switch
                                                    v-model="privateVacancy"
                                                    color="primary"
                                                    label="Vacante privada"
                                                    :value=true
                                                    hide-details
                                                    ></v-switch>
                                               </div>
                                           </v-col>
                                           <v-col
                                               cols="12"
                                               sm="12"
                                               md="3"
                                               lg="3"
                                           >
                                               <div>
                                                <v-switch
                                                    v-model="publicVacancy"
                                                    color="primary"
                                                    label="Vacante pública"
                                                    :value=true
                                                    hide-details
                                                    ></v-switch>
                                               </div>
                                           </v-col>

                                           <v-col
                                               cols="12"
                                               sm="12"
                                               md="12"
                                               lg="12"
                                           >
                                               <div>
                                                <label>Requerimientos del la plaza vacante</label>
                                                    <multiselect v-model="requirementJobSelected"
                                                        tag-placeholder="Requerimientos de la plaza"
                                                        placeholder="Buscar o agregar un requerimiento"
                                                        label="name" track-by="id"
                                                        :options="requirementJobArray"
                                                        :multiple="true"
                                                        :taggable="true"
                                                        @tag="addTag"
                                                        deselectLabel="Presione enter para remover"
                                                        selectLabel="Presione enter para seleccionar"
                                                        selectedLabel="Seleccionado"

                                                    ></multiselect>
                                               </div>
                                           </v-col>
                                       </v-row>

                                       <!-- Inicia comentarios -->


                                        <v-row v-if="approveStatus == 1">
                                            <v-col
                                                cols="12"
                                                sm="12"
                                                md="12"
                                                lg="12"
                                            >

                                                    <v-textarea
                                                            clearable
                                                            ref="commentApprove"
                                                            v-model="commentApprove"
                                                            label="Comentario de aprobación"
                                                            hint="Comentario de aprobación"
                                                            :counter="500"
                                                            maxlength="500"
                                                        >

                                                    </v-textarea>

                                            </v-col>
                                        </v-row>






                                        <v-row v-if="validationStatus == 1">
                                            <v-col
                                                cols="12"
                                                sm="12"
                                                md="12"
                                                lg="12"
                                            >

                                                    <v-textarea
                                                            clearable
                                                            ref="commentValidate"
                                                            v-model="commentValidate"
                                                            label="Comentario de validación"
                                                            hint="Comentario de validación"
                                                            :counter="500"
                                                            maxlength="500"
                                                        >

                                                    </v-textarea>

                                            </v-col>
                                        </v-row>







                                        <v-row>
                                            <v-col cols="12"
                                            sm="12"
                                            md="12"
                                            >

                                                <div class="row col-4 mt-5">
                                                        <div class="col-lg-6" v-if="waitResponseSave">
                                                            <div class="spinner-border" style="width: 2rem; height: 2rem;" role="status">
                                                                <span class="sr-only">Loading...</span>
                                                            </div>
                                                        </div>

                                                        <div class="col-lg-6" v-else>
                                                            <button type="button" class="btn btn-primary" @click="saveVacancy" v-if="action == 'Crear'"> <i class="fa fa-save"></i> Grabar </button>
                                                            <button type="button" class="btn btn-warning" @click="saveVacancy" v-else> <i class="fa fa-fresh"></i> Actualizar </button>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <button type="button" class="btn btn-danger" @click="cancel"> <i class="fa fa-ban"></i> Cancelar </button>
                                                        </div>
                                                </div>
                                            </v-col>
                                        </v-row>



                                        <!-- Finaliza comentarios -->

                                    </v-container>
                                </v-card>

                            </template>






                        </v-app>
                        <!--     Termina vuetify             -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>





<script>
import Vuetify from "vuetify";
import "vuetify/dist/vuetify.min.css";
import Swal from "sweetalert2/dist/sweetalert2";
import "sweetalert2/src/sweetalert2.scss";
import Integer from "../../../inputFormats/IntegerComponent";
import Money from "../../../inputFormats/MoneyComponent";
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.min.css'


export default{
    vuetify: new Vuetify(),
    data(){
        return{
            url: '/maintenance/vacancies/',
            urlOccupations: '/catalogs/occupation/',
            urlAcademicLevel: '/catalogs/academic-level/',
            urlWorkingDay: '/catalogs/working-days/',
            urlJobRequirment: '/catalogs/requirement/',
            urlCompanies: '/catalogs/company/',
            action:'Crear',
            isCreate:true,
            nameVacancy:'',
            descriptionVacancy:'',
            numberVacancies:'',
            numberFilled:'',
            publicVacancy:false,
            privateVacancy: false,
            additionalNote: '',
            approvedSalary: '',
            incentiveBonus: '',
            productivityBonus: '',
            active:false,
            commentValidate:'',
            commentApprove:'',
            occupationListArray:[],
            academicListArray:[],
            occupationSelected:0,
            academicLevelListArray:[],
            academicLevelSelected:0,
            workingDayListArray:[],
            workingDaySelected:0,
            requirementJobArray:[],
            requirementJobSelected:[],

            loadingName:false,
            loadingOccupation:false,
            loadingAcademicLevel:false,
            loadingDescription:false,
            loadingNumberVacancies:false,
            loadingWorkingDay:false,
            loadJobRequirements:false,
            loadingApprove:false,
            loadingValidate:false,
            additionalNoteLoading:false,
            approvedSalaryLoading:false,
            incentiveBonusLoading:false,
            productivityBonusLoading:false,
            commentValidateLoding:false,
            commentApproveLoding:false,
            approveStatus:0,
            validationStatus:0,
            waitResponseSave:false,
            companySelected:'',
            companyListArray:[],
            loadingAcademicLevel:false,
            loadingBaseSalrial:false,
            baseDisabled:false,
            vacancy: this.$attrs.vacancy,
            vacancyReqs: this.$attrs.reqs,
            loadingCompany:false,
            localCreate:'',
            idVacancy:0



        }


    },
    mounted(){
        this.occupationLists();
        this.academicLevelList();
        this.workingDayLists();
        this.jobRequirements();
        this.getCompanies();
        let localApprove    = localStorage.getItem("approveStatusVacancy");
        let localValidate   = localStorage.getItem("validateStatusVacancy");
        this.localCreate     = localStorage.getItem('createVacancy');

        this.approveStatus = localApprove;
        this.validationStatus = localValidate ;
        this.isCreate = this.localCreate;
        this.montedData();



    },
    methods:{

        montedData(){

            if(this.vacancy){
                this.localCreate = 2;
                this.isCreate = false
            };

            (this.localCreate == 1) ? this.action = 'Crear' : this.action = 'Actualizar';
            this.editFillFields(this.vacancy,this.vacancyReqs)

            console.log("is create",this.isCreate);
        },

        occupationLists(){

            this.loadingOccupation = true
            axios.get(this.urlOccupations+'list')
                .then((response) =>{
                   // console.log(response.data.data)
                    if(response.data.code == 200){
                        this.occupationListArray = response.data.data;
                        this.loadingOccupation = false;
                    }

                })

        },
        academicLevelList(){
            this.loadingAcademicLevel = true
            axios.get(this.urlAcademicLevel+'list')
                .then((response) =>{
                    //console.log(response.data.data)
                    if(response.data.code == 200){
                        this.academicLevelListArray = response.data.data;
                        this.loadingAcademicLevel = false;
                    }

                })
        },

        workingDayLists(){
            this.loadingWorkingDay = true
            axios.get(this.urlWorkingDay+'list')
                .then((response) =>{
                    //console.log(response.data.data)
                    if(response.data.code == 200){
                        this.workingDayListArray = response.data.data;
                        this.loadingWorkingDay = false;
                    }

                })
        },

        jobRequirements(){

            axios.get(this.urlJobRequirment+'list')
            .then((response) =>{
                //console.log(response.data.data)
                if(response.data.code == 200){
                    //console.log(response.data.data)
                    this.requirementJobArray = response.data.data;

                }

            })
        },

        addTag (newTag) {
            const tag = {
                name: newTag,
                id: newTag.substring(0, 2) + Math.floor((Math.random() * 10000000))
            }
            this.options.push(tag)
            this.value.push(tag)
        },

        cancel(){
           localStorage.clear();
           window.location.href = '/maintenance/vacancies'
        },

        saveVacancy(){
           console.log(this.publicVacancy, this.privateVacancy);
            this.waitResponseSave = true
            let urlProcess =  this.url+'store';
            let data;
            let vacancyprivate = (this.privateVacancy == null) ? false : true;
            let vacancyPublic  = (this.publicVacancy == null) ? false : true;
            data = {
                name:this.nameVacancy,
                description_vacancy: this.descriptionVacancy,
                number_vacancy_available: this.numberVacancies,
                number_filled_vacancies: this.numberFilled,
                public_vacancy: this.publicVacancy,
                private_vacancy: vacancyprivate,
                approved_salary: vacancyPublic,
                incentive_bonus: this.incentiveBonus,
                productivity_bonus: this.productivityBonus,
                occupation_id: this.occupationSelected,
                academic_level_id: this.academicLevelSelected,
                working_day_id: this.workingDaySelected,
                requirements: this.requirementJobSelected,
                company_id: this.companySelected
            }
            if(!this.isCreate){
                urlProcess = this.url+'update'
                data = {
                    id:this.idVacancy,
                    name:this.nameVacancy,
                    description_vacancy: this.descriptionVacancy,
                    number_vacancy_available: this.numberVacancies,
                    number_filled_vacancies: this.numberFilled,
                    public_vacancy:  vacancyPublic,
                    private_vacancy: vacancyprivate,
                    approved_salary: this.approvedSalary,
                    incentive_bonus: this.incentiveBonus,
                    productivity_bonus: this.productivityBonus,
                    occupation_id: this.occupationSelected,
                    academic_level_id: this.academicLevelSelected,
                    working_day_id: this.workingDaySelected,
                    comment_approve: this.commentApprove,
                    comment_validate: this.commentValidate,
                    requirements: this.requirementJobSelected,
                    company_id: this.companySelected
                }
            }

            axios.post(urlProcess, data)
                .then((response)=>{
                    this.waitResponseSave = false;
                    let respuesta = response.data;
                    console.log(response.data)
                    Swal.fire({
                        position: 'center',
                        icon: response.data.icon,
                        title: response.data.message,
                        showConfirmButton: false,
                        timer: 1500
                    }).finally(() => {
                       this.cancel();
                    })
            })
        },

        getCompanies(){

            this.loadingCompany = true
            axios.get(this.urlCompanies+'list')
            .then((response) =>{
                //console.log(response.data.data)
                if(response.data.code == 200){
                    console.log(response.data.data)
                    this.companyListArray = response.data.data;
                    this.loadingCompany = false

                }

            })
        },

        getBaseSalarial(idCompany){
            this.loadingBaseSalarial = true
            axios.get(`${this.urlCompanies}baseSalarial/${idCompany}`)
            .then((response) =>{
                //console.log(response.data.data)
                if(response.data.code == 200){
                    //console.log(response.data.data)
                    this.approvedSalary = response.data.data[0].base_salarial;
                    this.loadingBaseSalrial = false
                    this.baseDisabled = true

                }

            })
        },

        editFillFields(item, vacancyR){

            console.log("Vacancy",item);
           this.nameVacancy            = item.name.toUpperCase();
            this.occupationSelected     = item.occupation_id;
            this.academicLevelSelected  = item.academic_level_id;
            this.companySelected        = item.company_id;
            this.descriptionVacancy     = item.description_vacancy.toUpperCase();
            this.numberVacancies        = item.number_vacancy_available;
            this.numberFilled           = item.number_filled_vacancies;
            this.approvedSalary         = item.approved_salary;
            this.incentiveBonus         = item.incentive_bonus;
            this.productivityBonus      = item.productivity_bonus;
            this.workingDaySelected     = item.working_day_id;
            this.publicVacancy          = (item.public_vacancy  === 1) ? true : false;
            this.privateVacancy         = (item.private_vacancy === 1) ? true : false;
            this.requirementJobSelected = vacancyR
            this.idVacancy              = item.id
        }



    },

    //components:{ Vuetify }
    components:{ Vuetify, "v-text-field-integer": Integer, "v-text-field-money": Money, Multiselect }


}










</script>

