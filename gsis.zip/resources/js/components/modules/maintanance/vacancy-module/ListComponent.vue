<template>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-12 mt-3">
                <div class="card card-dark">
                    <div class="card-header">
                        Módulo - Plazas
                    </div>
                    <div class="card-body">
                        <v-app id="inspire">
                            <template>
                                <v-card>
                                    <v-container grid-list-md>
                                        <v-data-table
                                            :headers="headers"
                                            :items="VacancyArray"
                                            :items-per-page="10"
                                            class="elevation-1"
                                            :search="search"
                                            :footer-props="{
                                                showFirstLastPage: true,
                                                firstIcon: 'fas fa-angle-double-left',
                                                lastIcon: 'fas fa-angle-double-right',
                                                prevIcon: 'fas fa-angle-left',
                                                nextIcon: 'fas fa-angle-right',
                                                    'items-per-page-text':'Registros por página'
                                                }"
                                        >
                                            <template v-slot:top>

                                                <v-toolbar flat color="white">


                                                    <button type="button" class="btn btn-primary" @click="callCreateForm"> <i class="fas fa-plus-circle"></i> Crear</button>
                                                    <!--                                                    <button type="button" class="btn btn-primary" @click="actualizar" v-else> <i class="fas fa-plus-circle"></i> Actualizar</button>-->

                                                    <v-spacer></v-spacer>
                                                    <v-text-field v-model="search" label="Buscar" single-line hide-details></v-text-field>


                                                    <!-- Aqui van los dialogos    -->

                                                </v-toolbar>
                                            </template>

                                            <template v-slot:item.name="{item}">
                                                {{ item.name.toUpperCase() }}
                                            </template>

                                            <template v-slot:item.private_vacancy="{item}">
                                                <div v-if="item.private_vacancy === 1"> ACTIVA  </div>
                                                <div v-else> INACTIVA  </div>
                                            </template>

                                            <template v-slot:item.public_vacancy="{item}">
                                                <div v-if="item.public_vacancy === 1"> ACTIVA  </div>
                                                <div v-else> INACTIVA  </div>
                                            </template>

                                            <template v-slot:item.active="{item}">
                                                <div v-if="item.active === 1"> ACTIVO  </div>
                                                <div v-else> INACTIVO  </div>
                                            </template>

                                            <template v-slot:item.status.name="{item}">

                                                {{ item.status.name.toUpperCase() }}

                                            </template>







                                            <template v-slot:item.actions="{ item }">
                                                <a class="btn btn-dark btn-sm pointerHand" @click="copyLink('/job-application/'+item.slug)" id="copyVacancy">
                                                    Copiar link
                                                    <v-icon
                                                        small
                                                        class="mr-2"
                                                        color="white"

                                                    >
                                                        far fa-copy
                                                    </v-icon>

                                                </a>
                                                <a class="btn btn-warning btn-sm pointerHand" @click="editVacancy(item)">
                                                    Editar
                                                    <v-icon
                                                        small
                                                        class="mr-2"
                                                        color="white"

                                                    >
                                                        fas fa-edit
                                                    </v-icon>

                                                </a>

                                                <a class="btn btn-danger btn-sm pointerHand" @click="deleteVacancy(item)">
                                                    Eliminar
                                                    <v-icon
                                                        small
                                                        class="mr-2"
                                                        color="white"

                                                    >
                                                        fas fa-trash-alt
                                                    </v-icon>

                                                </a>





                                            </template>
                                            <template v-slot:no-data>
                                                <v-alert :value="true" color="error" icon="fas fa-exclamation-triangle" class="mt-2">
                                                    No hay registros para mostrar
                                                </v-alert>
                                            </template>
                                        </v-data-table>
                                    </v-container>
                                </v-card>
                            </template>
                        </v-app>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import Vuetify from 'vuetify';
import "vuetify/dist/vuetify.min.css";
import Swal from "sweetalert2/dist/sweetalert2";
import "sweetalert2/src/sweetalert2.scss";
import Integer from "../../../inputFormats/IntegerComponent";
import Money from "../../../inputFormats/MoneyComponent";
import Clipboard from 'clipboard';

    export default {
        vuetify: new Vuetify(),
        data() {
            return {
                search:'',
                headers:[],
                url: '/maintenance/vacancies/',
                VacancyArray:[],
                isNew: true,
                dialogTitle:'',
                name:'',
                dialogVacancy:false,
                id:0,

            }
        },
        mounted() {
            this.cargarHeader();
        },
        methods: {

        copyLink(slug) {
                const fullLink = `https://${window.location.host}${slug}`;

                navigator.clipboard.writeText(fullLink)
                    .then(() => {

                        this.toastMessage('success', 'Enlace copiado al portapapeles')
                    })
                    .catch(() => {

                        this.toastMessage('error', 'Error al copiar el enlace')
                    });


            },







            cargarHeader(){
                this.headers = [
                    { text: "NOMBRE", align: "left", value: 'name' },
                    { text: "PLAZA INTERNA", align: "left", value: 'private_vacancy' },
                    { text: "PLAZA EXTERNA", align: "left", value: 'public_vacancy' },
                    { text: "ESTADO", align: "left", value: 'active' },
                    { text: "PROCESO", align: "left", value: 'status.name' },
                    { text: "ACCIONES", align: "center", value: 'actions', sortable: false },
                ]

                this.list()

            },

            list(){

                let useURL = this.url+'list';
                axios.get(useURL).then(response => {
                    //console.log(response.data.data);
                    this.VacancyArray = response.data.data
                })
            },


          deleteVacancy(item){
                //console.log(item.id);
                let processDelete;
                Swal.fire({
                    title: '¿Está seguro de eliminar?',
                    text: "¡No podrás revertir esto!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    cancelButtonText:'Cancelar',
                    confirmButtonText: 'Sí, eliminar'
                }).then((result) => {
                    if (result.isConfirmed) {
                        processDelete = this.deletePocess(item.id);
                        Swal.fire(
                            '¡Eliminado!',
                            'La vacante se ha eliminado correctamente.',
                            'success'
                        ).finally(() => {
                             this.clear();
                        })

                    }
                })
            },

            deletePocess(item){
                let useURL = this.url+'delete';
                axios.post(useURL, {
                     id: item
                    }).then(response => {
                    console.log(response.data);
                    if(response.data.code == 200){
                        return true;
                    }else{
                        return false;
                    }
                })
            },

            close(){
                this.clear();
            },

            create(){
                let useURL = this.url+'store';
                axios.post(useURL, {
                    name: this.name.toLocaleLowerCase()
                }).then(response => {
                    console.log(response.data);
                    if(response.data.code == 200)
                    this.dialogVacancy = false;
                    this.name = '';

                    Swal.fire({
                        position: 'top-end',
                        icon: 'success',
                        title: response.data.message,
                        showConfirmButton: false,
                        timer: 1500
                    }).finally(() => {
                        this.clear();
                    })
                })
            },

            newLang(){
                this.dialogTitle = 'Nuevo Idioma';
                this.dialogVacancy = true;
                this.isNew = true;
            },

            clear(){
              this.list();
              this.name = '';
              this.dialogVacancy = false;
              this.isNew = true;
            },

            editVacancy(item){
                //console.log(item)
                let urlEdit = `${this.url}edit/${item.id}`;
                this.id             = item.id;
                this.name           = item.name;
                this.dialogTitle    = 'Editar plaza';
                this.dialogVacancy = true;
                this.isNew          = false;

                localStorage.setItem('items', JSON.stringify(item));
                localStorage.setItem('createVacancy', this.isNew);
                console.log(urlEdit);
                //window.location.open()
                window.open(urlEdit,'_self');


            },


            updateVacancy(){
                let useURL = this.url+'update';
                axios.post(useURL, {
                    id: this.id,
                    name: this.name.toLocaleLowerCase()
                }).then(response => {
                    console.log(response.data);
                    if(response.data.code == 200)
                    this.dialogVacancy = false;
                    this.name = '';

                    Swal.fire({
                        position: 'center',
                        icon: 'success',
                        title: response.data.message,
                        showConfirmButton: false,
                        timer: 1500
                    }).finally(() => {
                        this.clear();
                    })
                })
            },

            callCreateForm(){
                localStorage.setItem('createVacancy', 1);
                localStorage.setItem('approveStatusVacancy',0);
                localStorage.setItem('validateStatusVacancy',0);
                window.location.href='/maintenance/vacancies/create';
            },

            vacancyRoute(item){
                //window.location.href='/job-application/'+item.slug;
                window.open('/job-application/'+item.slug);
            },


            vacancyFormCopy(slug) {
                // Build the URL with the slug
                const urlWithSlug = `http://${window.location.host}/job-application/${slug}`;

                //console.log(urlWithSlug);

                // Copy the URL to the clipboard
                navigator.clipboard.writeText(urlWithSlug)
                    .then(() => {
                        this.copiedUrl = urlWithSlug;
                    })
                    .catch((err) => {
                        console.error("Error copying to clipboard: ", err);
                    });
            },

            toastMessage(icon, message){
               const Toast =  Swal.mixin({
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.onmouseenter = Swal.stopTimer;
                    toast.onmouseleave = Swal.resumeTimer;
                }
                });
                Toast.fire({
                icon: icon,
                title: message
                });
            },

            vacancyEdit(item){
                console.log(item)
            }





        },
        components: {Vuetify, "v-text-field-integer": Integer, "v-text-field-money": Money}
    }
</script>

