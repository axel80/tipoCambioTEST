<template>
    <div class="container-fluid mt-3 mb-5">
        <div class="row">
            <v-app id="inspire">
                <h1>Review</h1>
            </v-app>

         </div>
    </div>
</template>

<script>
import Vuetify from "vuetify";
import "vuetify/dist/vuetify.min.css";
import Swal from "sweetalert2/dist/sweetalert2";
import "sweetalert2/src/sweetalert2.scss";

export default {
    vuetify: new Vuetify(),
    data(){
        return{

        }
    },
    computed:{

    },
    watch:{

    },
    mounted(){

    },
    methods:{

        message(message, icon, title) {
            Swal.fire({
                position: 'center',
                icon: icon,
                title: title,
                html: message,
                showConfirmButton: false,
                timer: 3500
            })
        },

        toastMessage(icon, message){
               const Toast =  Swal.mixin({
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.onmouseenter = Swal.stopTimer;
                    toast.onmouseleave = Swal.resumeTimer;
                }
                });
                Toast.fire({
                icon: icon,
                title: message
                });
            },

            messageProcessedInfo(){
                let timerInterval;
                Swal.fire({
                    title: "Mensaje del sistema",
                    html: "Un momento por favor se esta procesando la información",
                    timer: 3500,
                    timerProgressBar: false,
                    didOpen: () => {
                        Swal.showLoading();
                        const timer = Swal.getPopup().querySelector("b");
                        timerInterval = setInterval(() => {
                            `${Swal.getTimerLeft()}`;
                        }, 100);
                    },
                    willClose: () => {
                        clearInterval(timerInterval);

                    }
                    }).then((result) => {
                        /* Read more about handling dismissals below */
                        if (result.dismiss === Swal.DismissReason.timer) {
                        // console.log("I was closed by the timer");
                            this.toastMessage('warning', 'Puede continuar con la solicitud')
                        }
                    });
                },

                confirmationMessage(icon, title, htmlText, routeReturn){
                    Swal.fire({
                        title: title,
                        html: htmlText,
                        icon: icon,
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        cancelButtonText: 'Cancelar',
                        confirmButtonText: 'Sí, Salir'
                    }).then((result) => {
                        if (result.isConfirmed) {

                            window.open(`/${routeReturn}`, '_self');

                        }
                    })
                }
    },
    components:{Vuetify}
}


</script>
