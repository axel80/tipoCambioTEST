<template>
    <div class="container-fluid mt-3 mb-5">
        <div class="row justify-content-center">
            <div class="col-md-12 mt-3">
                <div class="card card-dark">
                    <div class="card-header">
                        <h1 class="title">Solicitud # {{ idApl }}</h1>
                    </div>
                </div>

                <div class="card-body">
                    <v-app id="inspire">
                        <v-row class="container">
                            <div class="col-sm-4 mt-2">

                                <div class="card card-primary">
                                    <div class="card-header">
                                        <h2 class="card-title">Datos Identidad</h2>
                                    </div>
                                    <div class="card-body">
                                        <div class="text-center">
                                            <v-row>
                                                <v-col cols="12"
                                                        md="12"
                                                        xl="12"
                                                >
                                                    <v-avatar
                                                        size="148"
                                                    >
                                                        <img
                                                            :src="`${uri}`"
                                                            alt="John"
                                                            size="148"
                                                        >
                                                    </v-avatar>
                                                </v-col>
                                            </v-row>
                                        </div>
                                        <v-row>
                                            <v-col
                                                cols="12"
                                                md="12"
                                                sm="12"
                                                xs="12"
                                            >
                                                <label for="names" class="text-uppercase">Nombres:</label>
                                                <span class="text-uppercase">{{ fullName }}</span>

                                            </v-col>

                                            <v-col
                                                cols="12"
                                                md="6"
                                                sm="6"
                                                xs="6"
                                            >
                                                <label for="names" class="text-uppercase">DPI:</label>
                                                <span class="text-uppercase">{{ personalId }}</span>

                                            </v-col>

                                            <v-col
                                                cols="12"
                                                md="6"
                                                sm="6"
                                                xs="6"
                                            >
                                                <label for="names" class="text-uppercase"> nit:</label>
                                                <span class="text-uppercase">{{ taxId }}</span>

                                            </v-col>
                                            <v-col
                                                cols="12"
                                                md="6"
                                                sm="6"
                                                xs="6"
                                            >
                                                <label for="names" class="text-uppercase"> fecha de nac.:</label>
                                                <span class="text-uppercase">{{ birthDay.toLocaleString() }}</span>

                                            </v-col>
                                        </v-row>


                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-8 mt-2 card card-blue" >

                                <template>
                                    <v-card>
                                        <v-tabs
                                            v-model="tab"
                                            background-color="primary"
                                            dark
                                        >
                                        <v-tab

                                            :key="1"
                                        >
                                            Ubicaciones
                                        </v-tab>
                                        <v-tab

                                            :key="2"
                                        >
                                            Historial Laboral
                                        </v-tab>
                                        <v-tab

                                            :key="3"
                                        >
                                            Datos familiares
                                        </v-tab>
                                        <v-tab

                                            :key="4"
                                        >
                                            Servicios/Armas
                                        </v-tab>

                                        <v-tab

                                            :key="5"
                                        >
                                            Acreditaciones
                                        </v-tab>
                                        <v-tab

                                            :key="6"
                                        >
                                            Referencias laborales
                                        </v-tab>
                                        <v-tab

                                            :key="7"
                                        >
                                            Referencias personales
                                        </v-tab>
                                        <v-tab

                                            :key="8"
                                        >
                                            Información adicional
                                        </v-tab>
                                        <v-tab

                                            :key="9"
                                        >
                                            Requerimientos adicionales
                                        </v-tab>




                                        </v-tabs>

                                        <v-tabs-items v-model="tab">
                                            <v-tab-item

                                                :key="1"
                                            >
                                                <v-card flat>
                                                <v-card-text>***** Direcciones *****</v-card-text>
                                                </v-card>
                                            </v-tab-item>
                                            <v-tab-item

                                                :key="2"
                                            >
                                                <v-card flat>
                                                <v-card-text>***** Laboral *****</v-card-text>
                                                </v-card>
                                            </v-tab-item>
                                            <v-tab-item

                                                :key="3"
                                            >
                                                <v-card flat>
                                                <v-card-text>***** Familiares *****</v-card-text>
                                                </v-card>
                                            </v-tab-item>
                                            <v-tab-item

                                                :key="4"
                                            >
                                                <v-card flat>
                                                <v-card-text>***** Servicios Armas *****</v-card-text>
                                                </v-card>
                                            </v-tab-item>
                                            <v-tab-item

                                                :key="5"
                                            >
                                                <v-card flat>
                                                <v-card-text>***** Acreditaciones *****</v-card-text>
                                                </v-card>
                                            </v-tab-item>
                                            <v-tab-item

                                                :key="6"
                                            >
                                                <v-card flat>
                                                <v-card-text>***** Referencias laborales *****</v-card-text>
                                                </v-card>
                                            </v-tab-item>
                                            <v-tab-item

                                                :key="7"
                                            >
                                                <v-card flat>
                                                <v-card-text>***** Referencias personales *****</v-card-text>
                                                </v-card>
                                            </v-tab-item>
                                            <v-tab-item

                                                :key="8"
                                            >
                                                <v-card flat>
                                                <v-card-text>***** Información adicional *****</v-card-text>
                                                </v-card>
                                            </v-tab-item>
                                            <v-tab-item

                                                :key="9"
                                            >
                                                <v-card flat>
                                                <v-card-text>***** Requerimientos *****</v-card-text>
                                                </v-card>
                                            </v-tab-item>

                                        </v-tabs-items>
                                    </v-card>
                                </template>


                            </div>

                            <div class="col-sm-12 mt-2">
                                <div class="card card-blue">

                                    <div class="card-body row">
                                        <div class="col-md-3">
                                            <button type="button" class="btn btn-primary" @click="regresar()"><i class="fas fa-arrow-left"></i> Regresar</button>
                                        </div>
                                        <div class="col-md-3">
                                            <button type="button" class="btn btn-primary"><i class="fas fa-scroll"></i> Entrevista</button>
                                        </div>

                                        <div class="col-md-6 row">

                                            <div class="col-md-6 form-group">
                                                <v-select item-text='name' item-value="id"
                                                    v-model="interviewSelected" :items="interviewArray"
                                                    label="Asignar para entrevista"
                                                    hint="Seleccione un usuario"
                                                    >
                                                </v-select>
                                            </div>
                                            <div class="col-md-6">
                                                <button type="button" class="btn btn-dark"><i class="fas fa-arrow-circle-right"></i> Asignar</button>
                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </div>
                        </v-row>

                    </v-app>
                </div>
            </div>
         </div>
    </div>
</template>

<script>
import Vuetify from "vuetify";
import "vuetify/dist/vuetify.min.css";
import Swal from "sweetalert2/dist/sweetalert2";
import "sweetalert2/src/sweetalert2.scss";
import { computeStyles } from "@popperjs/core";
import axios from "axios";

export default {
    vuetify: new Vuetify(),
    data(){
        return{

            idApl: '',
            tab: null,
            uri: '/storage/sistem/img/default-user.png',
            url: '/transactions-rh/applications/',
            fullName:'',
            personalId:'',
            taxId:'',
            igssId:'',
            irtraId:'',
            birthDay:'',
            interviewSelected: '',
            interviewArray: [],

        }
    },
    computed:{

    },
    watch:{

    },
    mounted(){
        this.getAplData();
        this.getUsersInterview();

    },
    methods:{

        message(message, icon, title) {
            Swal.fire({
                position: 'center',
                icon: icon,
                title: title,
                html: message,
                showConfirmButton: false,
                timer: 3500
            })
        },

        toastMessage(icon, message){
               const Toast =  Swal.mixin({
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.onmouseenter = Swal.stopTimer;
                    toast.onmouseleave = Swal.resumeTimer;
                }
                });
                Toast.fire({
                icon: icon,
                title: message
                });
        },

        messageProcessedInfo(){
            let timerInterval;
            Swal.fire({
                title: "Mensaje del sistema",
                html: "Un momento por favor se esta procesando la información",
                timer: 3500,
                timerProgressBar: false,
                didOpen: () => {
                    Swal.showLoading();
                    const timer = Swal.getPopup().querySelector("b");
                    timerInterval = setInterval(() => {
                        `${Swal.getTimerLeft()}`;
                    }, 100);
                },
                willClose: () => {
                    clearInterval(timerInterval);

                }
                }).then((result) => {
                    /* Read more about handling dismissals below */
                    if (result.dismiss === Swal.DismissReason.timer) {
                    // console.log("I was closed by the timer");
                        this.toastMessage('warning', 'Puede continuar con la solicitud')
                    }
                });
        },

        confirmationMessage(icon, title, htmlText, routeReturn){
            Swal.fire({
                title: title,
                html: htmlText,
                icon: icon,
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                cancelButtonText: 'Cancelar',
                confirmButtonText: 'Sí, Salir'
            }).then((result) => {
                if (result.isConfirmed) {

                    window.open(`/${routeReturn}`, '_self');

                }
            })
        },

        getAplData(){

            this.idApl = localStorage.getItem('aplId');
            if(!this.idApl){
                history.back();
            }
            let url = `${this.url}get/${this.idApl}`

            this.getApl(url);
        },

        getApl(url){
            axios.get(url).then((response) => {
                console.log(response.data.data)
                this.fullName   =  response.data.fullName
                this.personalId =  response.data.data.document_dpi
                this.taxId      =  response.data.data.tax_number
                this.birthDay   = this.getBirth(response.data.data.birth_date);

            });
        },

        regresar(){
            localStorage.removeItem('aplId')
            history.back();
        },

        getBirth: (date)=> {
            let splitDate   = date.split("-");
            let dayDate     = splitDate[2];
            let monthDate   = splitDate[1];
            let yearDate    = splitDate[0];
            let fullDate = `${dayDate}/${monthDate}/${yearDate}`;


            return fullDate
        },
        getUsersInterview(){
            axios.get(`${this.url}users-list`).then((response) => {
                this.interviewArray = response.data.data
            })
        }
    },
    components:{Vuetify}
}


</script>
