<template>
    <div class="container-fluid mt-3 mb-5">
        <div class="row justify-content-center">
            <div class="col-md-12 mt-3">
                <div class="card card-dark">
                    <div class="card-header">
                        Lista de aplicaciones de trabajo
                    </div>
                    <div class="card-body container-fluid">
                        <v-app id="inspire">
                            <h1>Postulantes</h1>
                            <template>
                                <v-card>
                                    <v-container grid-list-lg>
                                        <v-data-table
                                            :headers="headers"
                                            :items="listArray"
                                            :items-per-page="10"
                                            class="elevation-1"
                                            :search="search"
                                            :footer-props="{
                                                showFirstLastPage: true,
                                                firstIcon: 'fas fa-angle-double-left',
                                                lastIcon: 'fas fa-angle-double-right',
                                                prevIcon: 'fas fa-angle-left',
                                                nextIcon: 'fas fa-angle-right',
                                                    'items-per-page-text':'Registros por página'
                                                }"
                                        >

                                            <template v-slot:top>

                                                        <v-dialog
                                                                v-model="dialogNotes"
                                                                max-width="750"
                                                                persistent
                                                                transition="dialog-bottom-transition"
                                                            >
                                                            <v-card>
                                                                 <v-toolbar
                                                                    color="primary"
                                                                    dark
                                                                    >Rechazar solicitud laboral Motivo:</v-toolbar>

                                                                    <v-card-text>

                                                                        <v-container fluid>
                                                                            <v-row>

                                                                                <v-col
                                                                                    cols="12"
                                                                                    sm="12"
                                                                                    md="12"
                                                                                >
                                                                                <v-select item-text='text' item-value="id"
                                                                                    v-model="statusAppSelected" :items="statusAppArr"
                                                                                    label="Enviar a lista (Obligatorio)"
                                                                                    hint="Enviar a lista"
                                                                                    :loading="loadingList"
                                                                                    >
                                                                                </v-select>
                                                                                </v-col>

                                                                                <v-col
                                                                                    cols-="12"
                                                                                    sm="12"
                                                                                    md="12"
                                                                                >
                                                                                <v-container fluid>
                                                                                    <v-textarea
                                                                                    v-model="textNote"
                                                                                    autocomplete="Motivo"
                                                                                    label="Motivo"
                                                                                    ></v-textarea>
                                                                                </v-container>
                                                                                </v-col>

                                                                            </v-row>
                                                                        </v-container>

                                                                    </v-card-text>

                                                                    <v-card-actions>
                                                                        <v-spacer></v-spacer>

                                                                        <div class="row">
                                                                            <div class="col-lg-6">
                                                                                <button
                                                                                    class="btn btn-success mr-2"
                                                                                    @click="rechazo()"
                                                                                >
                                                                                <i class="fas fa-papper-plane"></i>
                                                                                    Rechazar
                                                                                </button>

                                                                            </div>


                                                                            <div class="col-lg-6">
                                                                                <button
                                                                                    class="btn btn-danger"
                                                                                    @click="cancelarRechazo()"

                                                                                >
                                                                                <i class="fas fa-times-circle"></i>
                                                                                    Cancelar
                                                                                </button>
                                                                            </div>

                                                                        </div>



                                                                        <v-spacer></v-spacer>

                                                                    </v-card-actions>
                                                            </v-card>
                                                        </v-dialog>



                                                <v-toolbar flat color="white">

                                                    <v-spacer></v-spacer>
                                                   <v-text-field v-model="search" label="Buscar" single-line hide-details></v-text-field>

                                                </v-toolbar>
                                            </template>

                                            <template v-slot:item.full_name="{item}">
                                                <small>{{ item.full_name.toUpperCase() }}</small>
                                            </template>

                                            <template v-slot:item.vacancy_name="{item}">
                                                <small class="text-uppercase text-sm-start">{{ item.vacancy_name}}</small>
                                            </template>

                                            <template v-slot:item.personal_email="{ item }">
                                                <small><a href="mailto:`${item.personal_email}`">{{ item.personal_email }}</a></small>
                                            </template>

                                            <template v-slot:item.status_employee="{ item }">
                                                <v-chip
                                                    :color="item.color"
                                                    dark
                                                >
                                                   <small> {{ item.status_employee }} </small>

                                                </v-chip>
                                            </template>

                                            <template v-slot:item.actions="{ item }">

                                                <a class="btn btn-primary btn-sm pointerHand" title="Analizar solicitud" @click="analisisApl(item)" :disabled="isDisabled">
                                                    Analizar
                                                    <v-icon
                                                        small
                                                        class="mr-2"
                                                        color="white"

                                                    >
                                                        far fa-eye
                                                    </v-icon>

                                                </a>

                                                <a class="btn btn-danger btn-sm pointerHand" title="Rechazar solicitud" @click="rechazarSolicitud(item)">
                                                    Rechazar
                                                    <v-icon
                                                        small
                                                        class="mr-2"
                                                        color="white"

                                                    >
                                                        fas fa-window-close
                                                    </v-icon>

                                                </a>





                                            </template>

                                            <template v-slot:no-data>
                                                <v-alert :value="true" color="error" icon="fas fa-exclamation-triangle" class="mt-2">
                                                    No hay registros para mostrar
                                                </v-alert>
                                            </template>

                                        </v-data-table>
                                    </v-container>
                                </v-card>
                            </template>

                        </v-app>
                    </div>
                </div>
            </div>
         </div>
    </div>
</template>

<script>
import Vuetify from "vuetify";
import "vuetify/dist/vuetify.min.css";
import Swal from "sweetalert2/dist/sweetalert2";
import "sweetalert2/src/sweetalert2.scss";

export default {
    vuetify: new Vuetify(),
    data(){
        return{
            headers:[],
            url:'/transactions-rh/applications/',
            listArray:[],
            search:'',
            textNote:'',
            dialogNotes:false,
            aplId: 0,
            statusAppSelected:'',
            statusAppArr:[
                {'id': 'LN', 'text': "Lista en negra"},
                {'id': 'LE', 'text': "Lista en espera"},
            ],
            loadingList:false,
            isDisabled:true,



        }
    },
    computed:{

    },
    watch:{

    },
    mounted(){
        this.loadHeader();
    },
    methods:{

        loadHeader(){
            this.headers = [
                    { text: "POSTULANTE", align: "left", value: 'full_name' },
                    { text: "CORREO", align: "left", value: 'personal_email' },
                    { text: "TELEFONO", align: "left", value: 'personal_mobile_number' },
                    { text: "PLAZA QUE APLICA", align: "left", value: 'vacancy_name' },
                    { text: "ESTADO", align: "center", value: 'status_employee' },
                    { text: "ACCIONES", align: "center", value: 'actions', sortable: false },
                ]

                this.list()
        },

        list(){
            axios.get(`${this.url}list`)
            .then((response)=>{
                console.log(response.data.data)
                this.listArray = response.data.data
            });
        },

        message(message, icon, title) {
            Swal.fire({
                position: 'center',
                icon: icon,
                title: title,
                html: message,
                showConfirmButton: false,
                timer: 3500
            })
        },

        toastMessage(icon, message){
               const Toast =  Swal.mixin({
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.onmouseenter = Swal.stopTimer;
                    toast.onmouseleave = Swal.resumeTimer;
                }
                });
                Toast.fire({
                icon: icon,
                title: message
                });
        },

        messageProcessedInfo(){
            let timerInterval;
            Swal.fire({
                title: "Mensaje del sistema",
                html: "Un momento por favor se esta procesando la información",
                timer: 3500,
                timerProgressBar: false,
                didOpen: () => {
                    Swal.showLoading();
                    const timer = Swal.getPopup().querySelector("b");
                    timerInterval = setInterval(() => {
                        `${Swal.getTimerLeft()}`;
                    }, 100);
                },
                willClose: () => {
                    clearInterval(timerInterval);

                }
                }).then((result) => {
                    /* Read more about handling dismissals below */
                    if (result.dismiss === Swal.DismissReason.timer) {
                    // console.log("I was closed by the timer");
                        this.toastMessage('warning', 'Puede continuar con la solicitud')
                    }
                });
        },

        confirmationMessage(icon, title, htmlText, routeReturn){
            Swal.fire({
                title: title,
                html: htmlText,
                icon: icon,
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                cancelButtonText: 'Cancelar',
                confirmButtonText: 'Sí, Salir'
            }).then((result) => {
                if (result.isConfirmed) {

                    window.open(`/${routeReturn}`, '_self');

                }
            })
        },

        rechazarSolicitud(item){
            console.log(item)
            this.loadingList = true
            setInterval(()=>{
                this.loadingList = false
            },1500)

            this.textNote = `Rechazo de solicitud: # ${item.id} a nombre de:  ${item.full_name.toUpperCase()} \n`
            this.dialogNotes = true;
            this.aplId = item.id;

        },

        cancelarRechazo(){
            this.loadingList = false;
            this.dialogNotes = false;
            this.textNote= '';
        },

        rechazo(){

            let uri = `${this.url}rejected`;
            let data = {
                solId: this.aplId,
                status_application: this.statusAppSelected,
                note: this.textNote,
                type:1
            }
            axios.post(uri,data).then((response)=>{

                if(response.data.code === 200){

                    this.toastMessage('success', `Solicitud rechazada enviada a la lista `);
                }
            }).finally(()=>{

                this.toastMessage("success", "Rechazado");
                this.dialogNotes = false;
                this.textNote='';
                this.statusAppSelected='';
                this.list();
            })

        },
        analisisApl(item){
            window.location.href="/transactions-rh/applications/show";
            localStorage.setItem('aplId', item.id);
        }
    },
    components:{Vuetify}
}


</script>
