<template>
    <div class="container-fluid mt-3 mb-5">
        <div class="row">
            <v-app id="inspire">
                <v-stepper v-model="e1">
                    <v-row class="mt-2 ml-2">
                        <v-col cols="12"
                            md="12">
                            <h1 class="title">{{ vacancy[0].company.full_name }}</h1>
                        </v-col>
                        <v-col cols="12"
                            md="6"
                            sm="6">
                            <p>NOMBRE DEL POSTULANTE: {{ fullName.toUpperCase() }}</p>
                        </v-col>

                        <v-col cols="12"
                            md="6"
                            sm="6">
                            <p>EDAD : {{ (myAge < 18) ? '' : myAge }}</p>
                        </v-col>

                    </v-row>
                    <v-stepper-header>
                        <v-stepper-step
                            :complete="e1 > 1"
                            step="1"
                        >

                        </v-stepper-step>

                        <v-stepper-step
                            :complete="e1 > 2"
                            step="2"
                        >

                        </v-stepper-step>

                        <v-stepper-step
                            :complete="e1 > 3"
                            step="3">

                        </v-stepper-step>

                        <v-stepper-step
                            :complete="e1 > 4"
                            step="4">

                        </v-stepper-step>

                        <v-stepper-step
                            :complete="e1 > 5"
                            step="5">

                        </v-stepper-step>

                        <v-stepper-step
                            :complete="e1 > 6"
                            step="6">

                        </v-stepper-step>

                        <v-stepper-step
                            :complete="e1 > 7"
                            step="7">

                        </v-stepper-step>

                        <v-stepper-step
                            :complete="e1 > 8"
                            step="8">

                        </v-stepper-step>

                        <v-stepper-step
                            :complete="e1 > 9"
                            step="9">

                        </v-stepper-step>

                        <v-stepper-step
                            :complete="e1 > 10"
                            step="10">

                        </v-stepper-step>

                        <v-stepper-step
                            :complete="e1 > 11"
                            step="11">

                        </v-stepper-step>

                        <v-stepper-step
                            :complete="e1 > 12"
                            step="12">

                        </v-stepper-step>

                        <v-stepper-step
                            :complete="e1 > 13"
                            step="13">

                        </v-stepper-step>

                    </v-stepper-header>

                    <v-stepper-items>
                        <v-stepper-content step="1">
                            <v-card
                            class="mb-12"
                            color="white lighten-5"
                            height="auto"

                            >
                            <div class="container-fluid px-12">
                                <h2 class="title">IDENTIFICACIONES</h2>
                                <v-row>
                                    <v-col cols="12" xs="12" sm="3" md="3">
                                        <v-text-field-integer v-model="employeeId"
                                            label="DPI (Obligatorio)" hint="DPI (Obligatorio)"
                                            :counter="13" :properties="{
                                                readonly: false,
                                                clearable: true,
                                                placeholder: '1234567890101'
                                            }" :options="{
                                                    humanMask: '#############',
                                                    machineMask: '#############',
                                                    empty: '',
                                                    applyAfter: false
                                                }" @blur="validateIdentityDpi(employeeId)">

                                        </v-text-field-integer>
                                        <div class="text-red"
                                            v-if="employeeId.length === 0 || employeeId.length < 13">
                                            <sub> {{ errorDPI }} </sub></div>

                                    </v-col>

                                    <v-col cols="12" xs="12" sm="3" md="3">
                                            <v-menu ref="expirationDpiDateModal" v-model="expirationDpiDateModal"
                                                :close-on-content-click="false"
                                                transition="scale-transition" offset-y max-width="290px"
                                                min-width="auto">
                                                <template v-slot:activator="{ on, attrs }">
                                                    <v-text-field v-model="expirationDpiDateFormatted"
                                                        label="Fecha vencimiento DPI"
                                                        hint=" Fecha vencimiento DPI" persistent-hint
                                                        prepend-icon="fas fa-calendar" v-bind="attrs"
                                                        @blur="expirationDpiDate = parseDate(expirationDpiDateFormatted)"
                                                        v-on="on" ref="expirationDpiDate"></v-text-field>
                                                </template>
                                                <v-date-picker v-model="expirationDpiDate" no-title
                                                    @input="expirationDpiDateModal = false" locale="es-ES"
                                                    next-icon="fas fa-angle-right"
                                                    prev-icon="fas fa-angle-left"></v-date-picker>
                                            </v-menu>
                                    </v-col>

                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-text-field
                                            ref="employeeTaxId"
                                            v-model="employeeTaxId"
                                            label="NIT" hint="NIT"
                                            :counter="13"
                                            maxlength="13"
                                            @blur="validateTaxId(employeeTaxId)"
                                        >

                                        </v-text-field>
                                        <div class="text-red" v-if="employeeTaxId.length === 0">
                                            <sub> {{ errorTax }} </sub></div>

                                    </v-col>

                                    <v-col cols="12" xs="12" sm="3" md="3" >
                                        <v-text-field ref="passportId" v-model="passportId"
                                            label="Pasaporte" hint="Pasaporte" :counter="13"
                                            maxlength="13">

                                        </v-text-field>

                                    </v-col>
                                    <v-col cols="12" xs="12" sm="3" md="3">
                                            <v-menu ref="expirationPassportDateModal" v-model="expirationPassportDateModal"
                                                :close-on-content-click="false"
                                                transition="scale-transition" offset-y max-width="290px"
                                                min-width="auto">
                                                <template v-slot:activator="{ on, attrs }">
                                                    <v-text-field v-model="expirationPassportDateFormatted"
                                                        label="Fecha vencimiento pasaporte"
                                                        hint=" Fecha vencimiento pasaporte" persistent-hint
                                                        prepend-icon="fas fa-calendar" v-bind="attrs"
                                                        @blur="expirationPassportDate = parseDate(expirationPassportDateFormatted)"
                                                        v-on="on" ref="expirationPassportDate"></v-text-field>
                                                </template>
                                                <v-date-picker v-model="expirationPassportDate" no-title
                                                    @input="expirationPassportDateModal = false" locale="es-ES"
                                                    next-icon="fas fa-angle-right"
                                                    prev-icon="fas fa-angle-left"></v-date-picker>
                                            </v-menu>
                                    </v-col>

                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-text-field ref="igssId" v-model="igssId" label="IGSS"
                                            hint="IGSS" :counter="13" maxlength="13">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" xs="12" sm="3" md="3">
                                            <v-menu ref="expirationIgssDateModal" v-model="expirationIgssDateModal"
                                                :close-on-content-click="false"
                                                transition="scale-transition" offset-y max-width="290px"
                                                min-width="auto">
                                                <template v-slot:activator="{ on, attrs }">
                                                    <v-text-field v-model="expirationIgssDateFormatted"
                                                        label="Fecha vencimiento IGSS"
                                                        hint=" Fecha vencimiento IGSS" persistent-hint
                                                        prepend-icon="fas fa-calendar" v-bind="attrs"
                                                        @blur="expirationIgssDate = parseDate(expirationIgssDateFormatted)"
                                                        v-on="on" ref="expirationIgssDate"></v-text-field>
                                                </template>
                                                <v-date-picker v-model="expirationIgssDate" no-title
                                                    @input="expirationIgssDateModal = false" locale="es-ES"
                                                    next-icon="fas fa-angle-right"
                                                    prev-icon="fas fa-angle-left"></v-date-picker>
                                            </v-menu>
                                    </v-col>

                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-text-field ref="irtraId" v-model="irtraId" label="IRTRA"
                                            hint="IRTRA" :counter="13" maxlength="13">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" xs="12" sm="3" md="3">
                                            <v-menu ref="expirationIrtraDateModal" v-model="expirationIrtraDateModal"
                                                :close-on-content-click="false"
                                                transition="scale-transition" offset-y max-width="290px"
                                                min-width="auto">
                                                <template v-slot:activator="{ on, attrs }">
                                                    <v-text-field v-model="expirationIrtraDateFormatted"
                                                        label="Fecha vencimiento IRTRA"
                                                        hint=" Fecha vencimiento IRTRA" persistent-hint
                                                        prepend-icon="fas fa-calendar" v-bind="attrs"
                                                        @blur="expirationIrtraDate = parseDate(expirationIrtraDateFormatted)"
                                                        v-on="on" ref="expirationIrtraDate"></v-text-field>
                                                </template>
                                                <v-date-picker v-model="expirationIrtraDate" no-title
                                                    @input="expirationIrtraDateModal = false" locale="es-ES"
                                                    next-icon="fas fa-angle-right"
                                                    prev-icon="fas fa-angle-left"></v-date-picker>
                                            </v-menu>
                                    </v-col>

                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-select item-text='name' item-value="id"
                                            v-model="vaccineSelected" :items="vaccineArray"
                                            label="Dosis vacuna COVID-19 (Obligatorio)"
                                            hint="Dosis vacuna COVID-19 aplicada (Obligatorio)"
                                            :loading="loadingVaccine"
                                            >
                                        </v-select>


                                    </v-col>

                                </v-row>
                                <v-divider></v-divider>
                            </div>

                            </v-card>

                            <v-btn
                            color="primary"
                            @click="saveIds()"
                            >
                            Siguiente
                            <i class="fas fa-chevron-right"></i>
                            </v-btn>

                            <v-btn
                                color="error"
                                @click="cancel()"
                            >
                                <i class="fas fa-ban"></i>
                            Cancel
                            </v-btn>
                        </v-stepper-content>

                        <v-stepper-content step="2">
                            <v-card
                            class="mb-12"
                            color="white lighten-5"
                            height="auto"
                            >
                            <div class="container-fluid">
                                <h2 class="title">DATOS GENERALES</h2>
                                <v-row>

                                        <v-col cols="12" sm="12" md="4" lg="4">
                                            <div>
                                                <v-select item-text='name' item-value="id"
                                                    v-model="genderSelected" :items="genderListArray"
                                                    label="Seleccione un sexo (Obligatorio)" hint="Sexo (Obligatorio)"
                                                    :loading="loadingGender">
                                                </v-select>
                                            </div>
                                        </v-col>

                                        <v-col cols="12" sm="12" md="4" lg="4">
                                            <div>
                                                <v-select
                                                    item-text="name"
                                                    item-value="id"
                                                    v-model="maritalStatusSelected"
                                                    :items="maritalStatusArray" label="Estado civil (Obligatorio)"
                                                    hint="Estado civil (Obligatorio)" :loading="loadingMaritalStatus">
                                                </v-select>
                                            </div>
                                        </v-col>

                                        <v-col cols="12" sm="4" md="4" xs="12">
                                            <v-text-field
                                                ref="firstName"
                                                v-model="firstName"
                                                label="Primer nombre (Obligatorio)"
                                                hint="Primer nombre (Obligatorio)"
                                                :counter="50"
                                                maxlength="50"
                                                aria-require
                                                @blur="validateFirstName(firstName)">

                                            </v-text-field>
                                            <div class="text-red" v-if="firstName.length === 0">
                                                <sub> {{ errorFirstName }} </sub>
                                            </div>


                                        </v-col>

                                        <v-col cols="12" sm="4" md="4" xs="12">
                                            <v-text-field ref="secondName" v-model="secondName"
                                                label="Segundo nombre" hint="Segundo nombre"
                                                :counter="50" maxlength="50">

                                            </v-text-field>


                                        </v-col>

                                        <v-col cols="12" sm="4" md="4" xs="12">
                                            <v-text-field ref="thirdName" v-model="thirdName"
                                                label="Tercer nombre (Opcional)"
                                                hint="Tercer nombre (Opcional)" :counter="50"
                                                maxlength="50">

                                            </v-text-field>


                                        </v-col>

                                        <v-col cols="12" sm="4" md="4" xs="12">
                                            <v-text-field ref="firstLastName" v-model="firstLastName"
                                                label="Primer apellido (Obligatorio)" hint="Primer apellido (Obligatorio) "
                                                :counter="50" maxlength="50"
                                                @blur="validateFirstLastName(firstLastName)"
                                                >


                                            </v-text-field>

                                            <div class="text-red" v-if="firstLastName.length === 0">
                                                <sub> {{ errorFirstLastName }} </sub>
                                            </div>



                                        </v-col>

                                        <v-col cols="12" sm="4" md="4" xs="12">
                                            <v-text-field ref="secondLastName" v-model="secondLastName"
                                                label="Segundo apellido" hint="Segundo apellido" @blur="secondLastName = secondLastName.toUpperCase()"
                                                :counter="50" maxlength="50">

                                            </v-text-field>



                                        </v-col>

                                        <v-col v-if="maritalStatusSelected == 1 && genderSelected == 2"
                                            cols="12" sm="4" md="4" xs="12">

                                            <v-text-field ref="maritalLastName"
                                                v-model="maritalLastName" label="Apellido de casada"
                                                hint="Apellido de casada" :counter="50" maxlength="50"
                                                @blur="validateMaritalLastName(maritalLastName)"
                                                >

                                            </v-text-field>

                                            <div class="text-red" v-if="maritalLastName.length === 0">
                                                <sub> {{ errorMaritalLastName }} </sub>
                                            </div>

                                        </v-col>

                                        <v-col cols="12" sm="12" md="4" lg="4">
                                            <div>
                                                <v-select item-text='name' item-value="id"
                                                    v-model="stateSelected" :items="stateStatusArray"
                                                    label="Departamento nacimiento"
                                                    hint="Departamento nacimiento"
                                                    :loading="loadingState"
                                                    @change="selectCity(stateSelected)">
                                                </v-select>
                                            </div>
                                        </v-col>

                                        <v-col cols="12" sm="12" md="4" lg="4">
                                            <div>
                                                <v-select item-text='name' item-value="id"
                                                    v-model="citySelected" :items="cityArray"
                                                    label="Municipio de nacimiento"
                                                    hint="Municipio de nacimiento"
                                                    :loading="loadingCity" :disabled="isCityDisabled"
                                                    @blur="setFullName()">
                                                </v-select>
                                            </div>
                                        </v-col>

                                        <v-col cols="12" sm="12" md="4" lg="4">
                                            <div>
                                                <v-select item-text='national_name' item-value="id"
                                                    v-model="countrySelected" :items="countryArray"
                                                    label="Seleccione país - nacionalidad"
                                                    hint="País - nacionalidad" :loading="loadingCity">
                                                </v-select>
                                            </div>
                                        </v-col>

                                        <v-col cols="12" sm="12" md="4" lg="4">
                                            <v-menu ref="dialogBirthModal" v-model="dialogBirthModal"
                                                :close-on-content-click="false"
                                                transition="scale-transition" offset-y max-width="290px"
                                                min-width="auto">
                                                <template v-slot:activator="{ on, attrs }">
                                                    <v-text-field v-model="dateBirthFormatted"
                                                        label="Fecha nacimiento"
                                                        hint=" Fecha nacimiento" persistent-hint
                                                        prepend-icon="fas fa-calendar" v-bind="attrs"
                                                        @blur="dateBirth = parseDate(dateBirthFormatted)"
                                                        v-on="on" ref="dateBirth"></v-text-field>
                                                </template>
                                                <v-date-picker v-model="dateBirth" no-title
                                                    @input="dialogBirthModal = false" locale="es-ES"
                                                    next-icon="fas fa-angle-right"
                                                    prev-icon="fas fa-angle-left"></v-date-picker>
                                            </v-menu>
                                        </v-col>

                                        <v-col cols="12" sm="12" md="4" lg="4">
                                            <div>
                                                <v-select item-text='name' item-value="id"
                                                    v-model="maternLanguageSelected"
                                                    :items="maternLanguageArray" label="Idioma materno"
                                                    hint="Idioma materno"
                                                    :loading="loadingMaternLanguage">
                                                </v-select>
                                            </div>
                                        </v-col>

                                        <v-col cols="12" sm="12" md="4" lg="4">
                                            <div>
                                                <v-select item-text='name' item-value="id"
                                                    v-model="secondaryLanguageSelected"
                                                    :items="secondaryLanguageArray"
                                                    label="Idioma secundario" hint="Idioma secundario"
                                                    :loading="loadingSecondaryLanguage">
                                                </v-select>
                                            </div>
                                        </v-col>

                                        <v-col cols="12" sm="4" md="4" xs="12">
                                            <v-text-field ref="religion" v-model="religion"
                                                label="Religión" hint="Peso" :counter="20"
                                                maxlength="20" @change="religion = religion.toUpperCase()">

                                            </v-text-field>

                                        </v-col>

                                        <v-col cols="12" xs="12" sm="4" md="4">
                                            <v-text-field-integer v-model="employeeHeight"
                                                label="Altura (Obligatorio)"
                                                @blur="validateEmployeeHeight(employeeHeight)"
                                                :focus=isFocusH
                                                counter="4"
                                                :properties="{
                                                    readonly: false,
                                                    clearable: true,
                                                    placeholder: 'Altura (Obligatorio uso mts ej. 1.90)',

                                                }"
                                                :options="{
                                                        humanMask: '#.##',
                                                        machineMask: '#.##',
                                                        empty: '',
                                                        applyAfter: false
                                                }"
                                            >

                                            </v-text-field-integer>
                                            <div class="text-red"
                                                v-if="employeeHeight.length === 0">
                                                <sub> {{ errorEmployeeHeight }}</sub></div>

                                        </v-col>


                                        <v-col cols="12" xs="12" sm="4" md="4">
                                            <v-text-field-integer v-model="employeeWeight"
                                                label="Peso (Obligatorio)"
                                                @blur="validateEmployeeWeight(employeeWeight)"
                                                :focus=isFocusW
                                                counter="4"
                                                :properties="{
                                                    readonly: false,
                                                    clearable: true,
                                                    placeholder: 'Peso (Obligatorio uso lbs ej. 150)',

                                                }"
                                                :options="{
                                                        humanMask: '###',
                                                        machineMask: '###',
                                                        empty: '',
                                                        applyAfter: false
                                                }"
                                            >

                                            </v-text-field-integer>
                                            <div class="text-red"
                                                v-if="employeeWeight.length === 0">
                                                <sub> {{ errorEmployeeWeight }}</sub>
                                            </div>

                                        </v-col>


                                        <v-col cols="12" sm="12" md="4" lg="4">
                                            <div>
                                                <v-select
                                                    item-text='name'
                                                    item-value="id"
                                                    ref="clothJackSelected"
                                                    v-model="clothJackSelected"
                                                    :items="clothJackArray"
                                                    label="Talla chaqueta - chumpa"
                                                    hint="Talla chaqueta - chumpa"
                                                    :loading="loadClothJack"
                                                    @blur="validateSize(1, clothJackSelected)"
                                                    >
                                                </v-select>
                                                <div class="text-red"
                                                    v-if="clothJackSelected.length < 1">
                                                <sub> {{ errorJacket }}</sub>
                                                </div>
                                            </div>
                                        </v-col>

                                        <v-col cols="12" sm="12" md="4" lg="4">
                                            <div>
                                                <v-select item-text='name' item-value="id"
                                                    v-model="clothShirtSelected"
                                                    ref="clothShirtSelected"
                                                    :items="clothShirtArray" label="Talla camisa"
                                                    hint="Talla  camisa" :loading="loadClothShirt"
                                                    @blur="validateSize(2, clothShirtSelected)"
                                                    >
                                                </v-select>
                                                <div class="text-red"
                                                    v-if="clothShirtSelected.length < 1">
                                                    <sub> {{ errorShirt }}</sub>
                                                </div>
                                            </div>
                                        </v-col>

                                        <v-col cols="12" sm="12" md="4" lg="4">
                                            <div>
                                                <v-select item-text='name' item-value="id"
                                                v-model="clothShoesSelected"
                                                ref="clothShoesSelected"
                                                :items="clothShoesArray" label="Talla zapatos"
                                                hint="Talla  zapatos" :loading="loadClothShoes"
                                                @blur="validateSize(3, clothShoesSelected)"
                                                >
                                                </v-select>
                                                <div class="text-red"
                                                    v-if="clothShoesSelected.length < 1">
                                                        <sub> {{ errorShoes }}</sub>
                                                </div>
                                            </div>
                                        </v-col>

                                        <v-col cols="12" sm="12" md="4" lg="4">
                                                <div>
                                                    <v-select item-text='name' item-value="id"
                                                    v-model="clothPantSelected"
                                                    ref="clothShoesSelected"
                                                    :items="clothPantArray"
                                                    label="Talla pantalón" hint="Talla  pantalón"
                                                    :loading="loadClothPant"
                                                    @blur="validateSize(4, clothPantSelected)"
                                                    >
                                                </v-select>
                                                <div class="text-red"
                                                    v-if="clothPantSelected.length < 1">
                                                        <sub> {{ errorJeans }}</sub>
                                                </div>
                                            </div>
                                        </v-col>

                                </v-row>

                            </div>

                            </v-card>

                            <v-btn
                            color="primary"
                            @click="saveGeneralInfo()"
                            :disabled="isDisabledButton"
                            >
                            Siguiente
                            <i class="fas fa-chevron-right"></i>
                            </v-btn>

                            <v-btn
                            color="primary"
                            @click="e1 = 1"
                            >
                            <i class="fas fa-chevron-left"></i> Atrás
                            </v-btn>
                        </v-stepper-content>

                        <v-stepper-content step="3">
                            <v-card
                            class="mb-12"
                            color="white lighten-5"
                            height="auto"
                            >
                            <div class="container-fluid">
                                <h2 class="title">LOCALIZACION</h2>
                                <v-row>
                                    <v-col cols="12" sm="6" md="6" xs="12">
                                        <v-text-field ref="address" v-model="address"
                                            label="Domicilio" hint="Domicilio" :counter="50"
                                            maxlength="50">

                                        </v-text-field>

                                    </v-col>
                                    <v-col cols="12" sm="6" md="6" xs="12">
                                        <v-text-field ref="employeeMail" v-model="employeeMail"
                                            label="Correo electrónico" hint="Correo electrónico"
                                            :counter="50" maxlength="50"
                                            @blur="validateMail(employeeMail)">

                                        </v-text-field>

                                    </v-col>
                                    <v-col cols="12" sm="4" md="4" xs="12">
                                        <v-text-field ref="employeePersonalHomePhone"
                                            v-model="employeePersonalHomePhone"
                                            label="Teléfono de casa" hint="Teléfono de casa"
                                            :counter="8" maxlength="8">

                                        </v-text-field>

                                    </v-col>
                                    <v-col cols="12" sm="4" md="4" xs="12">
                                        <v-text-field ref="employeePersonalMobilePhone"
                                            v-model="employeePersonalMobilePhone"
                                            label="Teléfono móvil personal"
                                            hint="Teléfono móvil personal" :counter="8"
                                            maxlength="8">

                                        </v-text-field>

                                    </v-col>
                                </v-row>
                            </div>

                            </v-card>

                            <v-btn
                            color="primary"
                            @click="saveAddress()"
                            :disabled="isDisabledButton"
                            >
                                Siguiente
                                <i class="fas fa-chevron-right"></i>
                            </v-btn>

                            <v-btn
                            color="primary"
                            @click="e1 = 2"
                            >
                            <i class="fas fa-chevron-left"></i> Atrás
                            </v-btn>
                        </v-stepper-content>

                        <v-stepper-content step="4">
                            <v-card
                            class="mb-12"
                            color="white lighten-5"
                            height="auto"
                            >

                            <div class="container-fluid">
                                <h2 class="title">EN CASO DE EMERGENCIA</h2>
                                <v-row>
                                    <v-col cols="12" sm="2" md="2" xs="12">
                                        <v-select item-text='group' item-value="id"
                                                v-model="bloodSelect"
                                                :items="bloodTypeArr" label="Tipo de grupo sanguineo"
                                                hint="Tipo de grupo sanguineo" :loading="loadingRelationShip">
                                        </v-select>

                                    </v-col>

                                    <v-col cols="12" sm="6" md="6" xs="12">
                                        <v-text-field ref="emergencyContactName"
                                            v-model="emergencyContactName"
                                            label="Contacto de emergencias"
                                            hint="Contacto de emergencias" :counter="50"
                                            maxlength="50">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="4" md="4" xs="12">
                                        <v-text-field ref="emergencyContactPhone"
                                            v-model="emergencyContactPhone"
                                            label="Teléfono de contacto de emergencias"
                                            hint="Teléfono de contacto de emergencias" :counter="50"
                                            maxlength="50">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="4" md="4" xs="12">
                                        <v-switch v-model="allergies" color="primary"
                                            label="¿Es alérgico?" :value=true
                                            hide-details></v-switch>

                                    </v-col>

                                    <v-col cols="12" sm="8" md="8" xs="12">
                                        <v-text-field ref="allergieDetails"
                                            v-model="allergieDetails" label="Describa las alergias"
                                            hint="Describa las alergias" :counter="50"
                                            maxlength="50" :disabled="!allergies">

                                        </v-text-field>

                                    </v-col>
                                </v-row>

                            </div>
                            </v-card>

                            <v-btn
                            color="primary"
                            @click="e1 = 5"
                            :disabled="isDisabledButton"
                            >
                            Siguiente
                                <i class="fas fa-chevron-right"></i>
                            </v-btn>

                            <v-btn
                            color="primary"
                            @click="e1 = 3"
                            >
                            <i class="fas fa-chevron-left"></i> Atrás
                            </v-btn>
                        </v-stepper-content>

                        <v-stepper-content step="5">
                            <v-card
                            class="mb-12"
                            color="white lighten-5"
                            height="auto"
                            >
                            <div class="container-fluid">
                                <h2 class="title">DATOS VIVIENDA</h2>

                                <v-row>

                                <v-col cols="12" sm="4" md="4" xs="12">
                                    <v-switch v-model="ownHome" color="primary"
                                        label="¿Casa propia?" :value=true
                                        hide-details></v-switch>

                                </v-col>

                                <v-col cols="12" sm="4" md="4" xs="12">
                                    <v-text-field ref="ownerName" v-model="ownerName"
                                        label="Nombre del propietario"
                                        hint="Nombre del propietario" :counter="50"
                                        maxlength="50" :disabled="ownHome">

                                    </v-text-field>

                                </v-col>
                                <v-col cols="12" sm="4" md="4" xs="12">
                                    <v-text-field ref="ownerPhoneNumber"
                                        v-model="ownerPhoneNumber"
                                        label="Número del propietario"
                                        hint="Número del propietario" :counter="8" maxlength="8"
                                        :disabled="ownHome">

                                    </v-text-field>

                                </v-col>


                                </v-row>

                            </div>
                            </v-card>

                            <v-btn
                            color="primary"
                            @click="e1 = 6"
                            :disabled="isDisabledButton"
                            >
                            Siguiente
                                <i class="fas fa-chevron-right"></i>
                            </v-btn>

                            <v-btn
                            color="primary"
                            @click="e1 = 4"
                            >
                            <i class="fas fa-chevron-left"></i> Atrás
                            </v-btn>
                        </v-stepper-content>

                        <v-stepper-content step="6">
                            <v-card
                            class="mb-12"
                            color="white lighten-5"
                            height="auto"
                            >
                            <div class="container-fluid">
                                <h2 class="title">DATOS FAMILIARES</h2>
                                <v-row>
                                    <v-col cols="12" sm="12" md="3" lg="3">
                                        <div>
                                            <v-select item-text='name' item-value="id"
                                                v-model="relationShipSelected"
                                                :items="relationShipData" label="Parentesco"
                                                hint="Parentesco" :loading="loadingRelationShip">
                                            </v-select>
                                        </div>
                                    </v-col>

                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-text-field ref="familyNames" v-model="familyNames"
                                            label="Nombres" hint="Nombres" :counter="20"
                                            maxlength="20">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-text-field ref="familyFirstLastName"
                                            v-model="familyFirstLastName" label="Apellido paterno"
                                            hint="Apellido paterno" :counter="20" maxlength="20">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-text-field ref="familySecondLastName"
                                            v-model="familySecondLastName" label="Apellido materno"
                                            hint="Apellido materno" :counter="20" maxlength="20">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-text-field ref="familyAddress" v-model="familyAddress"
                                            label="Dirección" hint="Dirección" :counter="100"
                                            maxlength="100">

                                        </v-text-field>

                                    </v-col>
                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-text-field ref="familyPhoneNumber"
                                            v-model="familyPhoneNumber" label="Número telefónico"
                                            hint="Número telefónico" :counter="8" maxlength="8">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="12" md="3" lg="3">
                                        <v-menu ref="dialogBirthModal"
                                            v-model="dialogfamilyBurnDateModal"
                                            :close-on-content-click="false"
                                            transition="scale-transition" offset-y max-width="290px"
                                            min-width="auto">
                                            <template v-slot:activator="{ on, attrs }">
                                                <v-text-field v-model="familyBurnDateFormatted"
                                                    label="Fecha nacimiento familiar"
                                                    hint=" Fecha nacimiento familiar"
                                                    persistent-hint prepend-icon="fas fa-calendar"
                                                    v-bind="attrs"
                                                    @blur="familyBurnDate = parseDate(familyBurnDateFormatted)"
                                                    v-on="on" ref="familyBurnDate"></v-text-field>
                                            </template>
                                            <v-date-picker v-model="familyBurnDate" no-title
                                                @input="dialogfamilyBurnDateModal = false"
                                                locale="es-ES" next-icon="fas fa-angle-right"
                                                prev-icon="fas fa-angle-left"></v-date-picker>
                                        </v-menu>
                                    </v-col>

                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-text-field ref="familyComment" v-model="familyComment"
                                            label="Comentario" hint="Comentario" :counter="150"
                                            maxlength="150">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="8" xs="12" md="8">
                                        <button class="btn btn-success" title="Agregar familiar"
                                            @click="addFamilyMember(
                                                familyNames,
                                                familyFirstLastName,
                                                familySecondLastName,
                                                familyAddress,
                                                familyPhoneNumber,
                                                relationShipSelected,
                                                familyBurnDate,
                                                familyComment)">
                                            <i class="fas fa-plus"></i>
                                        </button>

                                    </v-col>

                                    <v-col cols="12" md="12" lg="12" sm="12">
                                        <div class="scroll-div">
                                            <table class="table table-hover table-bordered">
                                                <thead>
                                                    <th>Nombre</th>
                                                    <th>Parentesco</th>
                                                    <th>telefono</th>
                                                    <th>Acciones</th>
                                                </thead>
                                                <tbody v-if="familyDataDetail.length">
                                                    <tr v-for="(familyDet, index) in familyDataDetail"
                                                        :key="familyDataDetail.index">
                                                        <td class="text-left fs-6">
                                                            {{ familyDet.names + ' ' +
                                                                familyDet.first_last_name + ' ' +
                                                                familyDet.second_las_name }}</td>
                                                        <td class="text-left fs-6">
                                                            {{ familyDet.relationShipName }}</td>
                                                        <td class="text-left fs-6">
                                                            {{ familyDet.family_phone_number }}</td>
                                                        <td>

                                                            <button class="btn btn-danger"
                                                                title="Eliminar familiar"
                                                                @click="deleteDetails(index, 1)"> <i
                                                                    class="fas fa-trash"></i>
                                                            </button>

                                                        </td>
                                                    </tr>

                                                </tbody>
                                                <tbody v-else>
                                                    <tr>
                                                        <td colspan="4"
                                                            class="text-center text-danger">
                                                            <h5> No hay registros </h5>
                                                        </td>
                                                    </tr>
                                                </tbody>

                                            </table>
                                        </div>
                                    </v-col>

                                </v-row>
                            </div>
                            </v-card>

                            <v-btn
                            color="primary"
                            @click="e1 = 7"
                            :disabled="isDisabledButton"
                            >
                            Siguiente
                                <i class="fas fa-chevron-right"></i>
                            </v-btn>

                            <v-btn
                            color="primary"
                            @click="e1 = 5"
                            >
                            <i class="fas fa-chevron-left"></i> Atrás
                            </v-btn>
                        </v-stepper-content>

                        <v-stepper-content step="7">
                            <v-card
                            class="mb-12"
                            color="white lighten-5"
                            height="auto"
                            >
                            <div class="container-fluid">
                                <h2 class="title">SERVICIOS/ARMAS</h2>
                                <v-row>
                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-switch v-model="armyService" color="primary"
                                            label="¿Servicio militar?" :value=true
                                            hide-details></v-switch>

                                    </v-col>

                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-text-field ref="aramyServiceTime"
                                            v-model="aramyServiceTime"
                                            label="Tiempo de servicio militar"
                                            hint="Tiempo de servicio militar" :counter="50"
                                            maxlength="50" :disabled="!armyService">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-text-field ref="armyReasonUnregistration"
                                            v-model="armyReasonUnregistration"
                                            label="Motivo de baja" hint="Motivo de baja"
                                            :counter="50" maxlength="50" :disabled="!armyService">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-text-field ref="armyLastGrade"
                                            v-model="armyLastGrade"
                                            label="Grado militar obtenido" hint="Grado militar obtenido"
                                            :counter="50" maxlength="50" :disabled="!armyService">

                                        </v-text-field>

                                    </v-col>


                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-switch v-model="pncService" color="primary"
                                            label="¿Servicio en la PNC?" :value=true
                                            hide-details></v-switch>

                                    </v-col>

                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-text-field ref="pncServiceTime" v-model="pncServiceTime"
                                            label="Tiempo de servicio en la PNC"
                                            hint="Tiempo de servicio en la PNC" :counter="50"
                                            maxlength="50" :disabled="!pncService">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-text-field ref="pncReasonUnregistration"
                                            v-model="pncReasonUnregistration"
                                            label="Motivo de baja en la PNC"
                                            hint="Motivo de baja en la PNC" :counter="50"
                                            maxlength="50" :disabled="!pncService">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-text-field ref="pncLastGrade"
                                            v-model="pncLastGrade"
                                            label="Grado obtenido PNC"
                                            hint="Grado obtenido PNC" :counter="50"
                                            maxlength="50" :disabled="!pncService">

                                        </v-text-field>

                                    </v-col>



                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-switch v-model="pmtService" color="primary"
                                            label="¿Servicio en la PMT?" :value=true
                                            hide-details></v-switch>

                                    </v-col>


                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-text-field ref="pmtServiceTime" v-model="pmtServiceTime"
                                            label="Tiempo de servicio en la PMT"
                                            hint="Tiempo de servicio en la PMT" :counter="50"
                                            maxlength="50" :disabled="!pmtService">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-text-field ref="pmtReasonUnregistration"
                                            v-model="pmtReasonUnregistration"
                                            label="Motivo de baja en la PMT"
                                            hint="Motivo de baja en la PMT" :counter="50"
                                            maxlength="50" :disabled="!pmtService">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-text-field ref="pmtLastGrade"
                                            v-model="pmtLastGrade"
                                            label="Grado obtenido PMT"
                                            hint="Grado obtenido PMT" :counter="50"
                                            maxlength="50" :disabled="!pmtService">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="12" md="12" xs="12">
                                        <h2>Uso de armas</h2>
                                    </v-col>

                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-switch v-model="shotGun" color="primary"
                                            label="Escopeta" :value=true
                                            hide-details></v-switch>

                                    </v-col>
                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-select item-text='time' item-value="id"
                                                v-model="shotGunSelect"
                                                :items="arrTyme" label="Tiempo de uso escopeta"
                                                hint="Tiempo de uso escopeta" :loading="loadingRelationShip">
                                        </v-select>

                                    </v-col>
                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-switch v-model="gun" color="primary"
                                            label="Pistola" :value=true
                                            hide-details></v-switch>

                                    </v-col>
                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-select item-text='time' item-value="id"
                                                v-model="gunSelect"
                                                :items="arrTyme" label="Tiempo de uso pistola"
                                                hint="Tiempo de uso pistola" :loading="loadingRelationShip">
                                            </v-select>

                                    </v-col>
                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-switch v-model="revolver" color="primary"
                                            label="Revolver" :value=true
                                            hide-details></v-switch>

                                    </v-col>
                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-select item-text='time' item-value="id"
                                                v-model="revolverSelect"
                                                :items="arrTyme" label="Tiempo de uso revolver"
                                                hint="Tiempo de uso revolver" :loading="loadingRelationShip">
                                            </v-select>

                                    </v-col>

                                </v-row>

                            </div>
                            </v-card>

                            <v-btn
                            color="primary"
                            @click="e1 = 8"
                            :disabled="isDisabledButton"
                            >
                            Siguiente
                                <i class="fas fa-chevron-right"></i>
                            </v-btn>

                            <v-btn
                            color="primary"
                            @click="e1 = 6"
                            >
                            <i class="fas fa-chevron-left"></i> Atrás
                            </v-btn>
                        </v-stepper-content>

                        <v-stepper-content step="8">
                            <v-card
                            class="mb-12"
                            color="white lighten-5"
                            height="auto"
                            >
                            <div class="container-flkui">
                                <h2 class="title">ACREDITACIONES</h2>
                                <v-row>

                                    <v-col cols="12" sm="12" md="6" lg="6">
                                        <div>
                                            <v-select item-text="name" item-value="id"
                                                v-model="academicLevelSelected"
                                                :items="academicLevelArray"
                                                label="Ultimo nivel académico obtenido"
                                                hint="Ultimo nivel académico obtenido"
                                                :loading="loadingAcademicSelect">
                                            </v-select>

                                        </div>

                                    </v-col>

                                    <v-col cols="12" sm="6" md="6" xs="12">
                                        <v-text-field ref="lastDegreeObtained"
                                            v-model="lastDegreeObtained"
                                            label="Ultimo grado obtenido"
                                            hint="Ultimo grado obtenido" :counter="20"
                                            maxlength="20"
                                            @blur="lastDegreeObtained = lastDegreeObtained.toUpperCase()">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="12" md="12" lg="12">
                                        <h5 class="title">ACREDITACIONES</h5>
                                    </v-col>

                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-text-field ref="acreditationName"
                                            v-model="acreditationName" label="Tipo de acreditación"
                                            hint="Tipo de acreditación" :counter="20" maxlength="20"
                                            @blur="acreditationName = acreditationName.toUpperCase()">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-text-field ref="institutionAccreditation"
                                            v-model="institutionAccreditation"
                                            label="Institución que acredita"
                                            hint="Institución que acredita" :counter="20"
                                            maxlength="20"
                                            @blur="institutionAccreditation = institutionAccreditation.toUpperCase()">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-text-field ref="accreditationNumber"
                                            v-model="accreditationNumber"
                                            label="Número de la acreditación"
                                            hint="Número de la acreditación" :counter="20"
                                            maxlength="20"
                                            @blur="accreditationNumber = accreditationNumber.toUpperCase()">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="12" md="3" lg="3">
                                        <v-menu ref="dialogBirthModal"
                                            v-model="dialogExpireAccreditationDateModal"
                                            :close-on-content-click="false"
                                            transition="scale-transition" offset-y max-width="290px"
                                            min-width="auto">
                                            <template v-slot:activator="{ on, attrs }">
                                                <v-text-field
                                                    v-model="expireAccreditationDateFormatted"
                                                    label="Fecha de expiración de acreditación"
                                                    hint=" Fecha de expiración de acreditación"
                                                    persistent-hint prepend-icon="fas fa-calendar"
                                                    v-bind="attrs"
                                                    @blur="expireAccreditationDate = parseDate(expireAccreditationDateFormatted)"
                                                    v-on="on"
                                                    ref="expireAccreditationDate"></v-text-field>
                                            </template>
                                            <v-date-picker v-model="expireAccreditationDate"
                                                no-title
                                                @input="dialogExpireAccreditationDateModal = false"
                                                locale="es-ES" next-icon="fas fa-angle-right"
                                                prev-icon="fas fa-angle-left"></v-date-picker>
                                        </v-menu>
                                    </v-col>

                                    <v-col cols="12" sm="12" md="12" xs="12">
                                        <button class="btn btn-success push-right" @click="addAccreditationDetail(
                                            acreditationName,
                                            institutionAccreditation,
                                            accreditationNumber,
                                            expireAccreditationDate)"> <i
                                                class="fas fa-plus"></i> </button>

                                    </v-col>


                                    <v-col cols="12" md="12" lg="12" sm="12">
                                        <div class="scroll-div">
                                            <table class="table table-hover table-bordered">
                                                <thead>
                                                    <th>Tipo de acreditación</th>
                                                    <th>Institución que acredita</th>
                                                    <th>Número acreditación</th>
                                                    <th>Fecha de vencimiento</th>
                                                    <th>Acciones</th>
                                                </thead>
                                                <tbody v-if="acreditationDataDetail.length">
                                                    <tr v-for="(acreditationDet, index) in acreditationDataDetail"
                                                        :key="acreditationDataDetail.index">
                                                        <td class="text-left fs-6">{{
                                                            acreditationDet.accreditation_name }}
                                                        </td>
                                                        <td class="text-left fs-6">
                                                            {{ acreditationDet.accreditation_institution }}
                                                        </td>
                                                        <td class="text-left fs-6">
                                                            {{ acreditationDet.accreditation_number }}
                                                        </td>
                                                        <td class="text-left fs-6">
                                                            {{ acreditationDet.expire_date }}</td>
                                                        <td>

                                                            <button class="btn btn-danger"
                                                                title="Eliminar acreditación"
                                                                @click="deleteDetails(index, 2)"> <i
                                                                    class="fas fa-trash"></i>
                                                            </button>

                                                        </td>
                                                    </tr>

                                                </tbody>
                                                <tbody v-else>
                                                    <tr>
                                                        <td colspan="5"
                                                            class="text-center text-danger">
                                                            <h5> No hay registros </h5>
                                                        </td>
                                                    </tr>
                                                </tbody>

                                            </table>
                                        </div>
                                    </v-col>

                                </v-row>

                            </div>
                            </v-card>

                            <v-btn
                            color="primary"
                            @click="e1 = 9"
                            :disabled="isDisabledButton"
                            >
                            Siguiente
                                <i class="fas fa-chevron-right"></i>
                            </v-btn>

                            <v-btn
                            color="primary"
                            @click="e1 = 7"
                            >
                            <i class="fas fa-chevron-left"></i> Atrás
                            </v-btn>
                        </v-stepper-content>

                        <v-stepper-content step="9">
                            <v-card
                            class="mb-12"
                            color="white lighten-5"
                            height="auto"
                            >
                            <div class="container-fluid">
                                <h2 class="title">REFERENCIAS PERSONALES</h2>
                                <v-row>
                                    <v-col cols="12" sm="4" md="4" xs="12">
                                        <v-text-field ref="refPerFullName" v-model="refPerFullName"
                                            label="Nombre completo" hint="Nombre completo"
                                            :counter="150" maxlength="150"
                                            @blur="refPerFullName = refPerFullName.toUpperCase()">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="4" md="4" xs="12">
                                        <v-text-field ref="refPerPhone" v-model="refPerPhone"
                                            label="Teléfono" hint="Teléfono" :counter="8"
                                            maxlength="8"
                                            @blur="refPerPhone = refPerPhone.toUpperCase()">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="4" md="4" xs="12">
                                        <v-text-field ref="refPerAddress" v-model="refPerAddress"
                                            label="Dirección casa" hint="Dirección casa"
                                            :counter="150" maxlength="150"
                                            @blur="refPerAddress = refPerAddress.toUpperCase()">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="12" md="3" lg="3">
                                        <div>
                                            <v-select item-text="name" item-value="id"
                                                v-model="refPerProfessionSelected"
                                                :items="academicLevelArray"
                                                label="Profesion u oficio" hint="Profesion u oficio"
                                                :loading="loadingAcademicSelect">
                                            </v-select>

                                        </div>

                                    </v-col>

                                    <v-col cols="12" sm="12" md="12" xs="12">
                                        <button class="btn btn-success push-right" @click="addRefPer(
                                            refPerFullName,
                                            refPerPhone,
                                            refPerAddress,
                                            refPerProfessionSelected)"> <i
                                                class="fas fa-plus"></i> </button>

                                    </v-col>

                                    <v-col cols="12" md="12" lg="12" sm="12">
                                        <div class="scroll-div">
                                            <table class="table table-hover table-bordered">
                                                <thead>
                                                    <th>Nombres</th>
                                                    <th>Teléfono</th>
                                                    <th class="text-center">Acciones</th>
                                                </thead>
                                                <tbody v-if="perRefDetails.length">
                                                    <tr v-for="(perRef, index) in perRefDetails"
                                                        :key="perRefDetails.index">
                                                        <td class="text-left fs-6">{{
                                                            perRef.personal_full_name }}</td>
                                                        <td class="text-left fs-6">
                                                            {{ perRef.phone_number }}</td>
                                                        <td class="text-center">

                                                            <button class="btn btn-danger"
                                                                title="Eliminar referencia personal"
                                                                @click="deleteDetails(index, 3)"> <i
                                                                    class="fas fa-trash"></i>
                                                            </button>

                                                        </td>
                                                    </tr>

                                                </tbody>
                                                <tbody v-else>
                                                    <tr>
                                                        <td colspan="5"
                                                            class="text-center text-danger">
                                                            <h5> No hay registros </h5>
                                                        </td>
                                                    </tr>
                                                </tbody>

                                            </table>
                                        </div>
                                    </v-col>
                                </v-row>
                            </div>
                            </v-card>

                            <v-btn
                            color="primary"
                            @click="e1 = 10"
                            :disabled="isDisabledButton"
                            >
                            Siguiente
                                <i class="fas fa-chevron-right"></i>
                            </v-btn>

                            <v-btn
                            color="primary"
                            @click="e1 = 8"
                            >
                            <i class="fas fa-chevron-left"></i> Atrás
                            </v-btn>
                        </v-stepper-content>

                        <v-stepper-content step="10">
                            <v-card
                            class="mb-12"
                            color="white lighten-5"
                            height="auto"
                            >
                            <div class="container-f">
                                <h2 class="title">REFERENCIAS LABORALES</h2>

                                <v-row>
                                    <v-col cols="12" sm="4" md="4" xs="12">
                                        <v-text-field ref="refLabCompanyName"
                                            v-model="refLabCompanyName" label="Nombre de la empresa"
                                            hint="Nombre de la empresa" :counter="150"
                                            maxlength="150"
                                            @blur="refLabCompanyName = refLabCompanyName.toUpperCase()">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="4" md="4" xs="12">
                                        <v-text-field ref="refLabCompanyPhone"
                                            v-model="refLabCompanyPhone"
                                            label="Teléfono de la empresa"
                                            hint="Teléfono de la empresa" :counter="8" maxlength="8"
                                            @blur="refLabCompanyPhone = refLabCompanyPhone.toUpperCase()">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="4" md="4" xs="12">
                                        <v-text-field ref="refLabCompanyAddress"
                                            v-model="refLabCompanyAddress" label="Dirección"
                                            hint="Dirección" :counter="150" maxlength="150"
                                            @blur="refLabCompanyAddress = refLabCompanyAddress.toUpperCase()">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="4" md="4" xs="12">
                                        <v-text-field ref="refLabLastPosition"
                                            v-model="refLabLastPosition"
                                            label="Ultima posicion ocupada en la empresa"
                                            hint="Ultima posicion ocupada en la empresa"
                                            :counter="150" maxlength="150"
                                            @blur="refLabLastPosition = refLabLastPosition.toUpperCase()">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="4" md="4" xs="12">
                                        <v-text-field ref="refLabLastBoss" v-model="refLabLastBoss"
                                            label="Nombre último jefe inmediato"
                                            hint="Nombre último jefe inmediato" :counter="150"
                                            maxlength="150"
                                            @blur="refLabLastBoss = refLabLastBoss.toUpperCase()">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="4" md="4" xs="12">
                                        <v-text-field ref="refLabUnregReason"
                                            v-model="refLabUnregReason" label="Motivo del retiro"
                                            hint="Motivo del retiro" :counter="150" maxlength="150"
                                            @blur="refLabUnregReason = refLabUnregReason.toUpperCase()">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="12" md="3" lg="3">
                                        <v-menu ref="refLabBeginDateModal"
                                            v-model="refLabBeginDateModal"
                                            :close-on-content-click="false"
                                            transition="scale-transition" offset-y max-width="290px"
                                            min-width="auto">
                                            <template v-slot:activator="{ on, attrs }">
                                                <v-text-field v-model="refLabBeginDateFormatted"
                                                    label="Fecha inicio labores"
                                                    hint=" Fecha inicio labores" persistent-hint
                                                    prepend-icon="fas fa-calendar" v-bind="attrs"
                                                    @blur="refLabBeginDate = parseDate(refLabBeginDateFormatted)"
                                                    v-on="on" ref="refLabBeginDate"></v-text-field>
                                            </template>
                                            <v-date-picker v-model="refLabBeginDate" no-title
                                                @input="refLabBeginDateModal = false" locale="es-ES"
                                                next-icon="fas fa-angle-right"
                                                prev-icon="fas fa-angle-left"></v-date-picker>
                                        </v-menu>
                                    </v-col>

                                    <v-col cols="12" sm="12" md="3" lg="3">
                                        <v-menu ref="refLabEndDateModal"
                                            v-model="refLabEndDateModal"
                                            :close-on-content-click="false"
                                            transition="scale-transition" offset-y max-width="290px"
                                            min-width="auto">
                                            <template v-slot:activator="{ on, attrs }">
                                                <v-text-field v-model="refLabEndDateFormatted"
                                                    label="Fecha fin de relación laboral"
                                                    hint=" Fecha fin de relación laboral"
                                                    persistent-hint prepend-icon="fas fa-calendar"
                                                    v-bind="attrs"
                                                    @blur="refLabEndDate = parseDate(refLabEndDateFormatted)"
                                                    v-on="on" ref="refLabEndDate"></v-text-field>
                                            </template>
                                            <v-date-picker v-model="refLabEndDate" no-title
                                                @input="refLabEndDateModal = false" locale="es-ES"
                                                next-icon="fas fa-angle-right"
                                                prev-icon="fas fa-angle-left"></v-date-picker>
                                        </v-menu>
                                    </v-col>

                                    <v-col cols="12" sm="12" md="12" xs="12">
                                        <button class="btn btn-success push-right" @click="addRefLab(
                                            refLabCompanyName,
                                            refLabCompanyPhone,
                                            refLabCompanyAddress,
                                            refLabLastPosition,
                                            refLabUnregReason,
                                            refLabLastBoss,
                                            refLabBeginDate,
                                            refLabEndDate)"> <i class="fas fa-plus"></i>
                                        </button>

                                    </v-col>

                                    <v-col cols="12" md="12" lg="12" sm="12">
                                        <div class="scroll-div">
                                            <table class="table table-hover table-bordered">
                                                <thead>
                                                    <th>Nombre de la empresa</th>
                                                    <th>Teléfono</th>
                                                    <th class="text-center">Acciones</th>
                                                </thead>
                                                <tbody v-if="refLabDetails.length">
                                                    <tr v-for="(refLabDetail, index) in refLabDetails"
                                                        :key="refLabDetails.index">
                                                        <td class="text-left fs-6">{{
                                                            refLabDetail.laboral_company_name }}
                                                        </td>
                                                        <td class="text-left fs-6">
                                                            {{ refLabDetail.phone_number }}</td>
                                                        <td class="text-center">

                                                            <button class="btn btn-danger"
                                                                title="Eliminar referencia personal"
                                                                @click="deleteDetails(index, 4)"> <i
                                                                    class="fas fa-trash"></i>
                                                            </button>

                                                        </td>
                                                    </tr>

                                                </tbody>
                                                <tbody v-else>
                                                    <tr>
                                                        <td colspan="5"
                                                            class="text-center text-danger">
                                                            <h5> No hay registros </h5>
                                                        </td>
                                                    </tr>
                                                </tbody>

                                            </table>
                                        </div>
                                    </v-col>

                                </v-row>

                            </div>
                            </v-card>

                            <v-btn
                            color="primary"
                            @click="e1 = 11"
                            :disabled="isDisabledButton"
                            >
                            Siguiente
                                <i class="fas fa-chevron-right"></i>
                            </v-btn>

                            <v-btn
                            color="primary"
                            @click="e1 = 9"
                            >
                            <i class="fas fa-chevron-left"></i> Atrás
                            </v-btn>
                        </v-stepper-content>

                        <v-stepper-content step="11">
                            <v-card
                            class="mb-12"
                            color="white lighten-5"
                            height="auto"
                            >
                            <div class="container-fluid">
                                <h2 class="title">BENEFICIARIO SEGURO DE VIDA Y PRESTACIONES LABORALES</h2>

                                <v-row>
                                    <v-col cols="12" sm="4" md="4" xs="12">
                                        <v-text-field ref="secureBeneficiaryName"
                                            v-model="secureBeneficiaryName"
                                            label="Nombre del beneficiario"
                                            hint="Nombre del beneficiario" :counter="100"
                                            maxlength="100"
                                            @blur="secureBeneficiaryName = secureBeneficiaryName.toUpperCase()">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="4" md="4" xs="12">
                                        <v-text-field ref="secureBeneficiaryPhone"
                                            v-model="secureBeneficiaryPhone"
                                            label="Teléfono beneficiario"
                                            hint="Teléfono beneficiario" :counter="8" maxlength="8"
                                            @blur="secureBeneficiaryPhone = secureBeneficiaryPhone.toUpperCase()">
                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="4" md="4" xs="12">
                                        <div>
                                            <v-select item-text='name' item-value="id"
                                                v-model="secureBeneficiaryRelationShip"
                                                :items="relationShipData"
                                                label="Parentesco beneficiario"
                                                hint="Parentesco beneficiario"
                                                :loading="loadingRelationShip">
                                            </v-select>
                                        </div>
                                    </v-col>

                                    <v-col cols="12" sm="12" md="12" xs="12">
                                        <v-text-field ref="secureBeneficiaryAddress"
                                            v-model="secureBeneficiaryAddress"
                                            label="Dirección beneficiario"
                                            hint="Dirección beneficiario" :counter="150"
                                            maxlength="150"
                                            @blur="secureBeneficiaryAddress = secureBeneficiaryAddress.toUpperCase()">


                                        </v-text-field>

                                    </v-col>

                                </v-row>

                            </div>
                            </v-card>

                            <v-btn
                            color="primary"
                            @click="e1 = 12"
                            :disabled="isDisabledButton"
                            >
                            Siguiente
                                <i class="fas fa-chevron-right"></i>
                            </v-btn>

                            <v-btn
                            color="primary"
                            @click="e1 = 10"
                            >
                            <i class="fas fa-chevron-left"></i> Atrás
                            </v-btn>
                        </v-stepper-content>

                        <v-stepper-content step="12">
                            <v-card
                            class="mb-12"
                            color="white lighten-5"
                            height="auto"
                            >
                            <div class="container-fluid">
                                <h2 class="title">INFORMACION ADICIONAL</h2>

                                <v-row>
                                    <v-col cols="12" sm="12" md="12" xs="12">
                                        <v-switch v-model="hasArrested" color="primary"
                                            label="¿Ha estado detenido?" :value=true
                                            hide-details></v-switch>

                                    </v-col>

                                    <v-col cols="12" sm="12" md="12" xs="12">
                                        <v-text-field ref="reasonArrested" v-model="reasonArrested"
                                            label="Motivo de la detención"
                                            hint="Motivo de la detención" :counter="50"
                                            maxlength="50" :disabled="!hasArrested">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="4" md="4" xs="12">
                                        <v-text-field ref="JudicialProcesses"
                                            v-model="JudicialProcesses" label="Procesos judiciales"
                                            hint="Detalle proceso judicial" :counter="150"
                                            maxlength="150">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="4" md="4" xs="12">
                                        <v-text-field ref="medicalHistory" v-model="medicalHistory"
                                            label="Historial médico" hint="Detalle historial médico"
                                            :counter="50" maxlength="50">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="4" md="4" xs="12">
                                        <v-text-field ref="emergencyContact"
                                            v-model="emergencyContact"
                                            label="Nombre contácto emergencias"
                                            hint="Nombre contácto emergencias" :counter="50"
                                            maxlength="50">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="4" md="4" xs="12">
                                        <v-text-field ref="emergecyAdrress"
                                            v-model="emergecyAdrress" label="Direccion emergencias"
                                            hint="Direccion emergencias" :counter="50"
                                            maxlength="50">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="4" md="4" xs="12">
                                        <div>
                                            <v-select item-text='name' item-value="id"
                                                v-model="relationShipContact"
                                                :items="relationShipData"
                                                label="Parentesco contacto emergencias"
                                                hint="Parentesco contacto emergencias"
                                                :loading="loadingRelationShip">
                                            </v-select>
                                        </div>
                                    </v-col>

                                    <v-col cols="12" sm="4" md="4" xs="12">
                                        <v-switch v-model="hasTattoos" color="primary"
                                            label="¿Tiene tatuajes?" :value=true
                                            hide-details></v-switch>

                                    </v-col>

                                    <v-col cols="12" sm="4" md="4" xs="12">
                                        <v-switch v-model="hasFamilyInCompany" color="primary"
                                            label="¿Tiene familiares en la empresa?" :value=true
                                            hide-details></v-switch>

                                    </v-col>

                                    <v-col cols="12" sm="4" md="4" xs="12">
                                        <v-text-field ref="familyInCompanyFullName"
                                            v-model="familyInCompanyFullName"
                                            label="Nombre del familiar" hint="Nombre del familiar"
                                            :counter="100" maxlength="100"
                                            :disabled="!hasFamilyInCompany">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="4" md="4" xs="12">
                                        <div>
                                            <v-select item-text='name' item-value="id"
                                                v-model="familyInCompanyVacancySelect"
                                                :items="CompanyVacancyArray"
                                                label="Puesto que ocupa"
                                                hint="Puesto que ocupa el familiar"
                                                :loading="loadCompanyVacancy"
                                                :disabled="!hasFamilyInCompany">
                                            </v-select>
                                        </div>
                                    </v-col>
                                    <v-col cols="12" sm="4" md="4" xs="12">
                                        <v-switch v-model="hasFriendInCompany" color="primary"
                                            label="¿Tiene amigos en la empresa?" :value=true
                                            hide-details></v-switch>

                                    </v-col>

                                    <v-col cols="12" sm="4" md="4" xs="12">
                                        <v-text-field ref="friendInCompanyFullName"
                                            v-model="friendInCompanyFullName"
                                            label="Nombre del amigo" hint="Nombre del amigo"
                                            :counter="100" maxlength="100"
                                            :disabled="!hasFriendInCompany">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="4" md="4" xs="12">
                                        <div>
                                            <v-select item-text='name' item-value="id"
                                                v-model="friendInCompanyVacancySelect"
                                                :items="CompanyVacancyArray"
                                                label="Puesto que ocupa"
                                                hint="Puesto que ocupa el amigo"
                                                :loading="loadCompanyVacancy"
                                                :disabled="!hasFriendInCompany">
                                            </v-select>
                                        </div>
                                    </v-col>

                                    <v-col cols="12" sm="12" md="12" xs="12">

                                        <h3>Redes sociales <sub>**(Consigne el usuario como aparece
                                                en sus redes sociales)</sub> </h3>


                                    </v-col>

                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-text-field ref="facebookUser" v-model="facebookUser"
                                            label="Usuario de facebook" hint="Usuario de facebook"
                                            :counter="50" maxlength="50">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-text-field ref="xUser" v-model="xUser"
                                            label="Usuario de X /(twitter)"
                                            hint="Usuario de X /(twitter)" :counter="50"
                                            maxlength="50">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-text-field ref="instagramUser" v-model="instagramUser"
                                            label="Usuario instagram" hint="Usuario instagram"
                                            :counter="50" maxlength="50">

                                        </v-text-field>

                                    </v-col>

                                    <v-col cols="12" sm="3" md="3" xs="12">
                                        <v-text-field ref="tiktokUser" v-model="tiktokUser"
                                            label="Usuario tiktok" hint="Usuario tiktok"
                                            :counter="50" maxlength="50">

                                        </v-text-field>

                                    </v-col>

                                </v-row>

                            </div>
                            </v-card>

                            <v-btn
                            color="primary"
                            @click="e1 = 13"
                            :disabled="isDisabledButton"
                            >
                            Siguiente
                                <i class="fas fa-chevron-right"></i>
                            </v-btn>

                            <v-btn
                            color="primary"
                            @click="e1 = 11"
                            >
                            <i class="fas fa-chevron-left"></i> Atrás
                            </v-btn>
                        </v-stepper-content>

                        <v-stepper-content step="13">
                            <v-card
                            class="mb-12"
                            color="white lighten-5"
                            height="auto"
                            >
                            <div class="container-fluid">
                                <h2 class="title">REQUERIMIENTOS ESPECIFICOS DE LA PLAZA</h2>
                                <v-row>
                                        <v-col v-for="(fields, index) in reqs" :key="index" cols="12">
                                        <v-text-field
                                            v-if="fields[0].type === 'TEXT' || fields[0].type === 'TEXTAREA'"
                                            :label="fields[0].name.toUpperCase()"
                                            v-model="formValues[fields[0].id]"
                                        ></v-text-field>
                                        <div v-else-if="fields[0].type === 'FIELD'">
                                            <label> {{ fields[0].name.toUpperCase() }} </label>
                                            <dropzone

                                            :id="fields[0].id.toString()"
                                            :options="dropzoneOptions"
                                            v-model="formValues[fields[0].id]"
                                            @vdropzone-success="handleDropzoneSuccess(fields[0].id)"
                                            ></dropzone>
                                        </div>

                                        <div v-else-if="fields[0].type === 'BOOL'">

                                            <v-switch v-model="formValues[fields[0].id]" color="primary"
                                            :label="fields[0].name.toUpperCase()" :value=true
                                            hide-details></v-switch>
                                        </div>

                                    </v-col>

                                </v-row>

                            </div>
                            </v-card>

                            <v-btn
                            color="primary"
                            @click="e1 = 1"
                            :disabled="isDisabledButton"
                            >
                            Enviar
                            <i class="fas fa-paper-plane"></i>
                            </v-btn>

                            <v-btn
                            color="primary"
                            @click="e1 = 12"
                            >
                            <i class="fas fa-chevron-left"></i> Atrás
                            </v-btn>

                            <v-btn
                            color="error"
                            @click="e1 = 1"
                            >
                            <i class="fas fa-ban"></i>
                             Cancel
                            </v-btn>
                        </v-stepper-content>





                    </v-stepper-items>
                    <!-- v-skeleton-loader
                            class="mx-auto mt-2"
                            max-width="900"
                            max-height="700"
                            type="article, actions"


                            ></-v-skeleton-loader -->
                </v-stepper>
            </v-app>

        </div>


    </div>
</template>





<script>
import Vuetify from "vuetify";
import "vuetify/dist/vuetify.min.css";
import Swal from "sweetalert2/dist/sweetalert2";
import "sweetalert2/src/sweetalert2.scss";
import Integer from "../../../inputFormats/IntegerComponent";
import Money from "../../../inputFormats/MoneyComponent";
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.min.css';
import vue2Dropzone from 'vue2-dropzone'
import 'vue2-dropzone/dist/vue2Dropzone.min.css'
import Stepper from 'bs-stepper';
import 'bs-stepper';
export default {
    vuetify: new Vuetify(),
    data() {
        return {
            e1: 1,
            vacancy: this.$attrs.vacancy,
            reqs: this.$attrs.reqs,
            url: '/transaction/job-application-process/',
            urlCat: '/cat/',
            uriProcess: '/cat/job-application/',
            uriCatalogBlood: '/cat/blood/list',
            genderSelected: '',
            genderListArray: [],
            loadingGender: false,
            maritalStatusSelected: '',
            maritalStatusArray: [],
            loadingMaritalStatus: false,
            stateSelected: '',
            stateStatusArray: [],
            loadingState: false,
            citySelected: '',
            cityArray: [],
            loadingCity: false,
            countrySelected: '',
            countryArray: [],
            loadingCity: false,
            firstName: '',
            secondName: '',
            thirdName: '',
            firstLastName: '',
            secondLastName: '',
            maritalLastName: '',
            fullName: '',
            address: '',
            dateBirth: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
            dateBirthFormatted: this.formatDate((new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10)),
            dialogBirthModal: false,
            dialogoEsperarAsignar: false,
            nowDate: new Date().toISOString().slice(0, 10),
            myAge: 0,
            maternLanguageSelected: '',
            maternLanguageArray: [],
            loadingMaternLanguage: false,
            secondaryLanguageSelected: '',
            secondaryLanguageArray: [],
            loadingSecondaryLanguage: false,
            isCityDisabled: true,
            employeeHeight: '',
            employeeWeight: '',
            employeeId: '',
            employeeTaxId: '',
            passportId: '',
            igssId: '',
            irtraId: '',
            vaccineSelected: '',
            vaccineArray: [
                { id: '0', name: 'Sin dosis aplicada' },
                { id: '1', name: 'Primera dosis' },
                { id: '2', name: 'Segunda dosis' },
                { id: '3', name: 'Tercera dosis' },
            ],
            loadingVaccine: false,
            employeeMail: '',
            employeePersonalMobilePhone: '',
            employeePersonalHomePhone: '',
            bloodTypeArr: [],
            bloodSelect: '',
            emergencyContactName: '',
            emergencyContactPhone: '',
            allergies: false,
            allergieDetails: '',
            ownHome: false,
            ownerName: '',
            ownerPhoneNumber: '',
            religion: '',
            loadClothJack: false,
            loadClothShirt: false,
            loadClothShoes: false,
            loadClothPant: false,
            clothJackArray: [],
            clothShirtArray: [],
            clothShoesArray: [],
            clothPantArray: [],
            clothJackSelected: '',
            clothShirtSelected: '',
            clothShoesSelected: '',
            clothPantSelected: '',
            familyNames: '',
            familyFirstLastName: '',
            familySecondLastName: '',
            familyDataDetail: [],
            relationShipSelected: '',
            relationShipData: [],
            loadingRelationShip: false,
            familyAddress: '',
            familyPhoneNumber: '',
            familyComment: '',
            familyBurnDate: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
            familyBurnDateFormatted: this.formatDate((new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10)),
            dialogfamilyBurnDateModal: false,
            relationName: '',
            armyService: false,
            aramyServiceTime: '',
            armyReasonUnregistration: '',
            pncService: false,
            pncServiceTime: '',
            pncReasonUnregistration: '',
            weaponHandling: false,
            typeWeapon: '',
            academicLevelArray: [],
            academicLevelSelected: null,
            loadingAcademicSelect: false,
            acreditationDataDetail: [],
            lastDegreeObtained: '',
            expireAccreditationDate: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
            expireAccreditationDateFormatted: this.formatDate((new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10)),
            dialogExpireAccreditationDateModal: false,
            acreditationName: '',
            institutionAccreditation: '',
            accreditationNumber: '',
            refPerFullName: '',
            refPerPhone: '',
            refPerAddress: '',
            refPerProfessionSelected: '',
            refPerProfessionArray: '',
            refPerProfessionLoad: false,
            perRefDetails: [],
            refLabCompanyName: '',
            refLabCompanyPhone: '',
            refLabCompanyAddress: '',
            refLabLastPosition: '',
            refLabLastBoss: '',
            refLabUnregReason: '',
            refLabLastSalary: '',
            refLabBeginDate: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
            refLabBeginDateFormatted: this.formatDate((new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10)),
            refLabBeginDateModal: false,
            refLabEndDate: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
            refLabEndDateFormatted: this.formatDate((new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10)),
            refLabEndDateModal: false,
            refLabDetails: [],
            hasArrested: false,
            reasonArrested: '',
            JudicialProcesses: '',
            medicalHistory: '',
            emergecyAdrress: '',
            emergencyContact: '',
            relationShipContact: '',
            polygraphTest: false,
            polygraphTestObservations: '',
            facebookUser: '',
            xUser: '',
            instagramUser: '',
            tiktokUser: '',
            secureBeneficiaryName: '',
            secureBeneficiaryAddress: '',
            secureBeneficiaryPhone: '',
            secureBeneficiaryRelationShip: '',
            hasTattoos: '',
            hasFamilyInCompany: false,
            familyInCompanyVacancySelect: '',
            CompanyVacancyArray: [],
            loadCompanyVacancy: false,
            familyInCompanyFullName: '',
            hasFriendInCompany: false,
            friendInCompanyVacancySelect: '',
            friendInCompanyFullName: '',
            useCuadra: false,
            bonusCourse: '',
            waitResponseSave: false,
            errorDPI: '',
            errorTax: '',
            errorVaccine: '',
            errorFirstName: '',
            errorFirstLastName: '',
            errorMaritalLastName:'',
            isValidated: true,
            selectedFiles: [],
            formValues: {},
            dropzoneOptions: {
                thumbnailWidth: 250,
                maxFilesize: 5,
                maxFiles:1,
                acceptedFiles:'application/pdf, .jpg, .png, .jpeg, .docx, .doc',
                autoProcessQueue: false,
                addRemoveLinks: true,
                dictRemoveFile: 'Remover selección',
                url:'#',
                dictDefaultMessage  : "<sub><i class='fa fa-file-pdf-o'></i> Haga clic aquí o arrastre el archivo Máximo 1 archivo de 5 MB de peso</sub>",
            },
            errorEmployeeHeight:'',
            errorEmployeeWeight:'',
            isFocusH:false,
            isFocusW:false,
            errorJacket:'',
            errorShirt:'',
            errorShoes:'',
            errorJeans:'',
            armyLastGrade:'',
            pncLastGrade:'',
            pmtService:false,
            pmtServiceTime:'',
            pmtReasonUnregistration:'',
            pmtLastGrade:'',

            expirationDpiDate: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
            expirationDpiDateFormatted: this.formatDate((new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10)),
            expirationDpiDateModal: false,

            expirationPassportDate: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
            expirationPassportDateFormatted: this.formatDate((new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10)),
            expirationPassportDateModal: false,

            expirationIgssDate: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
            expirationIgssDateFormatted: this.formatDate((new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10)),
            expirationIgssDateModal: false,

            expirationIrtraDate: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
            expirationIrtraDateFormatted: this.formatDate((new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10)),
            expirationIrtraDateModal: false,

            loadingDataSave:false,
            typeArmaArray: [
                { id: '1', name: 'Escopeta' },
                { id: '2', name: 'Pistola' },
                { id: '3', name: 'Revolver' },
            ],
            isDisabledButton:false,
            applicationId:0,
            applDataResp:[],
            employeeResp:[],
            data:{},
            generalData:{},
            shotGun:false,
            gun:false,
            revolver:false,
            arrTyme:[
                {id: '1', time: '0-1 años'},
                {id: '2', time: '2-5 años'},
                {id: '3', time: '6-10 años'},
                {id: '4', time: '11-15 años'},
                {id: '5', time: '16-20 años'},
                {id: '6', time: '21-30 años'},
            ],
            gunSelect:'',
            shotGunSelect:'',
            revolverSelect:'',



        }

    },
    computed: {
        computedDateFormatted() {
            return this.formatDate(this.date)
        },
    },

    watch: {
        dateBirth(val) {
            this.dateBirthFormatted = this.formatDate(this.dateBirth)
            this.validateAge(this.dateBirth)
        },

        familyBurnDate(val) {
            this.familyBurnDateFormatted = this.formatDate(this.familyBurnDate)
            //this.validateAge(this.familyBurnDate)
        },

        expireAccreditationDate() {
            this.expireAccreditationDateFormatted = this.formatDate(this.expireAccreditationDate)
        },


        refLabBeginDate() {
            this.refLabBeginDateFormatted = this.formatDate(this.refLabBeginDate)
        },

        refLabEndDate() {
            this.refLabEndDateFormatted = this.formatDate(this.refLabEndDate)
        },

        expirationDpiDate(){
            this.expirationDpiDateFormatted = this.formatDate(this.expirationDpiDate);
        },

        expirationPassportDate(){
            this.expirationPassportDateFormatted = this.formatDate(this.expirationPassportDate);
        },

        expirationIgssDate(){
            this.expirationIgssDateFormatted = this.formatDate(this.expirationIgssDate);
        },

        expirationIrtraDate(){
            this.expirationIrtraDateFormatted = this.formatDate(this.expirationIrtraDate);
        }


    },

    mounted() {
        localStorage.clear();
        this.gendersList();
        this.maritalStatusList();
        this.states();
        this.selectCountryNat();
        this.maternalLanguage();
        this.secondaryLanguage();
        this.sizeSeach('JACK');
        this.sizeSeach('SHIRT');
        this.sizeSeach('SHOES');
        this.sizeSeach('PANT');
        this.familyRelationShip();
        this.academicLevel();
        this.getVacancies();
        this.getLocalData();
        this.bloodType();
    },

    methods: {

        handleDropzoneSuccess(fieldId) {
            // Lógica para manejar el éxito de la carga de archivos en Dropzone
            // Puedes procesar aquí la respuesta del servidor si es necesario
            //console.log(`Archivo subido para el campo con ID ${fieldId}`);
        },

        formatDate(date) {
            if (!date) return null

            const [year, month, day] = date.split('-')
            return `${day}/${month}/${year}`
        },

        parseDate(date) {
            if (!date) return null

            const [day, month, year] = date.split('/')
            return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`
        },

        gendersList() {
            //this.loadingDataSave = true;
            this.loadingGender = true;
            axios.get(this.urlCat + 'genders/list')
                .then((response) => {
                    if (response.data.code == 200) {
                        this.genderListArray = response.data.data;
                        this.loadingGender = false;
                        //this.loadingDataSave = false;
                    }

                })
        },

        maritalStatusList() {
            this.loadingMaritalStatus = true
            axios.get(this.urlCat + 'marital/list')
                .then((response) => {
                    if (response.data.code == 200) {
                        //console.log(response.data.data);
                        this.maritalStatusArray = response.data.data;
                        this.loadingMaritalStatus = false;
                    }

                })
        },

        selectCountryNat() {

            this.loadingCity = true
            axios.get(this.urlCat + 'country/list')
                .then((response) => {
                    if (response.data.code == 200) {
                        this.countryArray = response.data.data;
                        this.loadingCity = false;
                    }

                })
        },

        states() {
            this.loadingState = true
            axios.get(this.urlCat + 'state/list')
                .then((response) => {
                    if (response.data.code == 200) {
                        this.stateStatusArray = response.data.data;
                        this.loadingState = false;
                    }

                })
        },

        selectCity(state) {
           this.firstName       =  this.firstName.toUpperCase();
           this.secondName      =  this.secondName.toUpperCase();
           this.firstLastName   =  this.firstLastName.toUpperCase();
           this.secondLastName  =  this.secondLastName.toUpperCase();
           this.thirdName       =  this.thirdName.toUpperCase();
           this.maritalLastName =  this.maritalLastName.toUpperCase();
            this.loadingCity = true
            this.isCityDisabled = false
            axios.get(this.urlCat + 'city/list/' + state)
                .then((response) => {
                    if (response.data.code == 200) {

                        this.cityArray = response.data.data;
                        this.loadingCity = false;
                    }

                })
        },

        setFullName() {

            let nameWord;

            if (this.genderSelected === 1 || (this.genderSelected === 2 && this.maritalStatusSelected === 2)) {
                nameWord = this.firstName + " " + this.secondName + " " + this.thirdName + " " + this.firstLastName + " " + this.secondLastName;

            }

            if (this.genderSelected === 2 && this.maritalStatusSelected === 1) {
                nameWord = this.firstName + " " + this.secondName + " " + this.thirdName + " " + this.firstLastName + " " + this.secondLastName + " de " + this.maritalLastName;


            }

            this.fullName = this.capitalizeString(nameWord);


        },

        capitalizeString: (str) => {

            let word = str.split(' ');

            let wordCapitalize = word.map(function (word) {
                return word.charAt(0).toUpperCase() + word.slice(1);
            });

            let resultado = wordCapitalize.join(' ');

            return resultado;
        },

        validateAge(born) {
            let dateNow = new Date().toISOString().substr(0, 10);
            this.myAge = this.calculateAge(born, dateNow);
            if (this.myAge < 18) {
                this.message("Debe ser mayor de edad", "error", "Error en edad");
            }
        },

        calculateAge: (birthDate, otherDate) => {
            birthDate = new Date(birthDate);
            otherDate = new Date(otherDate);

            var years = (otherDate.getFullYear() - birthDate.getFullYear());

            if (otherDate.getMonth() < birthDate.getMonth() ||
                otherDate.getMonth() === birthDate.getMonth() && otherDate.getDate() < birthDate.getDate()) {
                years--;
            }

            //console.log(years)
            return years;
        },

        maternalLanguage() {
            this.loadingMaternLanguage = true
            axios.get(this.urlCat + 'languages/list')
                .then((response) => {
                    if (response.data.code == 200) {
                        this.maternLanguageArray = response.data.data;
                        this.loadingMaternLanguage = false;
                    }

                })
        },

        secondaryLanguage() {
            this.loadingSecondaryLanguage = true
            axios.get(this.urlCat + 'languages/list')
                .then((response) => {
                    if (response.data.code == 200) {
                        this.secondaryLanguageArray = response.data.data;
                        this.loadingSecondaryLanguage = false;
                    }

                })

        },

        validateMail: (mail) => {
            // Expresión regular para validar un correo electrónico
            var re = /\S+@\S+\.\S+/;
            if (!re.test(mail)) {
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: "El correo no tienen un formato correcto por favor verifique esta información",
                    showConfirmButton: false,
                    timer: 3000
                })
            }

        },

        sizeSeach(type) {

            if (type == 'JACK') {
                this.loadClothJack = true
            }
            if (type == 'SHIRT') {
                this.loadClothShirt = true
            }
            if (type == 'SHOES') {
                this.loadClothShoes = true
            }
            if (type == 'PANT') {
                this.loadClothPant = true
            }

            axios.get(this.urlCat + 'size/list/' + type)
                .then((response) => {
                    if (type == 'JACK') {
                        this.clothJackArray = response.data.data
                    }
                    if (type == 'SHIRT') {
                        this.clothShirtArray = response.data.data
                    }
                    if (type == 'SHOES') {
                        this.clothShoesArray = response.data.data
                    }
                    if (type == 'PANT') {
                        this.clothPantArray = response.data.data
                    }

                }).finally(() => {
                    if (type == 'JACK') {
                        this.loadClothJack = false
                    }
                    if (type == 'SHIRT') {
                        this.loadClothShirt = false
                    }
                    if (type == 'SHOES') {
                        this.loadClothShoes = false
                    }
                    if (type == 'PANT') {
                        this.loadClothPant = false
                    }
                })
        },

        familyRelationShip() {
            this.loadingRelationShip = true
            axios.get(this.urlCat + 'relationship/list')
                .then((response) => {
                    if (response.data.code == 200) {
                        this.relationShipData = response.data.data;
                        this.loadingRelationShip = false;
                    }

                })

        },

        deleteDetails(index, type) {
            if (type == 1) {
                this.familyDataDetail.splice(index, 1);
            }

            if (type == 2) {
                this.acreditationDataDetail.splice(index, 1);
            }

            if (type == 3) {
                this.perRefDetails.splice(index, 1);
            }

            if (type == 4) {
                this.refLabDetails.splice(index, 1);
            }



        },

        addAccreditationDetail(accreName, accreInst, accreNumber, accreExpireDate) {

            let date = new Date(accreExpireDate);
            let getDay = date.getDate();
            let formatDay = (getDay < 10) ? formatDay = '0' + getDay : getDay;
            let monthDate = date.getMonth() + 1;
            let yearDate = date.getFullYear();
            let fullDate = formatDay + "/" + monthDate + "/" + yearDate

            this.acreditationDataDetail.push({
                accreditation_name: accreName,
                accreditation_institution: accreInst,
                accreditation_number: accreNumber,
                expire_date: fullDate,
            })

            this.acreditationName = ''
            this.institutionAccreditation = ''
            this.accreditationNumber = ''
            this.expireAccreditationDate = (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10)

        },

        addFamilyMember(
            familyNames,
            familyFirstLastName,
            familySecondLastName,
            familyAddress,
            familyPhoneNumber,
            relationShipSelected,
            familyBurnDate,
            familyComment) {

            let relShipName = '';

            switch (relationShipSelected) {
                case 1:
                    relShipName = 'PADRE';
                    break;
                case 2:
                    relShipName = 'MADRE';
                    break;
                case 3:
                    relShipName = 'HIJO(A)';
                    break;
                case 4:
                    relShipName = 'CONYUGE';
                    break;
            }




            this.familyDataDetail.push({
                names: familyNames.toUpperCase(),
                first_last_name: familyFirstLastName.toUpperCase(),
                second_las_name: familySecondLastName.toUpperCase(),
                family_address: familyAddress.toUpperCase(),
                family_phone_number: familyPhoneNumber,
                family_relation_ship: relationShipSelected,
                birth_date: familyBurnDate,
                familu_comment: familyComment.toUpperCase(),
                relationShipName: relShipName

            })

            this.familyNames = '';
            this.familyFirstLastName = '';
            this.familySecondLastName = '';
            this.familyAddress = '';
            this.familyPhoneNumber = '';
            this.relationShipSelected = '';
            this.dialogfamilyBurnDateModal = new Date().toISOString().slice(0, 10);
            this.familyComment = ''



        },

        academicLevel() {
            this.loadingAcademicSelect = true
            axios.get(this.urlCat + 'academic-level/list')
                .then((response) => {
                    if (response.data.code == 200) {
                        this.academicLevelArray = response.data.data;
                        this.loadingAcademicSelect = false;
                    }

                })

        },

        addRefPer(
            refPerFullName,
            refPerPhone,
            refPerAddress,
            refPresonalProfessionSelected) {



            this.perRefDetails.push({
                personal_full_name: refPerFullName,
                phone_number: refPerPhone,
                address: refPerAddress,
                occupation_id: refPresonalProfessionSelected,
            })

            this.refPerFullName = ''
            this.refPerPhone = ''
            this.refPerAddress = ''
            this.refPerProfessionSelected = ''


        },

        addRefLab(
            refLabCompanyName,
            refLabCompanyPhone,
            refLabCompanyAddress,
            refLabLastPosition,
            refLabLastBoss,
            refLabUnregReason,
            refLabBeginDate,
            refLabEndDate,) {



            this.refLabDetails.push({
                laboral_company_name: refLabCompanyName,
                phone_number: refLabCompanyPhone,
                address: refLabCompanyAddress,
                start_date_work: refLabBeginDate,
                end_date_work: refLabEndDate,
                unregistration_reason: refLabUnregReason,
                inmediate_last_boss: refLabLastBoss,
                last_position_held: refLabLastPosition


            })

            this.refLabCompanyName = ''
            this.refLabCompanyPhone = ''
            this.refLabCompanyAddress = ''
            this.refLabBeginDate = new Date().toISOString().slice(0, 10);
            this.refLabEndDate = new Date().toISOString().slice(0, 10);
            this.refLabUnregReason = ''
            this.refLabLastBoss = ''
            this.refLabLastPosition = ''


        },

        getVacancies() {

            this.loadCompanyVacancy = true
            axios.get(this.urlCat + 'vacancies/list')
                .then((response) => {
                    if (response.data.code == 200) {
                        this.CompanyVacancyArray = response.data.data;
                        this.loadCompanyVacancy = false;
                        //console.log(this.CompanyVacancyArray)
                    }

                })
        },

        saveIds() {

            //console.log(appl);
            let appl = JSON.parse(localStorage.getItem("applicationJob"))
            if(this.employeeId.length > 0 && this.employeeId.length === 13 &&   this.employeeTaxId.length >= 5){

                   this.data = {
                        document_dpi            : this.employeeId,
                        document_dpi_expiration : this.expirationDpiDate,
                        tax_number              : (this.employeeTaxId == '') ? '----': this.employeeTaxId,
                        irtra_number            : (this.irtraId === '') ? '----': this.irtraId,
                        irtra_expiration        : this.expirationIrtraDate,
                        passport_id             : (this.passportId === '') ? '----' : this.passportId ,
                        passport_expiration     : this.expirationPassportDate,
                        igss_number             : (this.igssId === '') ? '----' : this.igssId,
                        igss_expiration         : this.expirationIgssDate,
                        vaccine_dose            : this.vaccineSelected,
                        company_id              : this.vacancy[0].company.id,
                        vacancy_id              : this.vacancy[0].id,
                        applId                  : (appl === null) ? 0 : appl.id,

                    }

                    //debugger;
                let localData = localStorage.getItem("employeeDataIDS");
                if(localData){

                    this.processSaveUpdate(this.data, 2)
                }else{

                    this.processSaveUpdate(this.data, 1)
                }
            }
            if(this.employeeId.length < 13){
                this.toastMessage('error', 'DPI no puede estar vacío');
                this.e1 = this.e1;
            }else if(this.employeeTaxId.length < 5){
                this.toastMessage('error', 'NIT no puede estar vacío');
                this.e1 = this.e1;
            }

            //this.processSaveUpdate(this.data, 1)

        },

        processSaveUpdate(data, type){

            this.messageProcessedInfo()
            if(type === 1){
                axios.post(`${this.uriProcess}save`,data)
                .then((response) =>{
                    //console.log(response)
                    console.log(this.urlProcess);
                    let resp = JSON.stringify(response.data.data)
                    let resAppl = JSON.stringify(response.data.applicationJob)
                    localStorage.setItem("employeeDataIDS", resp)
                    localStorage.setItem("applicationJob", resAppl);
                }).finally(()=>{
                    this.e1 = this.e1+1;
                    this.toastMessage('success','Puede continuar con la solicitud');
                })
            }

            if(type === 2){
                axios.post(`${this.uriProcess}update`, data)
                .then((response) =>{
                    console.log(response.data.data);
                    if(response.data.code === 200){
                        localStorage.removeItem("employeeDataIDS");
                        JSON.stringify(localStorage.setItem("employeeDataIDS", response.data.data));
                        this.e1 = this.e1+1;
                    }


                })
            }
        },

        cancel() {
            Swal.fire({
                title: '¡Cierre de solicitud seleccionado!',
                html: "Perderá todo lo que haya avazado en el llenado de esta solicitud. ¿Esta seguro(a) de querer dejar esta pantalla?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                cancelButtonText: 'Cancelar',
                confirmButtonText: 'Sí, Salir'
            }).then((result) => {
                if (result.isConfirmed) {

                    window.open('/login', '_self');

                }
            })
        },


        validateIdentityDpi(employeeId) {
            //(employeeId.length)

            if (employeeId.length < 13 || employeeId.length == 0) {
                this.errorDPI = 'DPI no puede ser vacío o menor de 13 digitos'
                //this.message(this.errorDPI, 'error', 'Validacion DPI falló')

            }

        },

        // Form validations per field
        validateTaxId(taxId) {
            if (taxId.length === 0 || taxId.length == 0) {
                this.errorTax = 'NIT debe ser completado, por favor verifique'

            }


        },

        validateFirstName(firstName) {
            if(firstName.length < 1 || firstName.length === 0){
                this.errorFirstName = 'Primer nombre del postulante es obligatorio'
                this.$refs.firstName.focus()
            }
        },

        validateFirstLastName(firstLastName) {
            if(firstLastName.length < 1 || firstLastName.length === 0){
                this.errorFirstLastName = 'Primer apellido del postulante es obligatorio'
                this.$refs.firstLastName.focus()
            }
        },

        validateMaritalLastName(maritalLastName) {
            if((maritalLastName.length < 1 || maritalLastName.length === 0) &&  (this.genderSelected === 2 && this.maritalStatusSelected === 1)){
                this.errorMaritalLastName = 'Apellido de casada de la postulante es obligatorio'
                this.$refs.maritalLastName.focus()
            }
        },

        validateEmployeeHeight(employeeHeight) {

            if(employeeHeight.length < 1 || employeeHeight.length === 0){
                this.errorEmployeeHeight = 'La altura del postulante es obligatoria'
                this.isFocusH = true
                //console.log(this.isFocusH)
            }else{this.isFocusH = false}
        },

        validateEmployeeWeight(employeeWeight) {

            if(employeeWeight.length < 1 || employeeWeight.length === 0){
                this.errorEmployeeWeight = 'El peso del postulante es obligatorio por favor consignar libras'
                this.isFocusW = true

            }else{
                this.isFocusW = false
            }
        },

        validateSize(type, field){
            console.log(field.length);
            //debugger
            if(field.length == undefined){

                this.isDisabledButton = false;

            }else{
                switch(type){
                case 1:
                        if(field.length < 1){
                            this.errorJacket  = "Es necesaria la talla de la chumpa";
                            this.$refs.clothJackSelected.focus();
                            this.isDisabledButton = true;

                        }
                break;
                case 2:
                    if(field.length < 1){
                        this.errorShirt = "Es necesaria la talla de la camisa";
                        this.$refs.clothShirtSelected.focus();
                        this.isDisabledButton = true;
                    }

                break;
                case 3:
                    if(field.length < 1){
                        this.errorShoes = "Es necesaria la los zapatos";
                        this.$refs.clothShoesSelected.focus();
                        this.isDisabledButton = true;
                    }
                break;
                case 4:

                    if(field.length < 1){
                        this.errorJeans = "Es necesaria la los zapatos";
                        this.$refs.clothPantSelected.focus();
                        this.isDisabledButton = true;
                    }
                break;

            }
         }


        },

        validaLocalization() { },
        validaEmergencyData() { },
        validaHomeData() { },
        validaFamilyData() { },
        validaServiceData() { },
        validaAcademicData() { },
        validaPersonalRefsData() { },
        validaLaboralRefsData() { },
        validaSecureData() { },
        validaAditionalData() { },

        message(message, icon, title) {
            Swal.fire({
                position: 'center',
                icon: icon,
                title: title,
                html: message,
                showConfirmButton: false,
                timer: 3500
            })
        },

        toastMessage(icon, message){
               const Toast =  Swal.mixin({
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.onmouseenter = Swal.stopTimer;
                    toast.onmouseleave = Swal.resumeTimer;
                }
                });
                Toast.fire({
                icon: icon,
                title: message
                });
        },

        messageProcessedInfo(){
            let timerInterval;
            Swal.fire({
                title: "Mensaje del sistema",
                html: "Un momento por favor se esta procesando la información",
                timer: 3500,
                timerProgressBar: false,
                didOpen: () => {
                    Swal.showLoading();
                    const timer = Swal.getPopup().querySelector("b");
                    timerInterval = setInterval(() => {
                        `${Swal.getTimerLeft()}`;
                    }, 100);
                },
                willClose: () => {
                    clearInterval(timerInterval);

                }
            }).then((result) => {
                /* Read more about handling dismissals below */
                if (result.dismiss === Swal.DismissReason.timer) {
                // console.log("I was closed by the timer");
                    this.toastMessage('warning', 'Puede continuar con la solicitud')
                }
            });
        },

        getLocalData(){
            this.employeeResp = JSON.parse(localStorage.getItem("employeeDataIDS"));
            this.applDataResp = JSON.parse(localStorage.getItem("applicationJob"));

            /* console.log(this.employeeResp[0])
            console.log("Application Data: ",this.applDataResp) */

            if(this.employeeResp && this.applDataResp){

                // alert("local")
                this.employeeId                         = this.employeeResp[0].document_dpi;
                this.employeeTaxId                      = this.employeeResp[0].tax_number;
                this.passportId                         = this.employeeResp[0].passport_id;
                this.igssId                             = this.employeeResp[0].igss_number;
                this.irtraId                            = this.employeeResp[0].irtra_number;
                this.expirationDpiDateFormatted         = this.formatDate(this.employeeResp[0].document_dpi_expiration) ;
                this.expirationIgssDateFormatted        = this.formatDate(this.employeeResp[0].igss_expiration);
                this.expirationIrtraDateFormatted       = this.formatDate(this.employeeResp[0].irtra_expiration);
                this.expirationPassportDateFormatted    = this.formatDate(this.employeeResp[0].passport_expiration);
                this.vaccineSelected                    = this.employeeResp[0].vaccine_dose;
                this.applicationId                      = this.applDataResp.id
            }
        },

        saveGeneralInfo(){
            this.messageProcessedInfo()

            let uri = `${this.uriProcess}update`;
            let apliId = JSON.parse(localStorage.getItem("applicationJob"));
            this.employeeResp = JSON.parse(localStorage.getItem("employeeDataIDS"));

            this.generalData = {
                first_name              : (this.firstName.length < 1) ? '' : this.firstName,
                second_name             : (this.secondName.length < 1) ? ' ' : this.secondName,
                third_name              : (this.thirdName.length < 1) ? ' ' : this.thirdName,
                first_last_name         : (this.firstLastName.length < 1) ? '' : this.firstLastName,
                second_last_name        : (this.secondLastName.length < 1) ? ' ' : this.secondLastName,
                marital_last_name       : (this.maritalLastName.length < 1) ? ' ' : this.maritalLastName,
                city_id                 : this.citySelected,
                shirt_size_id           : this.clothShirtSelected,
                pant_size_id            : this.clothPantSelected,
                jacket_size_id          : this.clothJackSelected,
                shoes_size_id           : this.clothShoesSelected,
                employee_weight         : this.employeeWeight,
                employee_height         : this.employeeHeight,
                religion                : this.religion,
                birth_date              : this.dateBirth,
                gender_id               : this.genderSelected,
                marital_status_id       : this.maritalStatusSelected,
                principal_language_id   : this.maternLanguageSelected,
                secondary_language_id   : this.secondaryLanguageSelected,
                applId                  : apliId.id,
            }

            axios.post(uri, this.generalData)
            .then((response) => {

                console.log(response.data)
                if(response.data.code == 200){
                    this.toastMessage('success', "Puede continuar con el proceso")
                }
                localStorage.setItem("employeeDataIDS", JSON.stringify(response.data.data))
            }).finally(()=>{
                this.e1 = this.e1+1;
            });
        },

        saveAddress(){
            this.messageProcessedInfo()

            let uri = `${this.uriProcess}update`;
            let apliId = JSON.parse(localStorage.getItem("applicationJob"));
            this.employeeResp = JSON.parse(localStorage.getItem("employeeDataIDS"));

            this.generalData = {
                applId                  : apliId.id,
                address                 : this.address,
                personal_email          : this.employeeMail,
                personal_mobile_number  : this.phone_number,
                personal_home_number    : this.employeePersonalHomePhone,
            }

            axios.post(uri, this.generalData)
            .then((response) => {

                console.log(response.data)
                if(response.data.code == 200){
                    this.toastMessage('success', "Puede continuar con el proceso")
                }
                localStorage.setItem("employeeDataIDS", JSON.stringify(response.data.data))
            }).finally(()=>{
                this.e1 = this.e1+1;
            });
        },



        bloodType(){
            axios.get(this.uriCatalogBlood).then((response)=>{
                this.bloodTypeArr = response.data.data
                console.log(response.data.data);
            })
        }




    },

    components: { Vuetify,
                    "v-text-field-integer": Integer,
                    "v-text-field-money": Money,
                    Multiselect,
                    Dropzone:vue2Dropzone
                 }


}

</script>
<style>
.scroll-div {
    overflow-y: scroll;
    max-height: 700px;

}
</style>
