<template>
    <div class="container-fluid">
        <v-app id="inspire">
            <template>
                <v-card>
                    <v-container grid-list-md>
                        <v-data-table
                            :headers="headers"
                            :items="languageArray"
                            :items-per-page="10"
                            class="elevation-1"
                            :search="search"
                            :footer-props="{
                                showFirstLastPage: true,
                                firstIcon: 'fas fa-angle-double-left',
                                lastIcon: 'fas fa-angle-double-right',
                                prevIcon: 'fas fa-angle-left',
                                nextIcon: 'fas fa-angle-right',
                                    'items-per-page-text':'Registros por página'
                                }"
                        >
                            <template v-slot:top>

                                <v-dialog
                                    v-model="dialogLanguage"
                                    max-width="700"
                                    persistent
                                >
                                    <v-card>
                                        <v-card-title class="text-h5">
                                            {{ dialogTitle }}
                                        </v-card-title>

                                        <v-card-text>

                                            <v-container>
                                                <v-row>
                                                    <v-col
                                                        cols-="12"
                                                        sm="12"
                                                        md="12"
                                                    >
                                                        <v-text-field
                                                            v-model="name"
                                                            label="Nombre"
                                                            @blur = "name = name.toUpperCase()"
                                                        >

                                                        </v-text-field>
                                                    </v-col>

                                                </v-row>
                                            </v-container>

                                        </v-card-text>

                                        <v-card-actions>
                                            <v-spacer></v-spacer>

                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <button
                                                        class="btn btn-primary mr-2"
                                                        @click="create"
                                                        v-if="isNew"
                                                    >
                                                    <i class="fas fa-save"></i>
                                                        Guardar
                                                    </button>
                                                    <button
                                                        class="btn btn-warning mr-2"
                                                        @click="updateLang(id)"
                                                        v-else

                                                    >
                                                    <i class="fas fa-sync-alt"></i>
                                                        Actualizar
                                                    </button>
                                                </div>


                                                <div class="col-lg-6">
                                                    <button
                                                        class="btn btn-danger"
                                                        @click="close"
                                                    >
                                                    <i class="fas fa-times-circle"></i>
                                                        Cerrar
                                                    </button>
                                                </div>

                                            </div>



                                            <v-spacer></v-spacer>

                                        </v-card-actions>
                                    </v-card>
                                </v-dialog>


                                <v-toolbar flat color="white">


                                    <button type="button" class="btn btn-primary" @click="newLang"> <i class="fas fa-plus-circle"></i> Crear</button>
                                    <!--                                                    <button type="button" class="btn btn-primary" @click="actualizar" v-else> <i class="fas fa-plus-circle"></i> Actualizar</button>-->

                                    <v-spacer></v-spacer>
                                    <v-text-field v-model="search" label="Buscar" single-line hide-details></v-text-field>


                                    <!-- Aqui van los dialogos    -->

                                </v-toolbar>
                            </template>

                            <template v-slot:item.name="{item}">
                                {{ item.name.toUpperCase() }}
                            </template>

                            <template v-slot:item.actions="{ item }">
                                <a class="btn btn-warning btn-sm pointerHand" @click="edit(item)">
                                    Editar
                                    <v-icon
                                        small
                                        class="mr-2"
                                        color="white"

                                    >
                                        fas fa-pen-square
                                    </v-icon>

                                </a>

                                <a class="btn btn-danger btn-sm pointerHand" @click="deleteLang(item)">
                                    Eliminar
                                    <v-icon
                                        small
                                        class="mr-2"
                                        color="white"

                                    >
                                        fas fa-trash-alt
                                    </v-icon>

                                </a>



                            </template>
                            <template v-slot:no-data>
                                <v-alert :value="true" color="error" icon="fas fa-exclamation-triangle" class="mt-2">
                                    No hay registros para mostrar
                                </v-alert>
                            </template>
                        </v-data-table>
                    </v-container>
                </v-card>
            </template>
        </v-app>
    </div>
</template>

<script>
import Vuetify from 'vuetify';
import "vuetify/dist/vuetify.min.css";
import Swal from "sweetalert2/dist/sweetalert2";
import "sweetalert2/src/sweetalert2.scss";
import Integer from "../../../inputFormats/IntegerComponent";
import Money from "../../../inputFormats/MoneyComponent";

    export default {
        vuetify: new Vuetify(),
        data() {
            return {
                search:'',
                headers:[],
                url: '/catalogs/language/',
                languageArray:[],
                isNew: true,
                dialogTitle:'',
                name:'',
                dialogLanguage:false,
                id:0,

            }
        },
        mounted() {
            this.cargarHeader();
        },
        methods: {

            cargarHeader(){
                this.headers = [
                    { text: "NOMBRE", align: "left", value: 'name' },
                    { text: "ACCIONES", align: "center", value: 'actions', sortable: false },
                ]

                this.list()

            },

            list(){

                let useURL = this.url+'list';
                axios.get(useURL).then(response => {
                    console.log(response.data);
                    this.languageArray = response.data.data
                })
            },


          deleteLang(item){
                //console.log(item.id);
                let processDelete;
                Swal.fire({
                    title: '¿Está seguro de eliminar?',
                    text: "¡No podrás revertir esto!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    cancelButtonText:'Cancelar',
                    confirmButtonText: 'Sí, eliminar'
                }).then((result) => {
                    if (result.isConfirmed) {
                        processDelete = this.deletePocess(item.id);
                        Swal.fire(
                            '¡Eliminado!',
                            'El idioma se ha eliminado correctamente.',
                            'success'
                        ).finally(() => {
                             this.clear();
                        })

                    }
                })
            },

            deletePocess(item){
                let useURL = this.url+'delete';
                axios.post(useURL, {
                     id: item
                    }).then(response => {
                    console.log(response.data);
                    if(response.data.code == 200){
                        return true;
                    }else{
                        return false;
                    }
                })
            },

            close(){
                this.clear();
            },

            create(){
                let useURL = this.url+'store';
                axios.post(useURL, {
                    name: this.name.toLocaleLowerCase()
                }).then(response => {
                    console.log(response.data);
                    if(response.data.code == 200)
                    this.dialogLanguage = false;
                    this.name = '';

                    Swal.fire({
                        position: 'top-end',
                        icon: 'success',
                        title: response.data.message,
                        showConfirmButton: false,
                        timer: 1500
                    }).finally(() => {
                        this.clear();
                    })
                })
            },

            newLang(){
                this.dialogTitle = 'Nuevo Idioma';
                this.dialogLanguage = true;
                this.isNew = true;
            },

            clear(){
              this.list();
              this.name = '';
              this.dialogLanguage = false;
              this.isNew = true;
            },

            edit(item){
                this.id             = item.id;
                this.name           = item.name;
                this.dialogTitle    = 'Editar Idioma';
                this.dialogLanguage = true;
                this.isNew          = false;

            },


            updateLang(){
                let useURL = this.url+'update';
                axios.post(useURL, {
                    id: this.id,
                    name: this.name.toLocaleLowerCase()
                }).then(response => {
                    console.log(response.data);
                    if(response.data.code == 200)
                    this.dialogLanguage = false;
                    this.name = '';

                    Swal.fire({
                        position: 'top-end',
                        icon: 'success',
                        title: response.data.message,
                        showConfirmButton: false,
                        timer: 1500
                    }).finally(() => {
                        this.clear();
                    })
                })
            }






        },
        components: {Vuetify, "v-text-field-integer": Integer, "v-text-field-money": Money}
    }
</script>

