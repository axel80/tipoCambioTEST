<template>
  <div>
    <label :for="inputId" class="file-input-label" :class="{ 'drag-over': isDragOver }">
      <span v-if="!selectedFiles.length">Seleccionar archivos</span>
      <span v-else>
        <template v-for="(file, index) in selectedFiles">
          <div :key="file.name" class="file-preview">
            <img
              v-if="isImage(file)"
              :src="getObjectURL(file)"
              alt="Preview"
              class="thumbnail"
              @click="openImagePreview(index)"
            />
            <div v-else class="non-image-preview">
              {{ file.name }}
            </div>
            <span class="remove-file" @click="removeFile(index)">x</span>
          </div>
        </template>
        <span class="clear-button" @click="clearFiles">Limpiar</span>
      </span>
    </label>
    <input
      ref="fileInput"
      :id="inputId"
      type="file"
      :multiple="multiple"
      :accept="acceptedFormats"
      @change="handleFileChange"
      @dragover.prevent="handleDragOver"
      @dragleave.prevent="handleDragLeave"
      @drop.prevent="handleDrop"
      style="display: none"
    />
  </div>
</template>

<script>
export default {
  props: {
    multiple: {
      type: Boolean,
      default: false,
    },
    acceptedFormats: {
      type: String,
      default: '',
    },
    maxFileSize: {
      type: Number,
      default: 10,
    },
  },
  data() {
    return {
      inputId: `file-input-${Date.now()}`,
      selectedFiles: [],
      isDragOver: false,
    };
  },
  methods: {
    handleFileChange() {
      const input = this.$refs.fileInput;
      const files = Array.from(input.files);

      this.selectedFiles = [...this.selectedFiles, ...files];

      // Emitir el evento para que el componente padre pueda manejar los archivos seleccionados
      this.$emit('files-selected', this.selectedFiles);

      // Limpiar el valor del input para que pueda seleccionar el mismo archivo nuevamente
      input.value = '';
    },
    handleDragOver() {
      this.isDragOver = true;
    },
    handleDragLeave() {
      this.isDragOver = false;
    },
    handleDrop(event) {
      this.isDragOver = false;
      const files = Array.from(event.dataTransfer.files);
      this.selectedFiles = [...this.selectedFiles, ...files];

      // Emitir el evento para que el componente padre pueda manejar los archivos seleccionados
      this.$emit('files-selected', this.selectedFiles);
    },
    isImage(file) {
      return file.type.startsWith('image/');
    },
    getObjectURL(file) {
      return URL.createObjectURL(file);
    },
    openImagePreview(index) {
      // Puedes implementar la lógica para abrir una vista previa de la imagen aquí
      console.log('Abriendo vista previa de la imagen:', this.selectedFiles[index]);
    },
    removeFile(index) {
      this.selectedFiles.splice(index, 1);
    },
    clearFiles() {
      this.selectedFiles = [];
      // Limpiar el valor del input para que pueda seleccionar el mismo archivo nuevamente
      this.$refs.fileInput.value = '';
    },
  },
};
</script>

<style scoped>
.file-input-label {
  display: inline-block;
  cursor: pointer;
  border: 1px solid #ced4da;
  border-radius: 4px;
  padding: 8px 12px;
  font-size: 14px;
  transition: border-color 0.3s ease-in-out;
}

.file-input-label.drag-over {
  border-color: #007bff;
}

.file-preview {
  display: inline-block;
  margin-right: 8px;
  position: relative;
}

.thumbnail {
  width: 80px;
  height: 80px;
  cursor: pointer;
}

.non-image-preview {
  width: 80px;
  height: 80px;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 1px solid #ddd;
  cursor: pointer;
}

.remove-file {
  position: absolute;
  top: 0;
  right: 0;
  cursor: pointer;
  background-color: rgba(255, 255, 255, 0.7);
  padding: 4px;
  border-radius: 0 4px 0 4px;
}

.clear-button {
  margin-left: 8px;
  cursor: pointer;
}
</style>
