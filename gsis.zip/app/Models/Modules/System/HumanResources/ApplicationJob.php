<?php

namespace App\Models\Modules\System\HumanResources;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ApplicationJob extends Model
{
    use HasFactory;

    protected $fillable = [
        'application_date',
        'vacancy_id',
        'status_application',
        'note',
        'employee_file_id'
    ];




    public function vacancy()
    {
        return $this->belongsTo(Vacancy::class);
    }

    public function employeeFile()
    {
        return $this->belongsTo(EmployeeFile::class, 'employee_file_id')->select('*');
    }
}
