<?php

namespace App\Models\Modules\System\HumanResources;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EmployeeFile extends Model
{
    use HasFactory;

    protected $table = 'employee_files';

    protected $fillable = [
        'code',
        'company_id',
        'active',
        'first_name',
        'second_name',
        'third_name',
        'first_last_name',
        'second_last_name',
        'gender_id',
        'academic_id',
        'company_employee_status', //CON = CONTRATADO, LN = LISTA NEGRA, LE = LISTA EN ESPERA, RC = RETIRADO PUEDE CONTRATAR, SO = SOLICITUD LABORAL
        'application_date',
        'hire_date',
        'start_date',
        'unregistration_date',
        'last_change_date',
        'type_bank_account',
        'bank_account',
        'bank_name',
        'notes',
        'address',
        'city_id',
        'army_services',
        'army_service_time',
        'army_service_unregistration_date',
        'army_reason_unregistration',
        'pnc_services',
        'pnc_service_time',
        'pnc_service_unregistration_date',
        'pnc_reason_unregistration',
        'document_dpi',
        'document_id_extend_city_id',
        'document_dpi_expiration',
        'marital_status_id',
        'ethnic_id',
        'exception_igss',
        'irtra_number',
        'irtra_expiration',
        'igss_number',
        'igss_expiration',
        'driver_license_number',
        'principal_language_id',
        'secondary_language_id',
        'has_children',
        'how_many_children',
        'total_people_depend',
        'emergency_contact_name',
        'emergency_contact_phone',
        'relationship_id',
        'photo_path',
        'reason_let_job',
        'carnet_number',
        'carnet_expiration_date',
        'company_email',
        'personal_email',
        'last_update_device_date',
        'universal_compensation',
        'allergies',
        'describe_allergies',
        'blood_type_id',
        'religion',
        'own_home',
        'homeowner_phone_number',
        'shirt_size_id',
        'pant_size_id',
        'jacket_size_id',
        'shoes_size_id',
        'employee_height',
        'employee_weight',
        'vaccine_dose',
        'personal_mobile_number',
        'personal_home_number',
        'user_id',
        'last_degree_earned',
        'weapons_handling',
        'type_weapons',
        'tottoos',
        'tottoos_visibility',
        'meaning_tottoo',
        'picture_tattoo',
        'shot_gun_id',
        'shot_gun_time',
        'gun_id',
        'gun_time',
        'revolver_id',
        'revolver_time',
        'army_last_grade',
        'pnc_last_grade',
        'pmt_last_grade',
        'pmt_services',
        'pmt_service_time',
        'pmt_service_unregistration_date',
        'pmt_reason_unregistration',
        'tax_number',
        'passport_id',
        'passport_expiration'

    ];


    /**
     *
     * 'company_id'
     * 'gender_id'
     * 'academic_id'
     * 'city_id'
     * 'document_id_extend_city_id'
     * 'marital_status_id'
     * 'ethnic_id'
     * 'principal_language_id'
     * 'secondary_language_id'
     * 'relationship_id'
     * 'blood_type_id'
     * 'shirt_size_id'
     * 'pant_size_id'
     * 'jacket_size_id'
     * 'shoes_size_id'
     * 'user_id'
     * 'shot_gun_id'
     * 'gun_id'
     * 'revolver_id'
     **/

    public function ApplicationJob()
    {
        return $this->hasMany(ApplicationJob::class, 'employee_file_id', 'id');
    }
}
