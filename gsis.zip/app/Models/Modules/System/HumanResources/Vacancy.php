<?php

namespace App\Models\Modules\System\HumanResources;

use App\Models\Catalogs\SystemCruds\AcademicLevel;
use App\Models\Catalogs\SystemCruds\CompanyCat;
use App\Models\Catalogs\SystemCruds\Occupation;
use App\Models\Catalogs\SystemCruds\Status;
use App\Models\Catalogs\SystemCruds\WorkingDay;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Models\User;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Vacancy extends Model
{
    use HasFactory;




    protected $table = 'vacancies';

    protected $fillable = [
        'name',
        'description_vacancy',
        'number_vacancy_available',
        'number_filled_vacancies',
        'aprove_date',
        'publication_date',
        'public_vacancy',
        'private_vacancy',
        'additional_notes',
        'approved_salary',
        'incentive_bonus',
        'productivity_bonus',
        'active',
        'comment_validate',
        'comment_approve',
        'user_create_id',
        'user_validate_id',
        'user_appove_id',
        'occupation_id',
        'academic_level_id',
        'working_day_id',
        'slug',
        'status_id',
        'company_id'
    ];

    public function occupation(): BelongsTo
    {
        return $this->belongsTo(Occupation::class, 'occupation_id');
    }

    public function academicLevel(): BelongsTo
    {
        return $this->belongsTo(AcademicLevel::class, 'academic_level_id');
    }

    public function workingDay(): BelongsTo
    {
        return $this->belongsTo(WorkingDay::class, 'working_day_id');
    }

    public function userCreate(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_create_id');
    }

    public function userValidate(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_validate_id');
    }

    public function userApprove(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_approve_id');
    }

    public function status(): BelongsTo
    {
        return $this->belongsTo(Status::class)->select('id', 'name');
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(CompanyCat::class, 'company_id', 'id');
    }


    // BelongsToMany
    public function requirements(): BelongsToMany
    {
        return $this->belongsToMany(JobRequirement::class, 'vacancies_requirements', 'vacancy_id', 'job_requirement_id')
            ->withPivot('vacancy_id', 'job_requirement_id');
    }


    // Has Many
    public function applicationJob(){
        return $this->hasMany(ApplicationJob::class);
    }
}
