<?php

namespace App\Models\Modules\System\HumanResources;

use App\Models\Catalogs\SystemCruds\AcademicLevel;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VacancyRequirement extends Model
{
    use HasFactory;

    public $timestamps = false;
    protected $table = 'vacancies_requirements';

    protected $fillable = [
        'vacany_id',
        'job_requirement_id'
    ];
}
