<?php

namespace App\Models\Modules\System\HumanResources;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TypeWeapon extends Model
{
    use HasFactory;

    protected $table = 'type_weapons';

    protected $fillable = [
        'name',
        'caliber'
    ];
}
