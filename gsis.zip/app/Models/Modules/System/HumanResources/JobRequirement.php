<?php

namespace App\Models\Modules\System\HumanResources;


use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class JobRequirement extends Model
{
    use HasFactory;

    // enum TypeData => "FIELD", "TEXT", "TEXTAREA", "BOOL" ;

    protected $table = 'job_requirements';

    protected $fillable = [
        'name',
        'mandatory',
        'type'
    ];

    public function vacancy(): BelongsToMany
    {
        return $this->belongsToMany(Vacancy::class, 'vacancy_requirements', 'vacancy_id', 'job_requirement_id')->withPivot('vacancy_id', 'job_requirement_id');
    }
}
