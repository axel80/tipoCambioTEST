<?php

namespace App\Models\Modules\System\HumanResources;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WorkerFileType extends Model
{
    use HasFactory;
}
