<?php

namespace App\Models\Catalogs\SystemCruds;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Modules\System\HumanResources\Vacancy; // Import the Vacancy class

class AcademicLevel extends Model
{
    use HasFactory;
    protected $table = 'academic_levels';





    public function vacancies()
    {
        return $this->hasMany(Vacancy::class);
    }
}
