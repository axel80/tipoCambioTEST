<?php

namespace App\Models\Catalogs\SystemCruds;

use App\Models\Modules\System\HumanResources\EmployeeFile;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BloodType extends Model
{
    use HasFactory;

    protected $fillable = [
        'grupo',
        'active'
    ];


    public function employeeFile()
    {
        return $this->hasMany(EmployeeFile::class);
    }
}
