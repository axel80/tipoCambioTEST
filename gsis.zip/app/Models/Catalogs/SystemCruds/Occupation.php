<?php

namespace App\Models\Catalogs\SystemCruds;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Modules\System\HumanResources\Vacancy; // Import the Vacancy class

class Occupation extends Model
{
    use HasFactory;

    public function vacancies()
    {
        return $this->hasMany(Vacancy::class, 'occupation_id')->select('id', 'name');
    }
}
