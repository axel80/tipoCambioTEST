<?php

namespace App\Models\Catalogs\SystemCruds;

use App\Models\Modules\System\HumanResources\Vacancy;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class CompanyCat extends Model
{
    use HasFactory;

    protected $table = 'company_cats';




    public function vacancy(): HasMany
    {
        $this->hasMany(Vacancy::class, 'company_id');
    }
}
