<?php

namespace App\Models\Catalogs\SystemCruds;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LanguageApp extends Model
{
    use HasFactory;

    protected $table = 'languages_apps';


    protected $fillable = [
        'name'
    ];
}
