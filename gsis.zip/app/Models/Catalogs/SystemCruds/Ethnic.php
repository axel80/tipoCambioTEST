<?php

namespace App\Models\Catalogs\SystemCruds;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ethnic extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'local_code',
        'short_name'
    ];
}
