<?php

namespace App\Http\Controllers\Catalogs\SystemCruds;

use App\Http\Controllers\Controller;
use App\Models\Modules\System\HumanResources\JobRequirement;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class JobRequirementController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('modules.catalogs.jobRequirement.list');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //dd($request);
        $req = new JobRequirement();
        $req->name      = strtolower($request->name);
        $req->mandatory = $request->mandatory;
        $req->type      = $request->type['value'];
        $req->save();

        return response()->json([
            'code' => 200,
            'data' => $req,
            'message' => 'El requerimiento se ha creado correctamente'
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        //dd($request);
        $updateReq = JobRequirement::find($request->id);
        $updateReq->fill($request->all());
        $updateReq->type = $request->type;
        $updateReq->save();

        return response()->json([
            'code' => 200,
            'data' => $updateReq,
            'message' => 'El idioma se ha actualizado correctamente'
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $requDelete = JobRequirement::find($request->id);
        $requDelete->delete();

        return response()->json([
            'code' => 200,
            'data' => $requDelete,
            'message' => 'El requerimiento se ha eliminado correctamente'
        ]);
    }


    public function getReqList()
    {
        $jobReqs = JobRequirement::select('id', DB::raw("upper(name) as name"), 'mandatory', 'type')->get();

        $data = [
            'code' => 200,
            'data' => $jobReqs
        ];

        return response()->json($data);
    }
}
