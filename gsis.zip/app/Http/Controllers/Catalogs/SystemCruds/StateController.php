<?php

namespace App\Http\Controllers\Catalogs\SystemCruds;

use App\Http\Controllers\Controller;
use App\Models\Catalogs\SystemCruds\City;
use App\Models\Catalogs\SystemCruds\ClothingSize;
use App\Models\Catalogs\SystemCruds\Country;
use App\Models\Catalogs\SystemCruds\FamilyRalationShip;
use App\Models\Catalogs\SystemCruds\LanguageApp;
use App\Models\Catalogs\SystemCruds\State;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class StateController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


    public function listCountryNationality()
    {

        $countryNationality = Country::select('id', DB::raw(" CONCAT(upper(name),' - ' ,upper(nationality) ) as national_name"))->get();

        $data = [
            'code' => 200,
            'data' => $countryNationality
        ];

        return response()->json($data);
    }



    public function listStates()
    {

        $states = State::select('id', DB::Raw("upper(name) as name"))->get();

        $data = [
            'code' => 200,
            'data' => $states
        ];

        return response()->json($data);
    }
    public function listCities($state)
    {

        $cities = City::select('id', DB::Raw("upper(name) as name"))->where('state_id', $state)->get();

        $data = [
            'code' => 200,
            'data' => $cities
        ];

        return response()->json($data);
    }

    public function languagesList()
    {
        $languages = LanguageApp::select('id', DB::Raw("upper(name) as name"))->get();

        $data = [
            'code' => 200,
            'data' => $languages
        ];

        return response()->json($data);
    }

    public function sizeCloth($type)
    {
        $clothing = ClothingSize::select('id', DB::Raw("upper(name) as name"))
            ->where('type', $type)->get();

        $data = [
            'code' => 200,
            'data' => $clothing
        ];

        return response()->json($data);
    }
    public function relationShip()
    {
        $relationShips = FamilyRalationShip::select('id', DB::Raw("upper(name) as name"))->get();

        $data = [
            'code' => 200,
            'data' => $relationShips
        ];

        return response()->json($data);
    }


    public function getRelName($id)
    {
        $relationShipsName = FamilyRalationShip::select(DB::Raw("upper(name) as name"))
            ->where('id', $id)->get();

        $data = [
            'code' => 200,
            'data' => $relationShipsName
        ];

        return response()->json($data);
    }
}
