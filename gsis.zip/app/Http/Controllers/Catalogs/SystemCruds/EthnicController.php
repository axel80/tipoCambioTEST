<?php

namespace App\Http\Controllers\Catalogs\SystemCruds;

use App\Http\Controllers\Controller;
use App\Models\Catalogs\SystemCruds\Ethnic;
use Illuminate\Http\Request;

class EthnicController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('modules.catalogs.ethnics.list');
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $ethnic = new Ethnic($request->all());
        $ethnic->save();

        return response()->json([
            'code' => 200,
            'data' => $ethnic,
            'message' => 'La etnia se ha creado correctamente'
        ]);
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $updateEthnic = Ethnic::find($request->id);
        $updateEthnic->fill($request->all());
        $updateEthnic->save();

        return response()->json([
            'code' => 200,
            'data' => $updateEthnic,
            'message' => 'La etnia se ha actualizado correctamente'
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $ethnic = Ethnic::find($request->id);
        $ethnic->delete();

        return response()->json([
            'code' => 200,
            'data' => $ethnic,
            'message' => 'La etnia se ha eliminado correctamente'
        ]);
    }

    public function getEthnicList()
    {
        $ethnics = Ethnic::all();

        $data = [
            'code' => 200,
            'data' => $ethnics,
            'message' => "Datos cargados con éxito"
        ];

        return response()->json($data);
    }
}
