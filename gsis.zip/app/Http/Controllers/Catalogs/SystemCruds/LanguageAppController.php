<?php

namespace App\Http\Controllers\Catalogs\SystemCruds;

use App\Http\Controllers\Controller;
use App\Models\Catalogs\SystemCruds\LanguageApp;
use Illuminate\Http\Request;

class LanguageAppController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('modules.catalogs.languagesApp.languages-app-list');
    }



    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $language = new LanguageApp($request->all());
        $language->save();

        return response()->json([
            'code' => 200,
            'data' => $language,
            'message' => 'El idioma se ha creado correctamente'
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $updateLanguage = LanguageApp::find($request->id);
        $updateLanguage->fill($request->all());
        $updateLanguage->save();

        return response()->json([
            'code' => 200,
            'data' => $updateLanguage,
            'message' => 'El idioma se ha actualizado correctamente'
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {

        $language = LanguageApp::find($request->id);
        $language->delete();

        return response()->json([
            'code' => 200,
            'data' => $language,
            'message' => 'El idioma se ha eliminado correctamente'
        ]);
    }

    public function getLangList()
    {
        $languages = LanguageApp::all();

        $data = [
            'code' => 200,
            'data' => $languages
        ];

        return response()->json($data);
    }
}
