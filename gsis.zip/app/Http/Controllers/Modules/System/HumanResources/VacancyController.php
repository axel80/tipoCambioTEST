<?php

namespace App\Http\Controllers\Modules\System\HumanResources;

use App\Http\Controllers\Controller;
use App\Models\Modules\System\HumanResources\JobRequirement;
use App\Models\Modules\System\HumanResources\Vacancy;
use App\Models\Modules\System\HumanResources\VacancyRequirement;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;



class VacancyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('modules.maintanance.vacancy-module.list');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('modules.maintanance.vacancy-module.form');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        try {

            DB::beginTransaction();
            $vacancy = new Vacancy();
            $vacancy->name                      = strtolower($request->name);
            $vacancy->description_vacancy       = $request->description_vacancy;
            $vacancy->number_vacancy_available  = intval($request->number_vacancy_available);
            $vacancy->number_filled_vacancies   = intval($request->number_filled_vacancies);
            $vacancy->public_vacancy            = $request->public_vacancy;
            $vacancy->private_vacancy           = $request->private_vacancy;
            $vacancy->approved_salary           = $request->approved_salary;
            $vacancy->incentive_bonus           = $request->incentive_bonus;
            $vacancy->productivity_bonus        = $request->productivity_bonus;
            $vacancy->occupation_id             = $request->occupation_id;
            $vacancy->academic_level_id         = $request->academic_level_id;
            $vacancy->working_day_id            = $request->working_day_id;
            $vacancy->company_id                = $request->company_id;
            $vacancy->user_create_id            = Auth::user()->id;
            $vacancy->slug                      = Str::slug($vacancy->name, '-');
            $vacancy->status_id                 = 1;
            $vacancy->active                    = true;
            $vacancy->save();

            //dd($request->requirements);

            $reqs =  $request->requirements;
            for ($i = 0; $i < sizeof($reqs); $i++) {
                $requirement = new VacancyRequirement();
                $requirement->vacancy_id = $vacancy->id;
                $requirement->job_requirement_id = $reqs[$i]['id'];
                $requirement->save();
            }


            DB::commit();

            return response()->json([
                'code' => 200,
                'data' => $vacancy,
                'icon' => 'success',
                'message' => 'La vacante ha sido creada exitosamente'
            ]);
        } catch (\Throwable $error) {
            DB::rollBack();
            //Log::error($error);
            logger("Error:: Error al crear la vacante" . $error->getMessage());
            logger("Error:: Error al crear la vacante linea -->" . $error->getLine());
            return response()->json([

                'code' => 205,
                'icon' => 'error',
                'message' => 'La vacante no se puede crear temporamente revise su informacion y vuelva mas tarde',
                'errorMessage' => $error->getMessage(),
                'errorLine' => $error->getLine()
            ]);
        }
    }

    public function edit($id)
    {

        $vacancy = Vacancy::find($id);
        $vacancyReqs = VacancyRequirement::where('vacancies_requirements.vacancy_id', $id)
            ->select('req.id', DB::raw(" upper(req.name) as name"))
            ->join('job_requirements as req', 'vacancies_requirements.job_requirement_id', '=', 'req.id')
            ->get();

        return view('modules.maintanance.vacancy-module.form-edit')
            ->with('vacancy',  $vacancy)
            ->with('vacancyReqs', $vacancyReqs);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        try {
            DB::beginTransaction();

            //dd($request->all());

            VacancyRequirement::where('vacancy_id', '=', $request->id)->delete();

            $reqs = $request->requirements;

            for ($i = 0; $i < sizeof($reqs); $i++) {
                //var_dump($reqs[$i]['id']);
                $req                     = new VacancyRequirement();
                $req->vacancy_id         = $request->id;
                $req->job_requirement_id = $reqs[$i]['id'];
                $req->save();
            }

            $vacancyUpdate                              = Vacancy::find($request->id);
            $vacancyUpdate->name                        = $request->name;
            $vacancyUpdate->description_vacancy         = $request->description_vacancy;
            $vacancyUpdate->number_vacancy_available    = $request->number_vacancy_available;
            $vacancyUpdate->number_filled_vacancies     = $request->number_filled_vacancies;
            $vacancyUpdate->public_vacancy              = $request->public_vacancy;
            $vacancyUpdate->private_vacancy             = $request->private_vacancy;
            $vacancyUpdate->approved_salary             = $request->approved_salary;
            $vacancyUpdate->incentive_bonus             = $request->incentive_bonus;
            $vacancyUpdate->productivity_bonus          = $request->productivity_bonus;
            $vacancyUpdate->occupation_id               = $request->occupation_id;
            $vacancyUpdate->academic_level_id           = $request->academic_level_id;
            $vacancyUpdate->working_day_id              = $request->working_day_id;
            $vacancyUpdate->user_create_id              = $request->user_create_id;
            $vacancyUpdate->company_id                  = $request->company_id;
            $vacancyUpdate->slug                        = Str::slug($request->name, '-');
            $vacancyUpdate->update();

            DB::commit();

            $data = [
                'code'      => 200,
                'message'   => 'La vacante ha sido actualizada exitosamente',
                'icon'      => 'success'
            ];

            return response()->json($data);
        } catch (\Throwable $error) {

            logger('ahsozco_logger -> Error ocurrido en la línea: ' . $error->getLine());
            logger('ahsozco_logger -> Error codigo de error: ' . $error->getCode());
            logger('ahsozco_logger -> Error al actualizar la plaza: ' . $error->getMessage());
            DB::rollBack();

            $data = [
                'code' => 504,
                'message' => 'No fue posible guardar la información por favor intente mas tarde',
                'icon' => 'error'
            ];

            return response()->json($data);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $vacancy = Vacancy::find($request->id);
        $vacancy->active = false;
        $vacancy->update();


        return response()->json([
            'code' => 200,
            'data' => $vacancy,
            'message' => 'La vacante se ha eliminada correctamente'
        ]);
    }

    public function getVacancyList()
    {
        $vacancies = Vacancy::where('active', true)->with(['status', 'requirements'])->get();
        $data = [
            'code' => 200,
            'data' => $vacancies,

        ];
        return response()->json($data);
    }
    public function getVacancyApplyList()
    {
        $vacancies = Vacancy::select('id', 'name')->where('active', true)->get();
        $data = [
            'code' => 200,
            'data' => $vacancies,

        ];
        return response()->json($data);
    }



    public function jobApplication($slug)
    {
        $vacancyApply = Vacancy::select('id', 'name', 'description_vacancy', 'academic_level_id', 'occupation_id', 'slug')
            ->where('slug', $slug)->get();

        $requirements = VacancyRequirement::select('job_requirement_id')->where('vacancy_id', $vacancyApply[0]['id'])->get();
        //  dd($requirements[1]['job_requirement_id']);
        $reqArr = [];
        for ($i = 0; $i < sizeof($requirements); $i++) {

            $reqs = JobRequirement::select('id', 'name', 'mandatory', 'type')->where('id', $requirements[$i]['job_requirement_id'])->get();
            array_push($reqArr, $reqs);
        }


        $data = [
            'code' => 200,
            'vacancy' => $vacancyApply,
            'requirements' => $reqArr,


        ];

        return response()->json($data);
    }
}
