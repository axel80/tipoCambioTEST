<?php

namespace App\Http\Controllers\Modules\System\HumanResources;

use App\Http\Controllers\Controller;
use App\Models\Catalogs\SystemCruds\BloodType;
use App\Models\Modules\System\HumanResources\ApplicationJob;
use App\Models\Modules\System\HumanResources\EmployeeFile;
use App\Models\Modules\System\HumanResources\JobRequirement;
use App\Models\Modules\System\HumanResources\Vacancy;
use App\Models\Modules\System\HumanResources\VacancyRequirement;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class JobApplicationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($slug)
    {


        $vacancyApply = Vacancy::select('id', 'name', 'description_vacancy', 'academic_level_id', 'occupation_id', 'company_id', 'slug')
            ->with(['academicLevel', 'occupation', 'company'])
            ->where('active', true)
            ->where('slug', $slug)->get();

        //dd($vacancyApply);

        if ($vacancyApply->count() < 1) {
            return redirect()->route('home');
        }

        $requirements = VacancyRequirement::select('job_requirement_id')->where('vacancy_id', $vacancyApply[0]['id'])->get();
        //  dd($requirements[1]['job_requirement_id']);
        $reqArr = [];
        for ($i = 0; $i < sizeof($requirements); $i++) {

            $reqs = JobRequirement::select('id', 'name', 'mandatory', 'type')->where('id', $requirements[$i]['job_requirement_id'])->get();
            array_push($reqArr, $reqs);
        }

        $collectionReq = collect($reqArr);


        return view('modules.transaction.job-application')
            ->with('vacancy', $vacancyApply)
            ->with('reqArrs', $collectionReq);
    }



    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        try {
            DB::beginTransaction();
            $getDataPrevius = EmployeeFile::select('code')->orderBy('id', 'desc')->first();
            //dd($getDataPrevius[0]);
            $code = $getDataPrevius;



            if (empty($code)) {
                $code = 1;
            } else {
                //dd($code->code);
                $code = intval($code->code) + 1;
            }


            $dataResponse = new EmployeeFile($request->all());
            $dataResponse->code = $code;
            $dataResponse->passport_id  = ($request->passport_id == null) ? '----' : $request->passport_id;
            $dataResponse->tax_number   = ($request->tax_number ===  null) ? '----' : $request->tax_number;
            $dataResponse->irtra_number = ($request->irtra_number == null) ? '----' : $request->irtra_number;
            $dataResponse->igss_number  = ($request->igss_number === null) ? '----' : $request->igss_number;
            $dataResponse->application_date = date('Y-m-d H:i:s');
            $dataResponse->save();

            $applicationJob = new ApplicationJob();
            $applicationJob->application_date = date('Y-m-d');
            $applicationJob->vacancy_id = $request->vacancy_id;
            $applicationJob->status_application = 'PRO';
            $applicationJob->employee_file_id = $dataResponse->id;
            $applicationJob->save();


            $getEmployeeData = EmployeeFile::find($dataResponse->id);
            $aplJob = ApplicationJob::find($applicationJob->id);

            DB::commit();
            $data = [
                'code' => 200,
                'data' => $getEmployeeData,
                'applicationJob' => $aplJob
            ];
            return response()->json($data);
        } catch (\Throwable $error) {
            DB::rollBack();
            logger("ERROR: Error al grabar mensaje: " . $error->getMessage());
            logger("ERROR: Error al grabar linea: " . $error->getLine());
            logger("ERROR: Error al grabar archivo: " . $error->getFile());
            return response()->json([
                'code' => 200,
                'message' => $error->getMessage()
            ]);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        //dd($request->applId['id']);

        $applictionData = ApplicationJob::find($request->applId);
        $employeeData = EmployeeFile::find($applictionData->employee_file_id);
        $employeeUpdate = $employeeData->fill($request->all());
        if (isset($request->second_name)) {

            $employeeUpdate->second_name = ($request->second_name === null) ? '' : $request->second_name;
            $employeeUpdate->third_name = ($request->third_name === null) ? '' : $request->third_name;
            $employeeUpdate->second_last_name = ($request->second_last_name === null) ? '' : $request->second_last_name;
            $employeeUpdate->marital_last_name = ($request->marital_last_name === null) ? '' : $request->marital_last_name;
        }
        //dd($employeeUpdate);
        $employeeUpdate->update();

        $data = [
            'code' => 200,
            'data' => $employeeUpdate,
            'applicationJob' => $applictionData
        ];
        return response()->json($data);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function destroy($id)
    {
        //
    }

    public function showAplJob($id)
    {
        return view('modules.transaction.review-application');
    }


    public function listAplJob()
    {

        return view('modules.transaction.list-application');
    }

    public function getListApls(){

        $applications = ApplicationJob::select(
            'application_jobs.id',
            'application_jobs.application_date',
            'empf.personal_email',
            'empf.personal_mobile_number',
            'empf.company_employee_status',
            'empf.active',
            'vac.name as vacancy_name',
            DB::raw("CONCAT( empf.first_name ,' ', empf.second_name, ' ', empf.first_last_name, ' ', empf.second_last_name) as full_name")
        )
            ->join('vacancies as vac', 'vac.id', 'application_jobs.vacancy_id')
            ->join('employee_files as empf', 'empf.id', 'application_jobs.employee_file_id')
            ->get();
        $applications->transform(function ($application) {
            switch ($application->company_employee_status) {

                case 'SO':
                    $application->status_employee = 'SOLICITUD LABORAL';
                    $application->color           = 'green darken-1';
                    $application->disabled        = false;
                    break;
                case 'CO':
                    $application->status_employee = 'CONTRATADO';
                    $application->color           = 'blue darken-2';
                    $application->disabled        = false;
                    break;
                case 'LN':
                    $application->status_employee = 'LISTA NEGRA';
                    $application->color           = 'black';
                    $application->disabled        = true;
                    break;
                case 'LE':
                    $application->status_employee = 'LISTA DE ESPERA';
                    $application->color           = 'yellow darken-1';
                    $application->disabled        = true;
                    break;
                case 'RC':
                    $application->status_employee = 'RETIRADO PUEDE CONTRATAR';
                    $application->color           = 'light-blue darken-4';
                    $application->disabled        = false;
                    break;
                default:
                    $application->status_employee = 'SIN CLASIFICACION';
                    $application->color           = 'orange';
                    $application->disabled        = false;
                    break;
            }
            return $application;
        });

        $data = [
            'code' => 200,
            'data' => $applications
        ];

        return response()->json($data);
    }


    public function showAplJobData()
    {

        return view('modules.transaction.job-application-analisis');
    }

    public function getData($id){

        $jobAppl = ApplicationJob::find($id);
        $employee = EmployeeFile::find($jobAppl->employee_file_id);

        if ($employee->gender === 2 && $employee->marital_status === 1) {
            $getFullNameCandidate = "$employee->first_name $employee->second_name $employee->third_name $employee->first_last_name $employee->second_last_name de $employee->marital_last_name";
        } else {
            $getFullNameCandidate = "$employee->first_name $employee->second_name $employee->third_name $employee->first_last_name $employee->second_last_name";
        }

        $data = [
            'code' => 200,
            'data' => $employee,
            'jobApp'   => $jobAppl,
            'fullName' => strtoupper($getFullNameCandidate)
        ];

        return response()->json($data);
    }

    public function getUsers()
    {
        $users = User::whereNotIn('id', [Auth::user()->id])->where('interview', true)->get();

        $data = [
            'code'  => 200,
            'data' => $users
        ];

        return response()->json($data);
    }


    public function getBloodTypeList(){

        $bloodTypes = BloodType::all();

        $data = [
            'code' => 200,
            'data' => $bloodTypes
        ];

        return response()->json($data);
    }

    public function requestChageStatus(Request $request){

        $updateStatus = $request->all();

        if($updateStatus['type'] === 1){

            $jobApl = ApplicationJob::find($updateStatus['solId']);
            $jobApl->fill($request->all());
            $jobApl->save();

            $employee = EmployeeFile::find($jobApl->employee_file_id);
            $employee->company_employee_status = $updateStatus['status_application'];
            $employee->save();

        }

        $data =[
            'code' => 200
        ];
        return response()->json($data);



    }
}
