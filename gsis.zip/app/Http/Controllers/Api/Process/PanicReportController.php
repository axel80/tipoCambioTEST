<?php

namespace App\Http\Controllers\Api\Process;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Models\Modules\System\Process\PanicReport;

class PanicReportController extends Controller
{

    public function getReports(){

        $reports = PanicReport::orderBy('id', 'desc')->whereIn('status',['ALERTSEND', 'HELPSEND', 'HELPIN', 'PAYMENTPROC', 'PAYING'])->with(['user'])->get();

        $reports->transform(function($report){
            switch($report->status){
                case 'ALERTSEND':
                    $report->classAlert = 'danger';
                break;
                case 'HELPSEND':
                    $report->classAlert = 'warning';
                break;
                case 'HELPIN':
                    $report->classAlert = 'info';
                break;
                case 'PAYMENTPROC':
                    $report->classAlert = 'primary';
                break;

                case 'PAYING':
                    $report->classAlert = 'success';
                break;
                default:
                    $report->classAlert = 'purple';
                break;

            }
            return $report;
        });

        $data = [
            'code'      => 200,
            'data'   => $reports
        ];

        return response()->json($data);
    }

    public function addAlert(Request $request){

        try {
            DB::beginTransaction();

            $alert = new PanicReport($request->all());
            $alert->user_id = auth()->user()->id;
            $alert->save();

            $data = [
                'code' => 200,
                'alert' => $alert
            ];

            DB::commit();

            return response()->json($data);
        } catch (\Throwable $err) {

            DB::rollback();

            \logger("ERR: message: " . $err->getMessage());

            $data = [
                'code'          => 205,
                'errorLine'     => $err->getLine(),
                'errorMessage'  => $err->getMessage(),
                'errorFile'     => $err->getFile()
            ];

            return response()->json($data);
        }
    }

    public function getUsersAssign(){

        // Por el momento se deja con interview se debe colocar el mientras hasRole == supervisor
        //todo cambiar al perfil o rol "supervisor"
        $users = User::whereNotIn('id', [Auth::user()->id])->where('interview', true)->get();

        $data = [
            'code'  => 200,
            'data' => $users
        ];

        return response()->json($data);
    }


}
